export default {
    name: 'MICET BOT',
    name1: 'ULTRA BOT',
    prefix: '.',
    tipo: 'owner',
    info: 'Iniciando...',
    version: '2.0.0',
    navegador: 'Ubuntu Chrome',
    baileys: '7.0.9',
    botowner: '5492644156919',
    creador: '—͟͞ ⁱᵃᵐ Cuerbito 𒆜ᴼᶠⁱᶜⁱᵃˡ',
    canalId: '120363409173174836@newsletter',
    canalNombre: '▓⃟ ⃟👾┆ۜ𝗠ۣؓ𝖨ؓ͟𝖢ۣ𝖤ۣؓ𝖳̷̸ۣؓ 𝗕ۣؓ𝖮ؓ͟𝖳ۣ 𝗠ۣؓ𝖣ؓ͟ 𝟤ۣؓ𝟢ؓ͟𝟤ۣ𝟨ۣؓ '◞ 𓈒 ⿻🍟⡻',
    owner: ['5492644156919', '542646762285', '5215539356057'],
    group1: 'https://whatsapp.com/channel/0029VbCq9xP2ZjCr6AGMzi1b',
    group2: 'https://whatsapp.com/channel/0029VbCq9xP2ZjCr6AGMzi1b',
    group3: 'https://whatsapp.com/channel/0029VbCq9xP2ZjCr6AGMzi1b',
    sessionName: 'session',
    
    // Imagen para el menú/bienvenida
    img: 'https://n.uguu.se/mzLdSFnb.jpeg',
    imgMenu: 'https://n.uguu.se/mzLdSFnb.jpeg',
    
    // APIs para descargas y servicios externos
    APIs: {
        xyro: { 
            url: "https://api.xyro.site", 
            key: null 
        },
        yupra: { 
            url: "https://api.yupra.my.id", 
            key: null 
        },
        vreden: { 
            url: "https://api.vreden.web.id", 
            key: null 
        },
        delirius: { 
            url: "https://api.delirius.store", 
            key: null 
        },
        zenzxz: { 
            url: "https://api.zenzxz.my.id", 
            key: null 
        },
        siputzx: { 
            url: "https://api.siputzx.my.id", 
            key: null 
        },
        adonix: { 
            url: "https://api-adonix.ultraplus.click", 
            key: 'Destroy-xyz' 
        }
    }
}