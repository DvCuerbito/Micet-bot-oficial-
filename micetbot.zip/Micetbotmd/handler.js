import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { loadGroupsConfig, saveGroupsConfig, getGroupConfig, updateGroupConfig } from './lib/groupConfig.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ====================
// CONFIGURACIÓN DE RUTAS
// ====================
const USERS_FILE = path.join(__dirname, 'databases', 'users.json');
const LEVEL_FILE = path.join(__dirname, 'databases', 'level.json');
const WARNS_FILE = path.join(__dirname, 'databases', 'warns.json');
const PRIMARIOS_FILE = path.join(__dirname, 'databases', 'primarios.json');
const PRIVADO_FILE = path.join(__dirname, 'databases', 'privado.json');

// ====================
// FUNCIONES PARA EXTRAER NÚMEROS Y JIDS
// ====================

function extractNumberFromJid(jid) {
    if (!jid) return null;
    if (jid.includes('@lid')) {
        return null;
    }
    const number = jid.split('@')[0];
    return number.replace(/\D/g, '');
}

function getSenderNumber(msg) {
    if (msg.key?.participantAlt) {
        return extractNumberFromJid(msg.key.participantAlt);
    }
    if (msg.key?.participant) {
        if (msg.key.participant.includes('@lid')) {
            return null;
        }
        return extractNumberFromJid(msg.key.participant);
    }
    return null;
}

function getBotNumber(sock) {
    if (sock.phoneNumber) {
        return sock.phoneNumber.replace(/\D/g, '');
    }
    if (sock.user?.id) {
        return extractNumberFromJid(sock.user.id);
    }
    return null;
}

function getSenderLid(msg) {
    if (msg.key?.participant) {
        return msg.key.participant;
    }
    return null;
}

function getSenderJidForMention(msg) {
    if (msg.key?.participantAlt) {
        return msg.key.participantAlt;
    }
    if (msg.key?.participant) {
        return msg.key.participant;
    }
    return null;
}

function getNumberFromLid(usersDB, lid) {
    if (!lid || !usersDB) return null;
    const lidNumber = lid.split('@')[0];
    if (usersDB[lidNumber]) return lidNumber;
    for (const [number, userData] of Object.entries(usersDB)) {
        if (userData.lid === lid) return number;
    }
    return null;
}

// ====================
// FUNCIÓN PARA CARGAR CONFIGURACIÓN ESPECÍFICA DEL BOT
// ====================
async function getBotConfig(sock, defaultConfig) {
    try {
        let botNumber = '';
        
        if (sock.phoneNumber) {
            botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
        } else if (sock.user?.id) {
            botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
        }
        
        if (!botNumber) return defaultConfig;
        
        const configPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
        
        if (fs.existsSync(configPath)) {
            const configContent = fs.readFileSync(configPath, 'utf8');
            const jsonMatch = configContent.match(/export default\s+({[\s\S]*})/);
            
            if (jsonMatch && jsonMatch[1]) {
                const infoConfig = eval('(' + jsonMatch[1] + ')');
                
                if (infoConfig) {
                    return {
                        ...defaultConfig,
                        ...infoConfig,
                        APIs: {
                            ...defaultConfig.APIs,
                            ...(infoConfig.APIs || {})
                        }
                    };
                }
            }
        }
        
        return defaultConfig;
    } catch (error) {
        console.error('Error cargando configuración específica del bot:', error);
        return defaultConfig;
    }
}

// ====================
// INICIALIZAR ARCHIVOS
// ====================
const initFiles = () => {
    if (!fs.existsSync(path.join(__dirname, 'databases'))) {
        fs.mkdirSync(path.join(__dirname, 'databases'), { recursive: true });
    }
    if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, '{}', 'utf8');
    if (!fs.existsSync(LEVEL_FILE)) fs.writeFileSync(LEVEL_FILE, '{}', 'utf8');
    if (!fs.existsSync(WARNS_FILE)) fs.writeFileSync(WARNS_FILE, '{}', 'utf8');
    if (!fs.existsSync(PRIMARIOS_FILE)) fs.writeFileSync(PRIMARIOS_FILE, '{}', 'utf8');
    if (!fs.existsSync(PRIVADO_FILE)) fs.writeFileSync(PRIVADO_FILE, JSON.stringify({ enabled: true }, null, 2), 'utf8');
};

// ====================
// FUNCIONES DE USUARIOS
// ====================

const loadUsersDB = () => {
    try {
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            return JSON.parse(data);
        }
        return {};
    } catch (error) {
        console.error('Error cargando users.json:', error);
        return {};
    }
};

const saveUsersDB = (usersDB) => {
    try {
        fs.writeFileSync(USERS_FILE, JSON.stringify(usersDB, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando users.json:', error);
        return false;
    }
};

const registerUser = (usersDB, userNumber, userLid, userJidForMention, pushName) => {
    if (!userNumber) return { isNew: false, user: null };
    
    try {
        if (!usersDB[userNumber]) {
            usersDB[userNumber] = {
                number: userNumber,
                lid: userLid,
                jid: userJidForMention,
                name: pushName || userNumber,
                pushName: pushName || userNumber,
                registered: new Date().toISOString(),
                lastSeen: Date.now(),
                lastLid: userLid,
                lastJid: userJidForMention,
                firstCommand: null,
                groups: []
            };
            console.log(`⭐ Nuevo usuario registrado por comando: ${pushName || userNumber} (${userNumber})`);
            return { isNew: true, user: usersDB[userNumber] };
        } else {
            if (userLid && usersDB[userNumber].lid !== userLid) {
                usersDB[userNumber].lid = userLid;
                usersDB[userNumber].lastLid = userLid;
            }
            if (userJidForMention && usersDB[userNumber].jid !== userJidForMention) {
                usersDB[userNumber].jid = userJidForMention;
                usersDB[userNumber].lastJid = userJidForMention;
            }
            if (pushName && pushName !== 'Usuario') {
                usersDB[userNumber].pushName = pushName;
                if (!usersDB[userNumber].name) usersDB[userNumber].name = pushName;
            }
            usersDB[userNumber].lastSeen = Date.now();
            return { isNew: false, user: usersDB[userNumber] };
        }
    } catch (error) {
        console.error('Error en registerUser:', error);
        return { isNew: false, user: null };
    }
};

const getUserJidForMention = (usersDB, userNumber) => {
    try {
        if (!userNumber || !usersDB || !usersDB[userNumber]) return null;
        return usersDB[userNumber].jid || usersDB[userNumber].lid || null;
    } catch (error) {
        console.error('Error en getUserJidForMention:', error);
        return null;
    }
};

// ====================
// FUNCIONES DE NIVELES Y EXP
// ====================

const loadLevelDB = () => {
    try {
        if (fs.existsSync(LEVEL_FILE)) {
            const data = fs.readFileSync(LEVEL_FILE, 'utf8');
            return JSON.parse(data);
        }
        return {};
    } catch (error) {
        console.error('Error cargando level.json:', error);
        return {};
    }
};

const saveLevelDB = (levelDB) => {
    try {
        fs.writeFileSync(LEVEL_FILE, JSON.stringify(levelDB, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando level.json:', error);
        return false;
    }
};

const calculateExpForLevel = (level) => {
    return Math.floor(100 * Math.pow(1.5, level - 1));
};

const calculateLevel = (exp) => {
    let level = 1;
    let expNeeded = 100;
    let currentExp = exp;
    
    while (currentExp >= expNeeded) {
        currentExp -= expNeeded;
        level++;
        expNeeded = calculateExpForLevel(level);
    }
    
    return { level, currentExp, expNeeded, totalExp: exp };
};

const addCommandExp = (userNumber, commandName) => {
    try {
        if (!userNumber) return { success: false, error: 'Número no válido' };
        
        const levelDB = loadLevelDB();
        
        if (!levelDB[userNumber]) {
            levelDB[userNumber] = {
                number: userNumber,
                exp: 0,
                level: 1,
                commands: 0,
                lastCommand: null
            };
        }
        
        levelDB[userNumber].exp += 15;
        levelDB[userNumber].commands += 1;
        levelDB[userNumber].lastCommand = { name: commandName, timestamp: Date.now() };
        
        const newLevelData = calculateLevel(levelDB[userNumber].exp);
        const oldLevel = levelDB[userNumber].level;
        levelDB[userNumber].level = newLevelData.level;
        
        saveLevelDB(levelDB);
        
        return {
            success: true,
            newLevel: newLevelData.level,
            oldLevel: oldLevel,
            exp: levelDB[userNumber].exp,
            commands: levelDB[userNumber].commands,
            leveledUp: newLevelData.level > oldLevel
        };
        
    } catch (error) {
        console.error('Error agregando EXP:', error);
        return { success: false, error: error.message };
    }
};

const getUserLevelInfo = (userNumber) => {
    try {
        if (!userNumber) return { exists: false, level: 1, currentExp: 0, expNeeded: 100, totalExp: 0, commands: 0 };
        
        const levelDB = loadLevelDB();
        if (!levelDB[userNumber]) {
            return { exists: false, level: 1, currentExp: 0, expNeeded: 100, totalExp: 0, commands: 0 };
        }
        
        const userData = levelDB[userNumber];
        const levelData = calculateLevel(userData.exp || 0);
        
        return {
            exists: true,
            level: levelData.level,
            currentExp: levelData.currentExp,
            expNeeded: levelData.expNeeded,
            totalExp: levelData.totalExp,
            commands: userData.commands || 0,
            lastCommand: userData.lastCommand || null
        };
        
    } catch (error) {
        console.error('Error obteniendo info de nivel:', error);
        return { exists: false, level: 1, currentExp: 0, expNeeded: 100, totalExp: 0, commands: 0 };
    }
};

// ====================
// FUNCIONES PARA WARNINGS
// ====================

const loadWarnsDB = () => {
    try {
        if (fs.existsSync(WARNS_FILE)) {
            const data = fs.readFileSync(WARNS_FILE, 'utf8');
            return JSON.parse(data);
        }
        return {};
    } catch (error) {
        console.error('Error cargando warns.json:', error);
        return {};
    }
};

const saveWarnsDB = (warnsDB) => {
    try {
        fs.writeFileSync(WARNS_FILE, JSON.stringify(warnsDB, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando warns.json:', error);
        return false;
    }
};

const addWarn = (userNumber, adminNumber, reason, groupId) => {
    try {
        if (!userNumber) return null;
        
        const warnsDB = loadWarnsDB();
        if (!warnsDB[groupId]) warnsDB[groupId] = {};
        if (!warnsDB[groupId][userNumber]) warnsDB[groupId][userNumber] = [];
        
        const newWarn = {
            id: warnsDB[groupId][userNumber].length + 1,
            reason: reason,
            date: new Date().toLocaleString('es-ES'),
            timestamp: Date.now(),
            warner: adminNumber
        };
        
        warnsDB[groupId][userNumber].push(newWarn);
        saveWarnsDB(warnsDB);
        
        return newWarn;
    } catch (error) {
        console.error('Error agregando warn:', error);
        return null;
    }
};

const getWarns = (userNumber, groupId) => {
    try {
        const warnsDB = loadWarnsDB();
        if (warnsDB[groupId] && warnsDB[groupId][userNumber]) {
            return warnsDB[groupId][userNumber];
        }
        return [];
    } catch (error) {
        console.error('Error obteniendo warns:', error);
        return [];
    }
};

const removeWarn = (userNumber, groupId, warnId) => {
    try {
        const warnsDB = loadWarnsDB();
        if (warnsDB[groupId] && warnsDB[groupId][userNumber]) {
            const initialLength = warnsDB[groupId][userNumber].length;
            warnsDB[groupId][userNumber] = warnsDB[groupId][userNumber].filter(w => w.id !== warnId);
            warnsDB[groupId][userNumber] = warnsDB[groupId][userNumber].map((w, index) => ({ ...w, id: index + 1 }));
            saveWarnsDB(warnsDB);
            return warnsDB[groupId][userNumber].length < initialLength;
        }
        return false;
    } catch (error) {
        console.error('Error eliminando warn:', error);
        return false;
    }
};

const clearWarns = (userNumber, groupId) => {
    try {
        const warnsDB = loadWarnsDB();
        if (warnsDB[groupId] && warnsDB[groupId][userNumber]) {
            delete warnsDB[groupId][userNumber];
            saveWarnsDB(warnsDB);
            return true;
        }
        return false;
    } catch (error) {
        console.error('Error limpiando warns:', error);
        return false;
    }
};

// ====================
// FUNCIÓN PARA VERIFICAR ADMIN
// ====================
async function isUserAdmin(sock, groupId, userJid) {
    try {
        const groupMetadata = await sock.groupMetadata(groupId);
        const participant = groupMetadata.participants.find(p => p.id === userJid);
        return participant?.admin === 'admin' || participant?.admin === 'superadmin';
    } catch (error) {
        console.error('Error verificando admin:', error);
        return false;
    }
}

// ====================
// FUNCIÓN PARA RESPONDER CON CONTEXTO
// ====================
const replyWithContext = async (sock, msg, text, mentions = [], config) => {
    try {
        const from = msg.key.remoteJid;
        const quoted = msg;
        
        const messageData = {
            text: text,
            mentions: mentions,
            contextInfo: {
                mentionedJid: mentions,
                forwardingScore: 9999999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.canalId || '',
                    serverMessageId: 0,
                    newsletterName: config.canalNombre || ''
                }
            }
        };
        
        await sock.sendMessage(from, messageData, { quoted });
        return true;
    } catch (error) {
        console.error('Error en replyWithContext:', error);
        return false;
    }
};

// ====================
// FUNCIONES PARA CONTAR
// ====================
const getTotalCommandsUsed = () => {
    try {
        const levelDB = loadLevelDB();
        let total = 0;
        Object.values(levelDB).forEach(user => { if (user.commands) total += user.commands; });
        return total;
    } catch (error) {
        console.error('Error contando comandos:', error);
        return 0;
    }
};

const getTotalPlugins = () => {
    try {
        const pluginsDir = path.join(__dirname, 'plugins');
        if (fs.existsSync(pluginsDir)) {
            return fs.readdirSync(pluginsDir).filter(file => file.endsWith('.js')).length;
        }
        return 0;
    } catch (error) {
        console.error('Error contando plugins:', error);
        return 0;
    }
};

const getTotalRegistros = () => {
    try {
        const usersDB = loadUsersDB();
        return Object.keys(usersDB).length;
    } catch (error) {
        console.error('Error contando registros:', error);
        return 0;
    }
};

// ====================
// HANDLER PRINCIPAL
// ====================

initFiles();

const handler = async (sock, msg, plugins, defaultConfig) => {
    try {
        // ====================
        // CARGAR CONFIGURACIÓN ESPECÍFICA DEL BOT
        // ====================
        const config = await getBotConfig(sock, defaultConfig);
        
        const from = msg.key.remoteJid;
        const pushName = msg.pushName || 'Usuario';
        
        // OBTENER NÚMERO REAL, LID Y JID PARA MENCIÓN
        const senderNumber = getSenderNumber(msg);
        const senderLid = getSenderLid(msg);
        const senderJidForMention = getSenderJidForMention(msg);
        
        const isBotSelf = msg.key.fromMe;
        
        // --- SECCIÓN ACTUALIZADA PARA LISTAS Y BOTONES ---
        let body = '';
        if (msg.message?.conversation) body = msg.message.conversation;
        else if (msg.message?.extendedTextMessage?.text) body = msg.message.extendedTextMessage.text;
        else if (msg.message?.imageMessage?.caption) body = msg.message.imageMessage.caption || '';
        else if (msg.message?.videoMessage?.caption) body = msg.message.videoMessage.caption || '';
        else if (msg.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson) {
            try { body = JSON.parse(msg.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id || ''; } catch { body = ''; }
        } else if (msg.message?.listResponseMessage?.singleSelectReply?.selectedRowId) {
            body = msg.message.listResponseMessage.singleSelectReply.selectedRowId;
        } else if (msg.message?.buttonsResponseMessage?.selectedButtonId) {
            body = msg.message.buttonsResponseMessage.selectedButtonId;
        } else if (msg.message?.templateButtonReplyMessage?.selectedId) {
            body = msg.message.templateButtonReplyMessage.selectedId;
        }
        // ------------------------------------------------
        
        const isCommand = body.startsWith(config.prefix);
        
        // SI NO ES UN COMANDO, SIMPLEMENTE IGNORAR
        if (!isCommand) {
            return;
        }
        
        // ====================
        // VERIFICACIÓN DE MODO PRIVADO (SOLO PARA CHATS PRIVADOS)
        // ====================
        if (!from.endsWith('@g.us')) {
            // Cargar configuración de privado
            let privadoConfig = { enabled: true };
            try {
                if (fs.existsSync(PRIVADO_FILE)) {
                    privadoConfig = JSON.parse(fs.readFileSync(PRIVADO_FILE, 'utf8'));
                }
            } catch (error) {
                console.error('Error cargando privado.json:', error);
            }
            
            // Extraer nombre del comando para verificar si existe
            const args = body.slice(config.prefix.length).trim().split(/ +/);
            const cmdName = args[0]?.toLowerCase() || '';
            const plugin = plugins.get(cmdName);
            
            // Si el modo privado está DESACTIVADO
            if (!privadoConfig.enabled) {
                // Si el comando NO existe, responder con "comando no existe"
                if (!plugin) {
                    await replyWithContext(
                        sock, 
                        msg, 
                        `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}${cmdName}\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                        [],
                        config
                    );
                }
                // Si el comando SÍ existe, NO responder (ignorar completamente)
                return;
            }
        }
        
        // ====================
        // ES UN COMANDO - PROCESAR
        // ====================
        
        // Cargar base de datos SOLO cuando es un comando
        let usersDB = loadUsersDB();
        
        // REGISTRAR USUARIO SOLO CUANDO USA UN COMANDO (solo si tiene número real)
        if (senderNumber) {
            const registration = registerUser(usersDB, senderNumber, senderLid, senderJidForMention, pushName);
            
            if (from.endsWith('@g.us') && registration.user) {
                if (!registration.user.groups) registration.user.groups = [];
                if (!registration.user.groups.includes(from)) {
                    registration.user.groups.push(from);
                }
            }
        }
        
        // VERIFICAR SI EL USUARIO ESTÁ BANEADO
        if (senderNumber && usersDB[senderNumber]?.banned?.isBanned) {
            console.log(`🚫 Usuario baneado: ${senderNumber}`);
            return;
        }
        
        // ====================
        // VERIFICACIONES PARA GRUPOS
        // ====================
        if (from.endsWith('@g.us')) {
            // VERIFICAR BOT PRIMARIO
            try {
                let primariosDB = {};
                if (fs.existsSync(PRIMARIOS_FILE)) {
                    primariosDB = JSON.parse(fs.readFileSync(PRIMARIOS_FILE, 'utf8'));
                }
                
                if (primariosDB[from]) {
                    const botPrimarioPhone = primariosDB[from].botPhone;
                    
                    let currentBotPhone = '';
                    if (sock.user?.id) currentBotPhone = extractNumberFromJid(sock.user.id);
                    else if (sock.userId) currentBotPhone = extractNumberFromJid(sock.userId);
                    else if (sock.phoneNumber) currentBotPhone = sock.phoneNumber;
                    
                    const cleanBotPrimario = botPrimarioPhone.replace(/\D/g, '');
                    const cleanCurrentBot = (currentBotPhone || '').replace(/\D/g, '');
                    
                    if (!cleanCurrentBot.includes(cleanBotPrimario) && !cleanBotPrimario.includes(cleanCurrentBot)) {
                        console.log(`🚫 Bot no primario en ${from}`);
                        return;
                    }
                }
            } catch (error) {
                console.error('Error verificando bot primario:', error);
            }
            
            // OBTENER CONFIGURACIÓN DEL GRUPO
            const groupConfig = getGroupConfig(from);
            const botEnabled = groupConfig.botEnabled;
            const onlyadmin = groupConfig.onlyadmin;
            
            // Extraer nombre del comando
            const args = body.slice(config.prefix.length).trim().split(/ +/);
            const cmdName = args[0]?.toLowerCase() || '';
            
            // Verificar owner - usando número real o LID
            const isOwner = config.owner && config.owner.some(ownerNum => {
                const cleanOwner = ownerNum.replace(/\D/g, '');
                // Verificar con número real del usuario
                if (senderNumber && cleanOwner === senderNumber.replace(/\D/g, '')) return true;
                // Verificar con LID (extraer número del LID)
                if (senderLid && cleanOwner === senderLid.split('@')[0].replace(/\D/g, '')) return true;
                return false;
            });
            
            // PERMITIR COMANDOS DE CONFIGURACIÓN SIEMPRE
            if (cmdName === 'bot' || cmdName === 'onlyadmin' || cmdName === 'privado') {
                console.log(`⚙️ Comando de configuración permitido: ${cmdName}`);
            }
            else if (!botEnabled) {
                if (isOwner) {
                    console.log(`👑 Owner en grupo desactivado: ${senderNumber || senderLid}`);
                } else {
                    await sock.sendMessage(from, {
                        text: `🌠 ${config.name} está apagado.\n> Activa el bot usando ${config.prefix}bot on`,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    return;
                }
            }
            
            // VERIFICAR ONLYADMIN
            if (onlyadmin && cmdName !== 'bot' && cmdName !== 'onlyadmin' && cmdName !== 'privado') {
                const isAdmin = senderJidForMention ? await isUserAdmin(sock, from, senderJidForMention) : false;
                if (!isAdmin && !isOwner) {
                    console.log(`🔒 Usuario no admin ignorado: ${senderNumber || senderLid}`);
                    return;
                }
            }
        }
        
        // ====================
        // PROCESAR COMANDO
        // ====================
        const args = body.slice(config.prefix.length).trim().split(/ +/);
        const cmdName = args.shift().toLowerCase();
        
        const plugin = plugins.get(cmdName);
        
        if (plugin) {
            const startTime = Date.now();
            
            let expResult = { success: true, leveledUp: false, newLevel: 1 };
            
            // AGREGAR EXP POR USAR COMANDO (15 EXP)
            if (!isBotSelf && senderNumber) {
                expResult = addCommandExp(senderNumber, cmdName);
                console.log(`🎮 Comando +15 EXP para ${pushName} (${senderNumber}) - Nivel: ${expResult.newLevel || 1}`);
                
                if (usersDB[senderNumber] && !usersDB[senderNumber].firstCommand) {
                    usersDB[senderNumber].firstCommand = { name: cmdName, timestamp: Date.now() };
                }
            }
            
            saveUsersDB(usersDB);
            
            const levelInfo = senderNumber ? getUserLevelInfo(senderNumber) : { exists: false, level: 1, commands: 0 };
            
            let botType = '';
            if (sock.isMainBot) botType = '🟦 MAIN';
            else if (sock.isSubBot) botType = '🟩 SUB';
            else botType = '🤖 PRINCIPAL';
            
            const userType = isBotSelf ? `${botType} [SELF]` : '👤 USUARIO';
            
            // Para SELF, usar el número real del bot en lugar del LID
            let displayIdentifier = senderNumber || 'sin número';
            if (isBotSelf) {
                const botNumber = getBotNumber(sock);
                if (botNumber) displayIdentifier = botNumber;
            }
            
            console.log(`${userType} ${pushName} (${displayIdentifier}) usó: ${config.prefix}${cmdName}`);
            
            // FUNCIÓN PARA OBTENER JID DE UN USUARIO POR SU NÚMERO O LID
            const getJidForMention = (targetId) => {
                if (/^\d+$/.test(targetId)) {
                    return getUserJidForMention(usersDB, targetId);
                }
                const numberFromLid = getNumberFromLid(usersDB, targetId);
                if (numberFromLid) {
                    return getUserJidForMention(usersDB, numberFromLid);
                }
                return targetId;
            };
            
            await plugin.execute(sock, msg, {
                args,
                command: cmdName,
                body,
                config,
                startTime,
                usersDB,
                levelInfo,
                pushName,
                sender: isBotSelf ? (getBotNumber(sock) || senderLid) : (senderNumber || senderLid),
                senderNumber: isBotSelf ? getBotNumber(sock) : senderNumber,
                senderLid: senderLid,
                senderJid: senderJidForMention,
                expResult,
                isBotSelf,
                isMainBot: sock.isMainBot || false,
                isSubBot: sock.isSubBot || false,
                replyWithContext: (text, mentions = []) => replyWithContext(sock, msg, text, mentions, config),
                getTotalCommandsUsed,
                getTotalPlugins,
                getTotalRegistros,
                calculateLevel,
                loadUsersDB,
                saveUsersDB,
                loadLevelDB,
                plugins: plugins,
                addWarn,
                getWarns,
                removeWarn,
                clearWarns,
                canUseWarnCommands: async (userNumber, groupId) => {
                    const userJid = getUserJidForMention(usersDB, userNumber);
                    return userJid ? isUserAdmin(sock, groupId, userJid) : false;
                },
                getGroupConfig,
                updateGroupConfig,
                loadGroupsConfig,
                saveGroupsConfig,
                extractNumberFromJid,
                getSenderNumber,
                getSenderLid,
                getSenderJidForMention,
                getUserJidForMention,
                getNumberFromLid,
                addCommandExp,
                getNumberFromLid: (lid) => getNumberFromLid(usersDB, lid),
                getBotNumber: () => getBotNumber(sock)
            });
            
        } else {
            saveUsersDB(usersDB);
            
            // Intentar obtener el JID para mencionar
            let mentionJid = senderJidForMention || senderLid;
            if (!mentionJid && senderNumber && usersDB[senderNumber]) {
                mentionJid = usersDB[senderNumber].jid || usersDB[senderNumber].lid;
            }
            
            await replyWithContext(
                sock, 
                msg, 
                `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}${cmdName}\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                mentionJid ? [mentionJid] : [],
                config
            );
        }
        
    } catch (error) {
        console.error('🔥 Error en handler:', error);
    }
};

export default handler;

export {
    loadUsersDB,
    saveUsersDB,
    loadLevelDB,
    saveLevelDB,
    calculateExpForLevel,
    calculateLevel,
    addCommandExp,
    getUserLevelInfo,
    registerUser,
    replyWithContext,
    getTotalCommandsUsed,
    getTotalPlugins,
    getTotalRegistros,
    loadWarnsDB,
    saveWarnsDB,
    addWarn,
    getWarns,
    removeWarn,
    clearWarns,
    isUserAdmin,
    getGroupConfig,
    updateGroupConfig,
    extractNumberFromJid,
    getSenderNumber,
    getSenderLid,
    getSenderJidForMention,
    getUserJidForMention,
    getNumberFromLid,
    getBotConfig,
    getBotNumber
};