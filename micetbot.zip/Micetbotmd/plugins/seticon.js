import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { downloadMediaMessage } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'seticon',
    alias: ['seticono'],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderNumber } = options;
            const from = msg.key.remoteJid;
            const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            
            let botNumber = '';
            if (sock.phoneNumber) {
                botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            if (!botNumber) {
                throw new Error('No se pudo identificar el número del bot');
            }
            
            const isBotOwner = config.botowner && 
                              config.botowner.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '');
            
            if (!isBotOwner) {
                await sock.sendMessage(from, {
                    text: `❀ *Solo el dueño del bot puede cambiar su icono*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            if (!quoted) {
                await sock.sendMessage(from, {
                    text: `🪷 *Debes responder a una imagen*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            const messageType = Object.keys(quoted)[0];
            
            if (messageType !== 'imageMessage') {
                await sock.sendMessage(from, {
                    text: `🪷 *Debes responder a una imagen*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            try {
                console.log(`🖼️ Botowner ${senderNumber} cambiando icono...`);
                
                const infoDir = path.join(process.cwd(), 'info', botNumber);
                if (!fs.existsSync(infoDir)) {
                    fs.mkdirSync(infoDir, { recursive: true });
                }
                
                const iconPath = path.join(infoDir, 'icon.jpg');
                
                const quotedMsgObj = {
                    key: {
                        remoteJid: from,
                        id: msg.message.extendedTextMessage.contextInfo.stanzaId,
                        participant: msg.message.extendedTextMessage.contextInfo.participant,
                        fromMe: false
                    },
                    message: {
                        imageMessage: quoted.imageMessage
                    }
                };
                
                const buffer = await downloadMediaMessage(
                    quotedMsgObj,
                    'buffer',
                    {},
                    {
                        logger: console,
                        reuploadRequest: sock.updateMediaMessage
                    }
                );
                
                if (!buffer || buffer.length === 0) {
                    throw new Error('No se pudo descargar la imagen');
                }
                
                if (buffer.length > 2 * 1024 * 1024) {
                    throw new Error('La imagen es demasiado grande (máx 2MB)');
                }
                
                fs.writeFileSync(iconPath, buffer);
                
                console.log(`✅ Icono guardado: ${iconPath} (${buffer.length} bytes)`);
                
                await sock.sendMessage(from, {
                    text: `🌸 *Icono guardado con éxito*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
            } catch (error) {
                console.error('Error:', error);
                await sock.sendMessage(from, {
                    text: `🪷 *Error:* ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
        } catch (error) {
            console.error('Error general:', error);
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ Error: ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};