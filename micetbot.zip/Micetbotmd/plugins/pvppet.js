import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');
const PETS_FILE = path.join(__dirname, '..', 'databases', 'pets.json');

// Lista de mascotas del sistema para pelear
const SYSTEM_PETS = [
    { name: 'Lobo Salvaje', emoji: '🐺', health: 100, power: 85 },
    { name: 'Tigre', emoji: '🐯', health: 120, power: 90 },
    { name: 'Águila', emoji: '🦅', health: 80, power: 95 },
    { name: 'Serpiente', emoji: '🐍', health: 70, power: 80 },
    { name: 'Oso', emoji: '🐻', health: 150, power: 85 },
    { name: 'León', emoji: '🦁', health: 130, power: 95 },
    { name: 'Dragón', emoji: '🐉', health: 200, power: 100 },
    { name: 'Tiburón', emoji: '🦈', health: 160, power: 90 },
    { name: 'Elefante', emoji: '🐘', health: 180, power: 85 },
    { name: 'Rinoceronte', emoji: '🦏', health: 170, power: 88 },
    { name: 'Cocodrilo', emoji: '🐊', health: 140, power: 92 },
    { name: 'Hipopótamo', emoji: '🦛', health: 190, power: 87 }
];

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 10000,
            bank: 0,
            pets: [],
            foods: []
        };
    }
    if (economy[userNumber].pets === undefined) economy[userNumber].pets = [];
    if (economy[userNumber].foods === undefined) economy[userNumber].foods = [];
    if (economy[userNumber].bank === undefined) economy[userNumber].bank = 0;
    return economy[userNumber];
}

function getRandomSystemPet() {
    const randomIndex = Math.floor(Math.random() * SYSTEM_PETS.length);
    return { ...SYSTEM_PETS[randomIndex] };
}

function battle(petUser, petSystem) {
    // Calcular poder total
    const userPower = petUser.health + (petUser.power || 50);
    const systemPower = petSystem.health + petSystem.power;
    
    // Probabilidad de ganar basada en poder
    const userChance = userPower / (userPower + systemPower);
    const random = Math.random();
    
    return random < userChance;
}

export default {
    name: 'pvppet',
    alias: ['petpvp', 'peleapet'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderNumber, pushName, replyWithContext, senderJid } = options;
            const from = msg.key.remoteJid;
            
            if (!senderNumber) {
                return await replyWithContext('❌ No se pudo identificar tu número', [senderJid]);
            }
            
            let economy = loadEconomy();
            const user = initUserEconomy(economy, senderNumber, pushName);
            
            if (!user.pets || user.pets.length === 0) {
                return await replyWithContext(
                    `🐾 *No tienes mascotas para pelear*\n\n> Compra una mascota con ${config.prefix}storepets`,
                    [senderJid]
                );
            }
            
            // Verificar si tiene suficientes coins (500,000)
            const BET_AMOUNT = 500000;
            if (user.coins < BET_AMOUNT) {
                return await replyWithContext(
                    `❌ *No tienes suficientes coins para apostar*\n\n` +
                    `> 💰 *Necesitas:* ${BET_AMOUNT.toLocaleString()} coins\n` +
                    `> 💵 *Tienes:* ${user.coins.toLocaleString()} coins\n\n` +
                    `> Gana más coins con comandos como *minar*, *trabajar*, *aventura*`,
                    [senderJid]
                );
            }
            
            // Si hay un argumento numérico (selección directa)
            if (args.length > 0 && !isNaN(parseInt(args[0]))) {
                const petIndex = parseInt(args[0]) - 1;
                
                if (petIndex < 0 || petIndex >= user.pets.length) {
                    return await replyWithContext(
                        `❌ Mascota no encontrada. Tienes ${user.pets.length} mascota(s).\n\n> Usa ${config.prefix}pvppet para ver la lista`,
                        [senderJid]
                    );
                }
                
                const selectedPet = user.pets[petIndex];
                const systemPet = getRandomSystemPet();
                
                // Realizar pelea
                const win = battle(selectedPet, systemPet);
                
                let resultText = `⚔️ *PvP PET* ⚔️\n\n`;
                resultText += `🐾 *Tu mascota:* ${selectedPet.emoji} ${selectedPet.name}\n`;
                resultText += `🐺 *Rival:* ${systemPet.emoji} ${systemPet.name}\n`;
                resultText += `━━━━━━━━━━━━━━━━\n`;
                
                if (win) {
                    // GANASTE
                    user.coins += BET_AMOUNT;
                    saveEconomy(economy);
                    
                    resultText += `🎉 *¡VICTORIA!* 🎉\n\n`;
                    resultText += `✨ *${selectedPet.emoji} ${selectedPet.name} ha ganado la pelea!*\n`;
                    resultText += `💰 *Ganaste:* +${BET_AMOUNT.toLocaleString()} coins\n`;
                    resultText += `💵 *Total:* ${user.coins.toLocaleString()} coins\n`;
                    resultText += `\n> ${selectedPet.name} ahora es más fuerte!`;
                    
                } else {
                    // PERDISTE - Pierdes la mascota y los coins
                    user.coins -= BET_AMOUNT;
                    const lostPet = user.pets.splice(petIndex, 1)[0];
                    saveEconomy(economy);
                    
                    resultText += `💀 *¡DERROTA!* 💀\n\n`;
                    resultText += `😭 *${lostPet.emoji} ${lostPet.name} ha perdido la pelea y se ha ido...*\n`;
                    resultText += `💰 *Perdiste:* -${BET_AMOUNT.toLocaleString()} coins\n`;
                    resultText += `💵 *Te quedan:* ${user.coins.toLocaleString()} coins\n`;
                    resultText += `\n> Puedes volver a comprar a ${lostPet.emoji} ${lostPet.name} en la tienda.`;
                }
                
                return await replyWithContext(resultText, [senderJid]);
            }
            
            // Mostrar lista de mascotas para pelear
            const petRows = user.pets.map((pet, index) => ({
                title: `${pet.emoji} ${pet.name}`,
                description: `❤️ Salud: ${pet.health}% | Apostar ${BET_AMOUNT.toLocaleString()} coins`,
                id: `${config.prefix}pvppet ${index + 1}`
            }));
            
            const sections = [{
                title: "🐾 SELECCIONA TU MASCOTA PARA PELEAR",
                rows: petRows
            }];
            
            const message = `⚔️ *ARENA PvP* ⚔️\n\n` +
                `💰 *Apuesta:* ${BET_AMOUNT.toLocaleString()} coins\n` +
                `💵 *Tus coins:* ${user.coins.toLocaleString()}\n` +
                `📦 *Tus mascotas:* ${user.pets.length}\n\n` +
                `⚠️ *Reglas:*\n` +
                `• Si ganas: +${BET_AMOUNT.toLocaleString()} coins\n` +
                `• Si pierdes: -${BET_AMOUNT.toLocaleString()} coins y pierdes a tu mascota\n` +
                `• La pelea es aleatoria basada en la fuerza de tu mascota\n\n` +
                `📋 *Selecciona una mascota para pelear*`;
            
            await sock.sendMessage(from, {
                text: message,
                footer: "⚔️ Moonlight PvP",
                interactiveButtons: [
                    {
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "🐾 Tus Mascotas",
                            sections: sections,
                        }),
                    },
                ],
            }, { quoted: msg });
            
        } catch (error) {
            console.error('❌ Error en pvppet:', error);
            await replyWithContext(`❌ Error: ${error.message}`, [senderJid]);
        }
    }
};