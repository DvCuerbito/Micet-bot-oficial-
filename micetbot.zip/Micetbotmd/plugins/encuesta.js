export default {
    name: 'encuesta',
    alias: ['poll'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            // Verificar que sea un grupo
            if (!from.endsWith('@g.us')) {
                await replyWithContext(
                    `🌸 Este comando solo puede usarse en grupos.`,
                    []
                );
                return;
            }
            
            const text = args.join(' ');
            
            if (!text) {
                await replyWithContext(
                    `🌸 *Ingresa la pregunta y opciones.*\n\n*• Ejemplo:*\n*${config.prefix}encuesta* Moonlight es el mejor bot?|si|no`,
                    []
                );
                return;
            }
            
            const textSplit = text.split('|');
            
            if (textSplit.length < 3) {
                await replyWithContext(
                    `🌸 *Mínimo 2 opciones.*\n\n*Ejemplo:*\n${config.prefix}encuesta ¿Te gusta Moonlight?|si|no`,
                    []
                );
                return;
            }
            
            if (textSplit.length > 13) {
                await replyWithContext(
                    `🌸 *Máximo 12 opciones.*`,
                    []
                );
                return;
            }
            
            const question = textSplit[0];
            const options_list = textSplit.slice(1);
            
            try {
                await sock.sendMessage(from, { react: { text: '🌸', key: msg.key } });
            } catch (e) {}
            
            // Enviar encuesta sin emojis en la pregunta
            await sock.sendMessage(from, {
                poll: {
                    name: question,
                    values: options_list,
                    selectableCount: 1
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Encuesta creada por ${pushName || 'Usuario'} en grupo ${from}`);
            
        } catch (error) {
            console.error('❌ Error en encuesta:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ Error: ${error.message}`,
                contextInfo: {
                    mentionedJid: [options.senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};