import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 0,
            minerals: {
                piedras: 0,
                diamantes: 0,
                esmeraldas: 0,
                oro: 0
            },
            health: 100,
            lastMine: 0,
            lastWork: 0,
            lastCrime: 0,
            lastAdventure: 0,
            lastClaim: 0,
            lastChest: 0,
            lastHunt: 0,
            lastFish: 0,
            items: {
                agua: 0,
                vendas: 0,
                pastillas: 0
            }
        };
    }
    return economy[userNumber];
}

function getRemainingTime(lastUsed, cooldownMs = 120000) { // 2 minutos
    const now = Date.now();
    const timePassed = now - lastUsed;
    
    if (timePassed >= cooldownMs) return 0;
    
    const remaining = cooldownMs - timePassed;
    const seconds = Math.floor(remaining / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    
    if (minutes > 0) {
        return `${minutes}m ${remainingSeconds}s`;
    }
    return `${remainingSeconds}s`;
}

// Peces para pescar
const fish = [
    // Peces comunes (70% probabilidad)
    {
        name: "🐟 Pez pequeño",
        rarity: "común",
        probability: 0.70,
        coins: [5, 15],
        healthCost: [1, 3],
        exp: 3
    },
    {
        name: "🐠 Pez tropical",
        rarity: "común",
        probability: 0.70,
        coins: [8, 20],
        healthCost: [1, 4],
        exp: 5
    },
    {
        name: "🦐 Camarón",
        rarity: "común",
        probability: 0.70,
        coins: [10, 18],
        healthCost: [2, 3],
        exp: 4
    },
    {
        name: "🐚 Caracol",
        rarity: "común",
        probability: 0.70,
        coins: [5, 12],
        healthCost: [1, 2],
        exp: 3
    },
    
    // Peces raros (20% probabilidad)
    {
        name: "🐡 Pez globo",
        rarity: "raro",
        probability: 0.20,
        coins: [25, 45],
        healthCost: [5, 10],
        exp: 12
    },
    {
        name: "🦑 Calamar",
        rarity: "raro",
        probability: 0.20,
        coins: [30, 50],
        healthCost: [4, 8],
        exp: 15
    },
    {
        name: "🐙 Pulpo",
        rarity: "raro",
        probability: 0.20,
        coins: [35, 60],
        healthCost: [5, 9],
        exp: 18
    },
    {
        name: "🦀 Cangrejo",
        rarity: "raro",
        probability: 0.20,
        coins: [20, 40],
        healthCost: [3, 6],
        exp: 10
    },
    
    // Peces épicos (7% probabilidad)
    {
        name: "🐋 Ballena",
        rarity: "épico",
        probability: 0.07,
        coins: [80, 150],
        healthCost: [10, 20],
        exp: 40
    },
    {
        name: "🦈 Tiburón",
        rarity: "épico",
        probability: 0.07,
        coins: [100, 200],
        healthCost: [15, 25],
        exp: 50
    },
    {
        name: "🐬 Delfín",
        rarity: "épico",
        probability: 0.07,
        coins: [70, 130],
        healthCost: [5, 12],
        exp: 35
    },
    
    // Peces legendarios (3% probabilidad)
    {
        name: "🐉 Pez dragón",
        rarity: "legendario",
        probability: 0.03,
        coins: [200, 400],
        healthCost: [8, 15],
        exp: 80,
        special: "🐉 ¡Escamas doradas! +100 coins"
    },
    {
        name: "👑 Pez rey",
        rarity: "legendario",
        probability: 0.03,
        coins: [150, 300],
        healthCost: [5, 10],
        exp: 70,
        special: "👑 ¡Corona real! +50 coins y +1 diamante"
    },
    {
        name: "🌊 Serpiente marina",
        rarity: "legendario",
        probability: 0.03,
        coins: [180, 350],
        healthCost: [12, 20],
        exp: 90,
        special: "🌊 ¡Escamas mágicas! +75 coins y +2 esmeraldas"
    }
];

export default {
    name: 'pescar',
    alias: ['fish', 'pesca'],
    
    async execute(sock, msg, options) {
        try {
            const { 
                config, 
                senderNumber, 
                pushName,
                replyWithContext,
                senderJid 
            } = options;
            
            if (!senderNumber) {
                return await replyWithContext(
                    '❌ No se pudo identificar tu número',
                    [senderJid]
                );
            }
            
            let economy = loadEconomy();
            const user = initUserEconomy(economy, senderNumber, pushName);
            
            // Verificar salud mínima
            if (user.health < 10) {
                return await replyWithContext(
                    '⚠️ *Estás muy débil para pescar*\n' +
                    '> Necesitas al menos 10 de salud\n' +
                    '> Usa *heal* para recuperarte',
                    [senderJid]
                );
            }
            
            // Verificar cooldown de 2 minutos
            const cooldownTime = 120000; // 2 minutos
            const now = Date.now();
            
            if (user.lastFish && (now - user.lastFish) < cooldownTime) {
                const remaining = getRemainingTime(user.lastFish, cooldownTime);
                return await replyWithContext(
                    `⏳ *Debes esperar ${remaining}* para volver a pescar`,
                    [senderJid]
                );
            }
            
            // Actualizar tiempo
            user.lastFish = now;
            
            // Seleccionar pez basado en probabilidades
            const rand = Math.random();
            let pez;
            
            if (rand < 0.7) { // 70% común
                const comunes = fish.filter(f => f.rarity === 'común');
                pez = comunes[Math.floor(Math.random() * comunes.length)];
            } else if (rand < 0.9) { // 20% raro
                const raros = fish.filter(f => f.rarity === 'raro');
                pez = raros[Math.floor(Math.random() * raros.length)];
            } else if (rand < 0.97) { // 7% épico
                const épicos = fish.filter(f => f.rarity === 'épico');
                pez = épicos[Math.floor(Math.random() * épicos.length)];
            } else { // 3% legendario
                const legendarios = fish.filter(f => f.rarity === 'legendario');
                pez = legendarios[Math.floor(Math.random() * legendarios.length)];
            }
            
            // Calcular ganancias y pérdidas
            const coinsGanados = Math.floor(Math.random() * (pez.coins[1] - pez.coins[0] + 1)) + pez.coins[0];
            const saludPerdida = Math.floor(Math.random() * (pez.healthCost[1] - pez.healthCost[0] + 1)) + pez.healthCost[0];
            
            // Aplicar cambios
            user.coins += coinsGanados;
            user.health = Math.max(0, user.health - saludPerdida);
            
            // Bonus especial para legendarios
            let specialText = '';
            if (pez.special) {
                if (pez.name === "🐉 Pez dragón") {
                    user.coins += 100;
                    specialText = '\n🐉 *¡Escamas doradas!* +100 coins extra';
                } else if (pez.name === "👑 Pez rey") {
                    user.coins += 50;
                    user.minerals.diamantes += 1;
                    specialText = '\n👑 *¡Corona real!* +50 coins y +1 diamante';
                } else if (pez.name === "🌊 Serpiente marina") {
                    user.coins += 75;
                    user.minerals.esmeraldas += 2;
                    specialText = '\n🌊 *¡Escamas mágicas!* +75 coins y +2 esmeraldas';
                }
            }
            
            saveEconomy(economy);
            
            // Determinar emoji según rareza
            let rarityEmoji = '';
            switch(pez.rarity) {
                case 'común': rarityEmoji = '🟢'; break;
                case 'raro': rarityEmoji = '🔵'; break;
                case 'épico': rarityEmoji = '🟣'; break;
                case 'legendario': rarityEmoji = '🟡'; break;
            }
            
            const fishText = `🎣 *PESCA EXITOSA*\n\n` +
                `${pez.name}\n` +
                `${rarityEmoji} *Rareza:* ${pez.rarity.toUpperCase()}\n\n` +
                `🎑 *RECOMPENSAS*\n\n` +
                `💰 Coins obtenidos » *+${coinsGanados}*\n` +
                `❤️ Salud perdida » *-${saludPerdida}*${specialText}\n\n` +
                `📊 *Total:* ${user.coins} coins | ${user.health} salud`;
            
            await replyWithContext(fishText, [senderJid]);
            
        } catch (error) {
            console.error('❌ Error en comando pescar:', error);
            await options.replyWithContext(
                `❌ Error: ${error.message}`,
                [options.senderJid]
            );
        }
    }
};
