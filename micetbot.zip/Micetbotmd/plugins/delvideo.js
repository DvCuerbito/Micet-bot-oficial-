import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const OWNER_NUMBER = "189202503315478";

export default {
    name: 'delvideo',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, senderNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            // Solo el owner puede usar este comando (por número)
            if (senderNumber !== OWNER_NUMBER) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}delvideo\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const fullArgs = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const cleanArgs = fullArgs.replace(config.prefix + 'delvideo', '').trim();

            if (!cleanArgs || !cleanArgs.includes('=')) {
                await sock.sendMessage(from, {
                    text: '☆ Formato incorrecto. Usa: /delvideo +categoría = +archivo\n> ✐ Ej : /delvideo +love = +video_1234567890.mp4',
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const parts = cleanArgs.split('=').map(part => part.trim());
            if (parts.length < 2) {
                await sock.sendMessage(from, {
                    text: '☆ Debes especificar categoría y archivo: /delvideo +categoría = +archivo',
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            let categoryName = parts[0];
            let filename = parts[1];

            if (categoryName.startsWith('+')) {
                categoryName = categoryName.substring(1).toLowerCase();
            }
            if (filename.startsWith('+')) {
                filename = filename.substring(1);
            }

            if (!categoryName || !filename) {
                await sock.sendMessage(from, {
                    text: '☆ Debes especificar categoría y archivo: /delvideo +categoría = +archivo',
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const categoriesFile = path.join(__dirname, '..', 'databases', 'categories.json');
            let categories = {};
            
            if (fs.existsSync(categoriesFile)) {
                categories = JSON.parse(fs.readFileSync(categoriesFile, 'utf8'));
            }

            if (!categories[categoryName]) {
                await sock.sendMessage(from, {
                    text: '❖ La categoría especificada no existe.',
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const category = categories[categoryName];
            let videoIndex = -1;
            let videoInfo = null;

            if (category.videos && Array.isArray(category.videos)) {
                for (let i = 0; i < category.videos.length; i++) {
                    if (category.videos[i].filename === filename) {
                        videoIndex = i;
                        videoInfo = category.videos[i];
                        break;
                    }
                }
            }

            if (videoIndex === -1) {
                await sock.sendMessage(from, {
                    text: `❖ El archivo *${filename}* no existe en la categoría *${categoryName}*`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const videosDir = path.join(__dirname, '..', 'videos');
            const videoPath = path.join(videosDir, categoryName, filename);
            
            if (fs.existsSync(videoPath)) {
                fs.unlinkSync(videoPath);
            }

            category.videos.splice(videoIndex, 1);
            category.videoCount = category.videos.length;
            categories[categoryName] = category;

            fs.writeFileSync(categoriesFile, JSON.stringify(categories, null, 2));

            await sock.sendMessage(from, {
                text: `☆ Se ha eliminado el archivo *${filename}* de la categoría *${categoryName}*`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });

        } catch (error) {
            console.log('Error en comando delvideo:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: '❖ Error al procesar el comando.',
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};