import { downloadMediaMessage } from '@whiskeysockets/baileys';

export default {
    name: 'tag',
    alias: ['tagsay'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            // Verificar si es un grupo
            if (!from.includes('@g.us')) {
                await sock.sendMessage(from, {
                    text: `♡ Este comando solo puede usarse en grupos`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Obtener metadatos del grupo
            const groupMetadata = await sock.groupMetadata(from);
            const participants = groupMetadata.participants;
            
            // Obtener el JID del bot correctamente
            const botJid = sock.user.id;
            
            // Verificar si el remitente es administrador - CORREGIDO
            // Buscar al participante por su JID (puede ser LID o número normal)
            const senderParticipant = participants.find(p => {
                // Comparar con senderJid (que puede ser LID o número)
                if (p.id === senderJid) return true;
                // Comparar con senderNumber (número limpio)
                if (p.id.includes(senderNumber || '')) return true;
                // Si el senderJid es LID, comparar con el número extraído
                if (senderJid && senderJid.includes('@lid')) {
                    const senderNum = senderJid.split('@')[0];
                    if (p.id.includes(senderNum)) return true;
                }
                return false;
            });
            
            const isAdmin = senderParticipant && 
                          (senderParticipant.admin === 'admin' || senderParticipant.admin === 'superadmin');
            
            console.log(`[TAG] Sender: ${senderJid} | Es admin: ${isAdmin} | Admin nivel: ${senderParticipant?.admin}`);
            
            if (!isAdmin) {
                await sock.sendMessage(from, {
                    text: `🍃 *Este comando solo puede ser usado por administradores del grupo*`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Obtener todos los participantes (excluyendo al bot)
            const allParticipants = participants
                .filter(p => p.id !== botJid && p.id !== botJid?.split(':')[0] + '@s.whatsapp.net')
                .map(p => p.id);
            
            if (allParticipants.length === 0) {
                await sock.sendMessage(from, {
                    text: `🌿 *No hay participantes para etiquetar*`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar si hay mensaje citado
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            const quotedMessage = quotedMsg?.quotedMessage;
            const quotedParticipant = quotedMsg?.participant;
            const quotedId = quotedMsg?.stanzaId;
            
            // Si hay un mensaje citado, reenviarlo con menciones
            if (quotedMessage) {
                const messageType = Object.keys(quotedMessage)[0];
                
                console.log(`[TAG] Reenviando mensaje tipo: ${messageType}`);
                
                // Crear el objeto del mensaje citado
                const quotedFullMsg = {
                    key: {
                        remoteJid: from,
                        id: quotedId,
                        participant: quotedParticipant || senderJid,
                        fromMe: false
                    },
                    message: quotedMessage
                };
                
                // IMAGEN
                if (messageType === 'imageMessage') {
                    try {
                        const buffer = await downloadMediaMessage(
                            quotedFullMsg,
                            'buffer',
                            {},
                            { 
                                logger: console,
                                reuploadRequest: sock.updateMediaMessage
                            }
                        );
                        
                        if (buffer) {
                            await sock.sendMessage(from, {
                                image: buffer,
                                caption: quotedMessage.imageMessage?.caption || '',
                                mentions: allParticipants,
                                contextInfo: {
                                    mentionedJid: allParticipants,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: 0,
                                        newsletterName: config.canalNombre || ''
                                    },
                                    forwardingScore: 9999999,
                                    isForwarded: true
                                }
                            });
                            console.log(`[TAG] Imagen reenviada con menciones`);
                        }
                    } catch (err) {
                        console.error('Error descargando imagen:', err);
                        await sock.sendMessage(from, {
                            text: `❌ Error al reenviar la imagen: ${err.message}`,
                            mentions: allParticipants,
                            contextInfo: {
                                mentionedJid: allParticipants,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                },
                                forwardingScore: 9999999,
                                isForwarded: true
                            }
                        });
                    }
                    return;
                }
                
                // VIDEO
                if (messageType === 'videoMessage') {
                    try {
                        const buffer = await downloadMediaMessage(
                            quotedFullMsg,
                            'buffer',
                            {},
                            { 
                                logger: console,
                                reuploadRequest: sock.updateMediaMessage
                            }
                        );
                        
                        if (buffer) {
                            await sock.sendMessage(from, {
                                video: buffer,
                                caption: quotedMessage.videoMessage?.caption || '',
                                mentions: allParticipants,
                                contextInfo: {
                                    mentionedJid: allParticipants,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: 0,
                                        newsletterName: config.canalNombre || ''
                                    },
                                    forwardingScore: 9999999,
                                    isForwarded: true
                                }
                            });
                            console.log(`[TAG] Video reenviado con menciones`);
                        }
                    } catch (err) {
                        console.error('Error descargando video:', err);
                        await sock.sendMessage(from, {
                            text: `❌ Error al reenviar el video: ${err.message}`,
                            mentions: allParticipants,
                            contextInfo: {
                                mentionedJid: allParticipants,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                },
                                forwardingScore: 9999999,
                                isForwarded: true
                            }
                        });
                    }
                    return;
                }
                
                // AUDIO
                if (messageType === 'audioMessage') {
                    try {
                        const buffer = await downloadMediaMessage(
                            quotedFullMsg,
                            'buffer',
                            {},
                            { 
                                logger: console,
                                reuploadRequest: sock.updateMediaMessage
                            }
                        );
                        
                        if (buffer) {
                            await sock.sendMessage(from, {
                                audio: buffer,
                                mimetype: quotedMessage.audioMessage?.mimetype || 'audio/mpeg',
                                ptt: quotedMessage.audioMessage?.ptt || false,
                                mentions: allParticipants,
                                contextInfo: {
                                    mentionedJid: allParticipants,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: 0,
                                        newsletterName: config.canalNombre || ''
                                    },
                                    forwardingScore: 9999999,
                                    isForwarded: true
                                }
                            });
                            console.log(`[TAG] Audio reenviado con menciones`);
                        }
                    } catch (err) {
                        console.error('Error descargando audio:', err);
                        await sock.sendMessage(from, {
                            text: `❌ Error al reenviar el audio: ${err.message}`,
                            mentions: allParticipants,
                            contextInfo: {
                                mentionedJid: allParticipants,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                },
                                forwardingScore: 9999999,
                                isForwarded: true
                            }
                        });
                    }
                    return;
                }
                
                // STICKER
                if (messageType === 'stickerMessage') {
                    try {
                        const buffer = await downloadMediaMessage(
                            quotedFullMsg,
                            'buffer',
                            {},
                            { 
                                logger: console,
                                reuploadRequest: sock.updateMediaMessage
                            }
                        );
                        
                        if (buffer) {
                            await sock.sendMessage(from, {
                                sticker: buffer,
                                mentions: allParticipants,
                                contextInfo: {
                                    mentionedJid: allParticipants,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: 0,
                                        newsletterName: config.canalNombre || ''
                                    },
                                    forwardingScore: 9999999,
                                    isForwarded: true
                                }
                            });
                            console.log(`[TAG] Sticker reenviado con menciones`);
                        }
                    } catch (err) {
                        console.error('Error descargando sticker:', err);
                        await sock.sendMessage(from, {
                            text: `❌ Error al reenviar el sticker: ${err.message}`,
                            mentions: allParticipants,
                            contextInfo: {
                                mentionedJid: allParticipants,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                },
                                forwardingScore: 9999999,
                                isForwarded: true
                            }
                        });
                    }
                    return;
                }
                
                // DOCUMENTO
                if (messageType === 'documentMessage') {
                    try {
                        const buffer = await downloadMediaMessage(
                            quotedFullMsg,
                            'buffer',
                            {},
                            { 
                                logger: console,
                                reuploadRequest: sock.updateMediaMessage
                            }
                        );
                        
                        if (buffer) {
                            await sock.sendMessage(from, {
                                document: buffer,
                                fileName: quotedMessage.documentMessage?.fileName || 'documento',
                                mimetype: quotedMessage.documentMessage?.mimetype || 'application/octet-stream',
                                mentions: allParticipants,
                                contextInfo: {
                                    mentionedJid: allParticipants,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: 0,
                                        newsletterName: config.canalNombre || ''
                                    },
                                    forwardingScore: 9999999,
                                    isForwarded: true
                                }
                            });
                            console.log(`[TAG] Documento reenviado con menciones`);
                        }
                    } catch (err) {
                        console.error('Error descargando documento:', err);
                        await sock.sendMessage(from, {
                            text: `❌ Error al reenviar el documento: ${err.message}`,
                            mentions: allParticipants,
                            contextInfo: {
                                mentionedJid: allParticipants,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                },
                                forwardingScore: 9999999,
                                isForwarded: true
                            }
                        });
                    }
                    return;
                }
                
                // TEXTO
                if (messageType === 'conversation' || messageType === 'extendedTextMessage') {
                    const quotedText = quotedMessage.conversation || quotedMessage.extendedTextMessage?.text || '';
                    
                    await sock.sendMessage(from, {
                        text: quotedText,
                        mentions: allParticipants,
                        contextInfo: {
                            mentionedJid: allParticipants,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            },
                            forwardingScore: 9999999,
                            isForwarded: true
                        }
                    });
                    console.log(`[TAG] Texto reenviado con menciones`);
                    return;
                }
                
                // Si no se reconoce el tipo
                await sock.sendMessage(from, {
                    text: `🌿 *Tipo de mensaje no soportado para reenviar*`,
                    mentions: allParticipants,
                    contextInfo: {
                        mentionedJid: allParticipants,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                });
                
            } else {
                // No hay mensaje citado, enviar solo texto con args
                const texto = args.join(' ').trim();
                
                if (!texto) {
                    await sock.sendMessage(from, {
                        text: `🌾 *Debes escribir un mensaje para etiquetar o responder a un mensaje*\n\nEjemplo: ${config.prefix}tag Reunión importante`,
                        contextInfo: {
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            },
                            forwardingScore: 9999999,
                            isForwarded: true
                        }
                    }, { quoted: msg });
                    return;
                }
                
                await sock.sendMessage(from, {
                    text: texto,
                    mentions: allParticipants,
                    contextInfo: {
                        mentionedJid: allParticipants,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                });
            }
            
        } catch (error) {
            console.error('Error en comando tag:', error);
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `🌿 *Ocurrió un error al etiquetar a los miembros*\n\n> ${error.message}`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};