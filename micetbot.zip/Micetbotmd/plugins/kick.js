export default {
    name: 'kick',
    alias: ['echar', 'ban'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, args, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                await replyWithContext(`🌸 Este comando solo puede usarse en grupos.`, []);
                return;
            }
            
            let groupMetadata;
            try {
                groupMetadata = await sock.groupMetadata(from);
            } catch (error) {
                await replyWithContext(`❌ Error al obtener información del grupo`, []);
                return;
            }
            
            // Función para limpiar JID (eliminar :0 y cualquier cosa después de @)
            function cleanJid(jid) {
                if (!jid) return null;
                // Eliminar :0 o : cualquier número antes del @
                let cleaned = jid.replace(/:\d+@/, '@');
                return cleaned;
            }
            
            // Función para extraer número de teléfono de cualquier JID
            function extractNumber(jid) {
                if (!jid) return null;
                let cleaned = cleanJid(jid);
                let number = cleaned.split('@')[0];
                return number.replace(/[^0-9]/g, '');
            }
            
            // Verificar si el usuario es admin del grupo
            const senderCleanJid = cleanJid(senderJid);
            const isGroupAdmin = groupMetadata.participants.find(p => {
                const pClean = cleanJid(p.id);
                return pClean === senderCleanJid || p.id === senderJid;
            })?.admin;
            
            // Verificar si es owner del bot
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            // Verificar si tiene rango en el bot
            const userData = usersDB[senderNumber];
            const userRank = userData?.rank;
            const hasBotRank = isOwner || (userRank && ['owner', 'c-owner', 'srmod', 'mod'].includes(userRank));
            
            if (!isGroupAdmin && !hasBotRank) {
                await replyWithContext(
                    `🍁 Solo administradores del grupo pueden usar este comando.`,
                    []
                );
                return;
            }
            
            // Obtener usuario objetivo
            let targetUserJid = null;
            let targetUserNumber = null;
            
            // 1. Verificar mención
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
                targetUserJid = cleanJid(targetUserJid);
                targetUserNumber = extractNumber(targetUserJid);
                console.log(`✅ Usuario mencionado: ${targetUserJid} -> Número: ${targetUserNumber}`);
            }
            // 2. Verificar respuesta (stanzaId)
            else if (msg.message?.extendedTextMessage?.contextInfo?.stanzaId) {
                const quotedMsg = msg.message.extendedTextMessage.contextInfo;
                if (quotedMsg.participant) {
                    targetUserJid = cleanJid(quotedMsg.participant);
                    targetUserNumber = extractNumber(targetUserJid);
                    console.log(`✅ Usuario por respuesta: ${targetUserJid} -> Número: ${targetUserNumber}`);
                }
            }
            // 3. Verificar si hay número en args
            else if (args && args.length > 0) {
                const possibleNumber = args[0].replace(/[^0-9]/g, '');
                if (possibleNumber && possibleNumber.length > 8) {
                    targetUserNumber = possibleNumber;
                    // Buscar el JID en el grupo
                    const found = groupMetadata.participants.find(p => {
                        const pNumber = extractNumber(p.id);
                        return pNumber === targetUserNumber;
                    });
                    if (found) targetUserJid = cleanJid(found.id);
                }
            }
            
            if (!targetUserJid || !targetUserNumber) {
                await replyWithContext(
                    `🌠 *Debes responder, mencionar o escribir el número del usuario*\n> Ejemplo: ${config.prefix}kick @usuario\n> Ejemplo: ${config.prefix}kick 5219992042946`,
                    []
                );
                return;
            }
            
            // Verificar si el usuario objetivo está en el grupo
            const targetParticipant = groupMetadata.participants.find(p => {
                const pNumber = extractNumber(p.id);
                const pClean = cleanJid(p.id);
                return pNumber === targetUserNumber || pClean === targetUserJid;
            });
            
            if (!targetParticipant) {
                await replyWithContext(
                    `🌺 El usuario no está en el grupo`,
                    []
                );
                return;
            }
            
            // Verificar que no se esté intentando eliminar al bot
            const botJid = sock.user?.id ? cleanJid(sock.user.id) : null;
            const botNumber = extractNumber(botJid);
            if (targetUserNumber === botNumber) {
                await replyWithContext(
                    `🍁 No se puede eliminar a ${config.name}`,
                    []
                );
                return;
            }
            
            // Verificar si el usuario es admin (no se puede eliminar admin)
            if (targetParticipant.admin) {
                await replyWithContext(
                    `🍁 @${targetUserNumber} es administrador del grupo\n> No se puede eliminar a administradores del grupo.`,
                    [targetParticipant.id]
                );
                return;
            }
            
            try {
                await sock.groupParticipantsUpdate(from, [targetParticipant.id], 'remove');
                
                await replyWithContext(
                    `🍁 @${targetUserNumber} *ha sido eliminado del grupo*`,
                    [targetParticipant.id]
                );
                
                console.log(`✅ Usuario ${targetUserNumber} eliminado por ${senderNumber}`);
                
            } catch (error) {
                console.log(`❌ Error en kick: ${error.message}`);
                
                if (error.message.includes('not authorized') || error.message.includes('forbidden') || error.message.includes('admin')) {
                    await replyWithContext(
                        `🌠 *${config.name}* debe ser administrador del grupo para eliminar a un usuario.`,
                        []
                    );
                } else {
                    await replyWithContext(
                        `🌠 *${config.name}* debe ser administrador del grupo para eliminar un usuario.`,
                        []
                    );
                }
            }
            
        } catch (error) {
            console.error('❌ Error en kick:', error);
            await options.replyWithContext(`❌ Error: ${error.message}`, []);
        }
    }
};