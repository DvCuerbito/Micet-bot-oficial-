import fetch from 'node-fetch';

export default {
    name: 'pfp',
    alias: ['profilepic'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            console.log(`\n📸 ===== PFP COMANDO =====`);
            console.log(`📸 Usuario: ${pushName || senderNumber}`);
            
            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, {
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);
            
            let targetUserJid = null;
            let targetUserNumber = null;
            
            // 1. DETECTAR USUARIO OBJETIVO
            // a) Si hay args y el primer argumento parece un número (funcionalidad secreta)
            if (args && args[0] && /^\d+$/.test(args[0])) {
                targetUserNumber = args[0];
                targetUserJid = targetUserNumber + '@s.whatsapp.net';
                console.log(`📨 Número directo: ${targetUserNumber}`);
            }
            // b) Respuesta a mensaje
            else if (msg.message?.extendedTextMessage?.contextInfo?.participant) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.participant;
                targetUserNumber = targetUserJid.split('@')[0];
                console.log(`📨 Respuesta a: ${targetUserNumber}`);
            }
            // c) Mención con @
            else if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
                targetUserNumber = targetUserJid.split('@')[0];
                console.log(`📨 Mención: ${targetUserNumber}`);
            }
            // d) Si no hay ni respuesta ni mención, usar el propio usuario
            else {
                targetUserJid = senderJid;
                targetUserNumber = senderNumber;
                console.log(`📨 Usuario propio: ${targetUserNumber}`);
            }
            
            // 2. INTENTAR OBTENER FOTO DE PERFIL
            console.log(`🔄 Obteniendo foto para: ${targetUserNumber}`);
            
            let profilePicture = null;
            
            try {
                profilePicture = await sock.profilePictureUrl(targetUserJid, 'image');
                console.log(`✅ Foto obtenida: ${profilePicture}`);
            } catch (error) {
                console.log(`❌ Error: ${error.message}`);
                
                // Verificar si es error 404 (sin foto)
                if (error.message.includes('404') || 
                    error.message.includes('not found') ||
                    error.message.includes('no picture')) {
                    
                    console.log(`ℹ️ Usuario sin foto de perfil`);
                    
                    // Mensaje específico para usuario sin foto
                    await sock.sendMessage(from, {
                        text: `> 🍁 El usuario no tiene foto de perfil.`,
                        contextInfo: {
                            mentionedJid: [targetUserJid],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    return;
                } else {
                    // Otro error
                    throw error;
                }
            }
            
            if (!profilePicture) {
                console.log(`❌ No se pudo obtener URL de foto`);
                await sock.sendMessage(from, {
                    text: `> 🍁 No se pudo obtener la foto de perfil del usuario.`,
                    contextInfo: {
                        mentionedJid: [targetUserJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // 3. DESCARGAR IMAGEN
            console.log(`🔄 Descargando imagen...`);
            
            try {
                const imageResponse = await fetch(profilePicture);
                
                if (!imageResponse.ok) {
                    throw new Error(`HTTP ${imageResponse.status}`);
                }
                
                const imageBuffer = await imageResponse.buffer();
                console.log(`✅ Imagen descargada: ${imageBuffer.length} bytes`);
                
                // Preparar contexto del mensaje
                const contextInfo = {
                    mentionedJid: [targetUserJid, senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                };
                
                // Obtener nombre del usuario para el caption (opcional)
                const targetName = usersDB[targetUserNumber]?.pushName || 
                                  usersDB[targetUserNumber]?.name || 
                                  targetUserNumber;
                
                // ENVIAR IMAGEN CON CAPTION SIMPLE
                await sock.sendMessage(from, {
                    image: imageBuffer,
                    caption: `> Usuario: @${targetUserNumber}`,
                    contextInfo: contextInfo
                }, { quoted: msg });
                
                console.log(`✅ Foto enviada exitosamente`);
                
            } catch (downloadError) {
                console.log(`❌ Error descargando: ${downloadError.message}`);
                
                await sock.sendMessage(from, {
                    text: `> 🦋 No se pudo descargar la foto de perfil.`,
                    contextInfo: {
                        mentionedJid: [targetUserJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
        } catch (error) {
            console.error('❌ Error en comando pfp:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `> 🦋 No se pudo obtener la foto de perfil del usuario.\nError: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
};