import fetch from 'node-fetch';

export default {
  name: 'ssweb',
  alias: ['ss'],
  
  async execute(sock, msg, options) {
    const { args, config, replyWithContext, senderJid } = options;
    const from = msg.key.remoteJid;
    const query = args.join(' ').trim();

    if (!query) {
      return await replyWithContext(
        '❀ Por favor, ingrese el Link de una página.',
        [senderJid]
      );
    }

    try {
      const ss = await (await fetch(`https://image.thum.io/get/fullpage/${query}`)).buffer();
      await sock.sendMessage(from, { image: ss, caption: query }, { quoted: msg });
    } catch (error) {
      return await replyWithContext(
        `> An unexpected error occurred while executing command *${config.prefix}ssweb*. Please try again or contact support if the issue persists.\n> [Error: *${error.message}*]`,
        [senderJid]
      );
    }
  }
};