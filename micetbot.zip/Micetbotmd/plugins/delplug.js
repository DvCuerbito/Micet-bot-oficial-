import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const OWNER_NUMBER = "5219992042946";

export default {
    name: 'delplug',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar si el usuario es el owner (por número)
            const isOwner = senderNumber === OWNER_NUMBER;
            
            if (!isOwner) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}delplug\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar si se proporcionó nombre de archivo
            if (args.length < 1) {
                await sock.sendMessage(from, {
                    text: `🌠 Debe proporcionar el nombre del archivo\n> Ejemplo: ${config.prefix}delplug ping.js`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            const archivo = args[0];
            
            // Asegurar que termina en .js
            const fileName = archivo.endsWith('.js') ? archivo : `${archivo}.js`;
            
            // Ruta completa al archivo
            const rutaArchivo = path.join(process.cwd(), 'plugins', fileName);
            
            try {
                // Verificar si el archivo existe
                if (!fs.existsSync(rutaArchivo)) {
                    await sock.sendMessage(from, {
                        text: `🌠 El archivo ${fileName} no existe`,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    return;
                }
                
                // Eliminar el archivo
                fs.unlinkSync(rutaArchivo);
                
                await sock.sendMessage(from, {
                    text: `🌠 El archivo ${fileName} ha sido eliminado con éxito`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
                console.log(`✅ Plugin eliminado: ${fileName} por ${pushName || senderNumber}`);
                
            } catch (error) {
                console.error('Error eliminando plugin:', error);
                
                await sock.sendMessage(from, {
                    text: `🌠 Error al eliminar el archivo ${fileName}\n> ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
        } catch (error) {
            console.error('❌ Error en delplug:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ *Error:* ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config?.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config?.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
};
