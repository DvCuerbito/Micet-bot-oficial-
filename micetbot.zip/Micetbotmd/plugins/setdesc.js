import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERS_FILE = path.join(__dirname, '..', 'databases', 'users.json');

function loadUsersDB() {
    try {
        if (fs.existsSync(USERS_FILE)) {
            return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando users.json:', error);
        return {};
    }
}

function saveUsersDB(users) {
    try {
        fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando users.json:', error);
        return false;
    }
}

export default {
    name: 'setdesc',
    alias: ['setdescription'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderNumber, senderJid, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const description = args.join(' ').trim();
            
            if (!description) {
                await replyWithContext(
                    `🌟 Debes proporcionar una descripción`,
                    []
                );
                return;
            }
            
            if (description.length > 150) {
                await replyWithContext(
                    `🌵 La descripción no puede tener más de 150 caracteres`,
                    []
                );
                return;
            }
            
            const users = loadUsersDB();
            
            if (!users[senderNumber]) {
                users[senderNumber] = {
                    number: senderNumber,
                    pushName: pushName || 'Usuario',
                    registered: new Date().toISOString()
                };
            }
            
            users[senderNumber].description = description;
            saveUsersDB(users);
            
            await replyWithContext(
                `🌵 Descripción establecida con éxito`,
                []
            );
            
        } catch (error) {
            console.error('❌ Error en setdesc:', error);
            await replyWithContext(`❌ Error: ${error.message}`, []);
        }
    }
};