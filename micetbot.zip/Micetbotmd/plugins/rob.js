import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 0,
            bank: 0,
            lastRob: 0
        };
    }
    if (economy[userNumber].bank === undefined) economy[userNumber].bank = 0;
    if (economy[userNumber].lastRob === undefined) economy[userNumber].lastRob = 0;
    return economy[userNumber];
}

function formatCooldown(timestamp) {
    const now = Date.now();
    const diff = timestamp - now;
    if (diff <= 0) return 'Listo';
    const minutes = Math.floor(diff / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    return `${minutes}m ${seconds}s`;
}

export default {
    name: 'rob',
    alias: ['robar'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderNumber, pushName, replyWithContext, senderJid, usersDB } = options;
            const from = msg.key.remoteJid;
            
            if (!senderNumber) {
                return await replyWithContext('❌ No se pudo identificar tu número', [senderJid]);
            }
            
            // Obtener usuario objetivo (mención o respuesta)
            let targetJid = null;
            let targetNumber = null;
            let targetName = null;
            
            const mencionado = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
            
            if (mencionado) {
                targetJid = mencionado;
                targetNumber = mencionado.split('@')[0];
                targetName = usersDB?.[targetNumber]?.pushName || 'Usuario';
            } else if (quotedParticipant) {
                targetJid = quotedParticipant;
                targetNumber = quotedParticipant.split('@')[0];
                targetName = usersDB?.[targetNumber]?.pushName || 'Usuario';
            } else if (args[0]) {
                targetNumber = args[0].replace(/[^0-9]/g, '');
                if (targetNumber) {
                    targetJid = `${targetNumber}@s.whatsapp.net`;
                    targetName = usersDB?.[targetNumber]?.pushName || 'Usuario';
                }
            }
            
            if (!targetNumber || targetNumber === senderNumber) {
                return await replyWithContext(
                    `🍭 *Debes mencionar o responder a un usuario para robarle*\n\n` +
                    `> Ejemplo: ${config.prefix}rob @usuario`,
                    [senderJid]
                );
            }
            
            let economy = loadEconomy();
            const user = initUserEconomy(economy, senderNumber, pushName);
            const target = initUserEconomy(economy, targetNumber, targetName);
            
            // Verificar cooldown (1 hora = 3600000 ms)
            const cooldownTime = 3600000;
            const now = Date.now();
            
            if (user.lastRob && (now - user.lastRob) < cooldownTime) {
                const remaining = cooldownTime - (now - user.lastRob);
                const minutes = Math.floor(remaining / 60000);
                const seconds = Math.floor((remaining % 60000) / 1000);
                return await replyWithContext(
                    `⏰ *Debes esperar para volver a robar*\n\n` +
                    `> Tiempo restante: ${minutes}m ${seconds}s`,
                    [senderJid]
                );
            }
            
            // Verificar que la víctima tenga coins fuera del banco
            if (!target.coins || target.coins <= 0) {
                return await replyWithContext(
                    `❌ *${target.name} no tiene coins para robar*\n\n` +
                    `> Solo se pueden robar coins que no están en el banco`,
                    [targetJid, senderJid]
                );
            }
            
            // Calcular cantidad a robar (10-30% de los coins de la víctima)
            const minPercent = 0.10;
            const maxPercent = 0.30;
            const percent = minPercent + Math.random() * (maxPercent - minPercent);
            let robAmount = Math.floor(target.coins * percent);
            
            // Mínimo 1 coin, máximo 5000
            robAmount = Math.max(1, Math.min(robAmount, 5000));
            
            // Probabilidad de éxito (70%)
            const success = Math.random() < 0.7;
            
            if (success) {
                // Robo exitoso
                target.coins -= robAmount;
                user.coins += robAmount;
                user.lastRob = now;
                saveEconomy(economy);
                
                await replyWithContext(
                    `🦹 *¡Robo exitoso!*\n\n` +
                    `> 🎯 *Víctima:* ${target.name}\n` +
                    `> 💰 *Robaste:* ${robAmount.toLocaleString()} coins\n` +
                    `> 💵 *Coins de ${target.name}:* ${target.coins.toLocaleString()} coins\n` +
                    `> 💎 *Tus coins:* ${user.coins.toLocaleString()} coins\n\n` +
                    `⏰ *Próximo robo en:* 1 hora`,
                    [targetJid, senderJid]
                );
            } else {
                // Robo fallido, pierdes 5-15% de tus coins
                const penaltyPercent = 0.05 + Math.random() * 0.10;
                let penalty = Math.floor(user.coins * penaltyPercent);
                penalty = Math.max(1, Math.min(penalty, 1000));
                
                user.coins -= penalty;
                if (user.coins < 0) user.coins = 0;
                user.lastRob = now;
                saveEconomy(economy);
                
                await replyWithContext(
                    `😭 *¡Robo fallido!*\n\n` +
                    `> 🎯 *Intentaste robar a:* ${target.name}\n` +
                    `> 💸 *Perdiste:* ${penalty.toLocaleString()} coins\n` +
                    `> 💰 *Te quedan:* ${user.coins.toLocaleString()} coins\n\n` +
                    `⏰ *Próximo intento en:* 1 hora`,
                    [targetJid, senderJid]
                );
            }
            
        } catch (error) {
            console.error('❌ Error en rob:', error);
            await options.replyWithContext(`❌ Error: ${error.message}`, [options.senderJid]);
        }
    }
};
