import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 0,
            minerals: {
                piedras: 0,
                diamantes: 0,
                esmeraldas: 0,
                oro: 0,
                rubies: 0,
                zafiros: 0,
                fosiles: 0,
                arcilla: 0,
                carbon: 0,
                hierro: 0
            },
            health: 100,
            lastMine: 0,
            lastWork: 0,
            lastCrime: 0,
            lastAdventure: 0,
            lastClaim: 0,
            lastChest: 0,
            lastHunt: 0,
            lastFish: 0,
            lastExcavar: 0,
            lastTesoro: 0,
            lastReciclar: 0,
            lastMina2: 0,
            lastMina3: 0,
            items: {
                agua: 0,
                vendas: 0,
                pastillas: 0,
                pico: 1,
                mapa: 0,
                pala: 1
            }
        };
    }
    return economy[userNumber];
}

function getRemainingTime(lastUsed, cooldownMs = 60000) { // 1 minuto
    const now = Date.now();
    const timePassed = now - lastUsed;
    
    if (timePassed >= cooldownMs) return 0;
    
    const remaining = cooldownMs - timePassed;
    const seconds = Math.floor(remaining / 1000);
    
    return `${seconds}s`;
}

// Opciones de reciclaje
const recycling = [
    {
        name: "*Reciclar Piedras*",
        requires: { piedras: 10 },
        gives: { coins: 5, arcilla: 2 },
        emoji: "🪨"
    },
    {
        name: "*Reciclar Arcilla*",
        requires: { arcilla: 5 },
        gives: { coins: 8, piedras: 10 },
        emoji: "🧱"
    },
    {
        name: "*Reciclar Hierro*",
        requires: { hierro: 3 },
        gives: { coins: 15, carbon: 2 },
        emoji: "⛓️"
    },
    {
        name: "*Reciclar Oro*",
        requires: { oro: 2 },
        gives: { coins: 25, diamantes: 1 },
        emoji: "🪙"
    },
    {
        name: "*Reciclar Diamantes*",
        requires: { diamantes: 1 },
        gives: { coins: 40, rubies: 1 },
        emoji: "💎"
    },
    {
        name: "*Reciclar Esmeraldas*",
        requires: { esmeraldas: 2 },
        gives: { coins: 30, zafiros: 1 },
        emoji: "💚"
    },
    {
        name: "*Reciclar Agua*",
        requires: { agua: 3 },
        gives: { coins: 10, vendas: 1 },
        emoji: "🍶"
    },
    {
        name: "*Reciclar Vendas*",
        requires: { vendas: 2 },
        gives: { coins: 15, pastillas: 1 },
        emoji: "🩹"
    },
    {
        name: "*Reciclar Pastillas*",
        requires: { pastillas: 2 },
        gives: { coins: 20, agua: 2 },
        emoji: "💊"
    },
    {
        name: "*Reciclar Mapas*",
        requires: { mapa: 1 },
        gives: { coins: 50, diamantes: 2, oro: 5 },
        emoji: "🗺️"
    }
];

export default {
    name: 'reciclar',
    alias: ['recycle', 'reciclaje'],
    
    async execute(sock, msg, options) {
        try {
            const { 
                config, 
                senderNumber, 
                pushName,
                replyWithContext,
                senderJid,
                args 
            } = options;
            
            if (!senderNumber) {
                return await replyWithContext(
                    '❌ No se pudo identificar tu número',
                    [senderJid]
                );
            }
            
            // Si no hay argumentos, mostrar opciones
            if (!args || args.length === 0) {
                let recycleText = `♻️ *RECICLAJE*\n\n`;
                
                for (const item of recycling) {
                    const reqText = Object.entries(item.requires)
                        .map(([k, v]) => `${v} ${k}`).join(' + ');
                    
                    const giveText = Object.entries(item.gives)
                        .map(([k, v]) => `${v} ${k}`).join(' + ');
                    
                    recycleText += `${item.emoji} ${item.name}\n`;
                    recycleText += `└ Entrega: ${reqText} → Recibe: ${giveText}\n\n`;
                }
                
                recycleText += `> *Uso:* ${config.prefix}reciclar [número]\n` +
                    `> *Ejemplo:* ${config.prefix}reciclar 1 (para reciclar piedras)`;
                
                return await replyWithContext(recycleText, [senderJid]);
            }
            
            let economy = loadEconomy();
            const user = initUserEconomy(economy, senderNumber, pushName);
            
            // Verificar cooldown
            const cooldownTime = 60000; // 1 minuto
            const now = Date.now();
            
            if (user.lastReciclar && (now - user.lastReciclar) < cooldownTime) {
                const remaining = getRemainingTime(user.lastReciclar, cooldownTime);
                return await replyWithContext(
                    `⏳ *Debes esperar ${remaining}* para volver a reciclar`,
                    [senderJid]
                );
            }
            
            // Obtener opción
            const option = parseInt(args[0]) - 1;
            
            if (isNaN(option) || option < 0 || option >= recycling.length) {
                return await replyWithContext(
                    '❌ Opción no válida',
                    [senderJid]
                );
            }
            
            const selected = recycling[option];
            
            // Verificar si tiene los recursos
            let hasResources = true;
            for (const [resource, amount] of Object.entries(selected.requires)) {
                if (resource === 'piedras' && (user.minerals.piedras || 0) < amount) hasResources = false;
                else if (resource === 'arcilla' && (user.minerals.arcilla || 0) < amount) hasResources = false;
                else if (resource === 'hierro' && (user.minerals.hierro || 0) < amount) hasResources = false;
                else if (resource === 'oro' && (user.minerals.oro || 0) < amount) hasResources = false;
                else if (resource === 'diamantes' && (user.minerals.diamantes || 0) < amount) hasResources = false;
                else if (resource === 'esmeraldas' && (user.minerals.esmeraldas || 0) < amount) hasResources = false;
                else if (resource === 'agua' && (user.items.agua || 0) < amount) hasResources = false;
                else if (resource === 'vendas' && (user.items.vendas || 0) < amount) hasResources = false;
                else if (resource === 'pastillas' && (user.items.pastillas || 0) < amount) hasResources = false;
                else if (resource === 'mapa' && (user.items.mapa || 0) < amount) hasResources = false;
            }
            
            if (!hasResources) {
                return await replyWithContext(
                    '❌ No tienes suficientes recursos para este reciclaje',
                    [senderJid]
                );
            }
            
            user.lastReciclar = now;
            
            // Quitar recursos
            for (const [resource, amount] of Object.entries(selected.requires)) {
                if (resource === 'piedras') user.minerals.piedras -= amount;
                else if (resource === 'arcilla') user.minerals.arcilla -= amount;
                else if (resource === 'hierro') user.minerals.hierro -= amount;
                else if (resource === 'oro') user.minerals.oro -= amount;
                else if (resource === 'diamantes') user.minerals.diamantes -= amount;
                else if (resource === 'esmeraldas') user.minerals.esmeraldas -= amount;
                else if (resource === 'agua') user.items.agua -= amount;
                else if (resource === 'vendas') user.items.vendas -= amount;
                else if (resource === 'pastillas') user.items.pastillas -= amount;
                else if (resource === 'mapa') user.items.mapa -= amount;
            }
            
            // Dar recompensas
            let giveText = '';
            for (const [resource, amount] of Object.entries(selected.gives)) {
                if (resource === 'coins') user.coins += amount;
                else if (resource === 'piedras') user.minerals.piedras += amount;
                else if (resource === 'arcilla') user.minerals.arcilla += amount;
                else if (resource === 'carbon') user.minerals.carbon += amount;
                else if (resource === 'hierro') user.minerals.hierro += amount;
                else if (resource === 'oro') user.minerals.oro += amount;
                else if (resource === 'diamantes') user.minerals.diamantes += amount;
                else if (resource === 'esmeraldas') user.minerals.esmeraldas += amount;
                else if (resource === 'rubies') user.minerals.rubies += amount;
                else if (resource === 'zafiros') user.minerals.zafiros += amount;
                else if (resource === 'agua') user.items.agua += amount;
                else if (resource === 'vendas') user.items.vendas += amount;
                else if (resource === 'pastillas') user.items.pastillas += amount;
                
                const emoji = resource === 'coins' ? '💰' :
                             resource === 'piedras' ? '🪨' :
                             resource === 'arcilla' ? '🧱' :
                             resource === 'carbon' ? '🪨' :
                             resource === 'hierro' ? '⛓️' :
                             resource === 'oro' ? '🪙' :
                             resource === 'diamantes' ? '💎' :
                             resource === 'esmeraldas' ? '💚' :
                             resource === 'rubies' ? '🔴' :
                             resource === 'zafiros' ? '🔵' :
                             resource === 'agua' ? '🍶' :
                             resource === 'vendas' ? '🩹' :
                             resource === 'pastillas' ? '💊' : '📦';
                
                giveText += `${emoji} *+${amount}* ${resource}\n`;
            }
            
            saveEconomy(economy);
            
            const reciclarText = `♻️ *RECICLAJE EXITOSO*\n\n` +
                `${selected.emoji} *${selected.name}*\n\n` +
                `🎁 *Recibiste:*\n${giveText}`;
            
            await replyWithContext(reciclarText, [senderJid]);
            
        } catch (error) {
            console.error('❌ Error en comando reciclar:', error);
        }
    }
};
