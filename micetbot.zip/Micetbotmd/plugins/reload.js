import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'reload',
    alias: ['recargar', 'refresh'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar si el usuario es el owner
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isOwner) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}reload\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Mensaje de procesando
            await sock.sendMessage(from, {
                text: `🌠 Recargando plugins...`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
            
            try {
                // Obtener la carpeta de plugins
                const pluginsDir = path.join(process.cwd(), 'plugins');
                
                if (!fs.existsSync(pluginsDir)) {
                    await sock.sendMessage(from, {
                        text: `🌠 No se encontró la carpeta de plugins`,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    return;
                }
                
                // Obtener todos los archivos .js
                const pluginFiles = fs.readdirSync(pluginsDir).filter(file => file.endsWith('.js'));
                
                let successCount = 0;
                let failCount = 0;
                const failedPlugins = [];
                
                // Limpiar el cache de importación para cada plugin
                for (const file of pluginFiles) {
                    try {
                        const filePath = path.join(pluginsDir, file);
                        const fileUrl = `file://${filePath}`;
                        
                        // Limpiar del cache de importación
                        const resolvedPath = fileUrl + '?update=' + Date.now();
                        
                        // Intentar importar para verificar que funciona
                        const pluginModule = await import(resolvedPath);
                        const pluginData = pluginModule.default || pluginModule;
                        
                        if (pluginData && pluginData.name) {
                            successCount++;
                        } else {
                            failCount++;
                            failedPlugins.push(`${file} (sin nombre)`);
                        }
                        
                        // Pequeña pausa para no sobrecargar
                        await new Promise(resolve => setTimeout(resolve, 10));
                        
                    } catch (error) {
                        failCount++;
                        failedPlugins.push(`${file} (${error.message.substring(0, 30)}...)`);
                        console.error(`❌ Error recargando ${file}:`, error.message);
                    }
                }
                
                // Mensaje de resultado
                let resultMessage = `🌠 *Plugins Recargados*\n> Funcionando » ${successCount} / Con bugs » ${failCount}`;
                
                if (failCount > 0 && failedPlugins.length > 0) {
                    resultMessage += `\n\n❌ *Plugins con error:*\n`;
                    failedPlugins.forEach((plugin, index) => {
                        if (index < 5) { // Mostrar solo los primeros 5
                            resultMessage += `> ${plugin}\n`;
                        }
                    });
                    if (failedPlugins.length > 5) {
                        resultMessage += `> ... y ${failedPlugins.length - 5} más`;
                    }
                }
                
                await sock.sendMessage(from, {
                    text: resultMessage,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
                console.log(`✅ Plugins recargados por OWNER: ${pushName || senderNumber} - Éxito: ${successCount}, Fallos: ${failCount}`);
                
            } catch (error) {
                console.error('Error en reload:', error);
                await sock.sendMessage(from, {
                    text: `🌠 Error al recargar plugins: ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
        } catch (error) {
            console.error('❌ Error en reload:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ *Error:* ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
};
