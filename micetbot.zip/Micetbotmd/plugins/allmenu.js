import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let botStartTime = Date.now();

// Función para obtener la hora y saludo según horario de México (Mérida)
function getMexicoTimeAndGreeting() {
    // Opciones para hora de México (GMT-6, Mérida está en GMT-6 sin horario de verano)
    const options = {
        timeZone: 'America/Merida',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
    };
    
    const mexicoTime = new Date().toLocaleString('es-MX', options);
    
    // Obtener hora actual en México para determinar el saludo
    const mexicoDate = new Date().toLocaleString('en-US', { timeZone: 'America/Merida' });
    const mexicoHour = new Date(mexicoDate).getHours();
    
    let greeting = '';
    
    if (mexicoHour >= 5 && mexicoHour < 12) {
        greeting = 'Buenos días 🏙️';
    } else if (mexicoHour >= 12 && mexicoHour < 19) {
        greeting = 'Buenas tardes 🌆';
    } else {
        greeting = 'Buenas noches 🌃';
    }
    
    return {
        time: mexicoTime,
        greeting: greeting
    };
}

export default {
    name: 'allmenu',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, sender, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // ==========================================
            // OBTENER NÚMERO DEL BOT
            // ==========================================
            let botNumber = '';
            
            if (sock.phoneNumber) {
                botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            // ==========================================
            // CARGAR CONFIGURACIÓN DESDE INFO/{NÚMERO}/CONFIG.JS
            // ==========================================
            let botConfig = { ...config }; // Config por defecto como respaldo
            let configLoaded = false;
            
            if (botNumber) {
                const configPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
                
                if (fs.existsSync(configPath)) {
                    try {
                        const configContent = fs.readFileSync(configPath, 'utf8');
                        const jsonMatch = configContent.match(/export default\s+({[\s\S]*})/);
                        
                        if (jsonMatch && jsonMatch[1]) {
                            const infoConfig = eval('(' + jsonMatch[1] + ')');
                            
                            if (infoConfig) {
                                botConfig = infoConfig;
                                configLoaded = true;
                                console.log(`✅ Menú usando config de info/${botNumber}/config.js`);
                            }
                        }
                    } catch (readError) {
                        console.log(`⚠️ Error leyendo config para menú:`, readError.message);
                    }
                }
            }
            
            // Calcular uptime
            const uptime = Date.now() - botStartTime;
            const uptimeText = this.formatUptime(uptime);
            
            // Obtener hora y saludo de México
            const { time: mexicoTime, greeting } = getMexicoTimeAndGreeting();
            
            // Contar usuarios registrados
            const totalUsers = Object.keys(usersDB || {}).length;
            
            // Cargar comandos desde la carpeta plugins
            const pluginsDir = path.join(__dirname, '..', 'plugins');
            let pluginFiles = [];
            let commandMap = new Map();
            
            try {
                if (fs.existsSync(pluginsDir)) {
                    pluginFiles = fs.readdirSync(pluginsDir).filter(file => file.endsWith('.js'));
                    
                    for (const file of pluginFiles) {
                        try {
                            const filePath = path.join(pluginsDir, file);
                            const fileUrl = `file://${filePath}`;
                            const pluginModule = await import(fileUrl + '?update=' + Date.now());
                            const pluginData = pluginModule.default || pluginModule;
                            
                            if (pluginData && pluginData.name) {
                                commandMap.set(pluginData.name, {
                                    name: pluginData.name,
                                    alias: pluginData.alias || []
                                });
                            }
                        } catch (error) {
                            console.log(`⚠️ Error cargando ${file} para menú:`, error.message);
                        }
                    }
                }
            } catch (error) {
                console.error('Error leyendo carpeta plugins:', error);
            }
            
            const pluginCount = pluginFiles.length;
            
            // Cargar menú y descripciones
            const menuPath = path.join(__dirname, '..', 'databases', 'menu.json');
            let menuData = { 
                categories: [], 
                banner: 'img/banner.jpg',
                commandDescriptions: {},
                categoryDescriptions: {}
            };
            
            try {
                if (fs.existsSync(menuPath)) {
                    const data = fs.readFileSync(menuPath, 'utf8');
                    menuData = JSON.parse(data);
                }
            } catch (error) {
                console.error('Error cargando menú:', error);
            }
            
            // Verificar si se pidió una categoría específica
            let categoriesToShow = menuData.categories || [];
            let isSpecificCategory = false;
            let categoryTitle = "CATEGORÍAS";
            
            if (args && args.length > 0) {
                const categoryRequested = args[0].toLowerCase().replace('+', '');
                const foundCategory = menuData.categories?.find(cat => 
                    cat.name.toLowerCase() === categoryRequested
                );
                
                if (foundCategory) {
                    categoriesToShow = [foundCategory];
                    isSpecificCategory = true;
                    categoryTitle = foundCategory.name.toUpperCase();
                }
            }
            
            // Construir encabezado del menú
            let menuText = `🍜ֲ〫̐〬𝆹゚𝅥𔘓 ${pushName} *Bienvenido a mi menu completo*\n\n❀ֵ֘ ⃞▒ᩙ݀ᤲ᮫ ֵ *bᦅƚ  › ${botConfig.name || config.name}*\n❀ֵ֘ ⃞▒ᩙ݀ᤲ᮫ ֵ *ƚꪱ𝗉ᦅ  › ${botConfig.tipo || config.tipo}*\n❀ֵ֘ ⃞▒ᩙ݀ᤲ᮫ ֵ *ꭇᧉgꪱ𝗌ƚꭇᦅ𝗌  › ${totalUsers}*\n❀ֵ֘ ⃞▒ᩙ݀ᤲ᮫ ֵ *ꭇ𝗎𝗇ƚꪱ𝗆ᧉ  › ${uptimeText}*\n\n✿⃝🍥̷̥̊˼𔘓 *cαƚᧉgᦅꭇíα𝗌* 𝆹𝅥 🎀̸⃨̟⃜⃞〫⿻\n\n`;
            
            // Agregar categorías con sus comandos
            if (!categoriesToShow || categoriesToShow.length === 0) {
                menuText += `⭐ *ɴᴏ ʜᴀʏ ᴄᴀᴛᴇɢᴏʀɪ́ᴀs ᴅɪsᴘᴏɴɪʙʟᴇs*\n`;
                menuText += `*ᴜsᴀ ${botConfig.prefix || config.prefix}setcat ᴘᴀʀᴀ ᴀɢʀᴇɢᴀʀ ᴄᴀᴛᴇɢᴏʀɪ́ᴀs*\n\n`;
            } else {
                for (const category of categoriesToShow) {
                    // Obtener descripción de la categoría
                    const catDesc = menuData.categoryDescriptions?.[category.name] || 
                                   `Comandos relacionados con ${category.name}`;
                    
                    menuText += `ᡣ𐭩╭ּ໋ׅ─ᩙ⃘━ּ໋ׅ━ׄ━໋ׅ━ᩨ━໋ׅ━໋ׅׄ━✡︎໋︩︪〫݀ׄ۟𝆬⃞   ━ᩙׅ━໋━໋ׅ━ׅׄ━ᩨׅ━໋ׅ━⃘─໋ׅׄ╮ᡣ𐭩\n                      \`\`\`${category.name}\`\`\` \n        \`»\` *${catDesc}*\n❀•°⏝˖⏝˖⏝🍥〪̫⏝˖⏝˖⏝°•❀\n\n`;
                    
                    // Agregar comandos de esta categoría
                    if (category.commands && category.commands.length > 0) {
                        for (const cmdName of category.commands) {
                            // Buscar información del comando
                            const cmdInfo = commandMap.get(cmdName);
                            
                            // Mostrar comando con alias
                            menuText += `🌈⃞̸᪶〫᪲˖⃞ ${botConfig.prefix || config.prefix}${cmdName}`;
                            
                            if (cmdInfo && cmdInfo.alias && cmdInfo.alias.length > 0) {
                                const aliasList = cmdInfo.alias.filter(a => a !== cmdName);
                                if (aliasList.length > 0) {
                                    const aliasText = aliasList.map(a => `${botConfig.prefix || config.prefix}${a}`).join(' › ');
                                    menuText += ` › ${aliasText}`;
                                }
                            }
                            
                            menuText += `\n`;
                        }
                    } else {
                        menuText += ` 📭 *sɪɴ ᴄᴏᴍᴀɴᴅᴏs ᴇɴ ᴇsᴛᴀ ᴄᴀᴛᴇɢᴏʀɪ́ᴀ*\n`;
                    }
                    
                    menuText += `\n`;
                }
            }
            
            // Si es una categoría específica, agregar nota
            if (isSpecificCategory) {
                menuText += `\n\n> *🎑ᩨ Usa ${botConfig.prefix || config.prefix}menu para ver todas las categorías*`;
            }
            
            // ==========================================
            // CARGAR IMAGEN DESDE INFO/{NÚMERO}/BANNER.JPG
            // ==========================================
            let bannerBuffer = null;
            let imagePath = '';
            let useImage = false;
            
            if (botNumber) {
                const bannerPath = path.join(process.cwd(), 'info', botNumber, 'banner.jpg');
                
                if (fs.existsSync(bannerPath)) {
                    try {
                        bannerBuffer = fs.readFileSync(bannerPath);
                        imagePath = bannerPath;
                        // Verificar que el buffer no esté vacío y sea una imagen válida
                        if (bannerBuffer && bannerBuffer.length > 0) {
                            useImage = true;
                            console.log(`✅ Imagen del menú cargada desde info/${botNumber}/banner.jpg (${bannerBuffer.length} bytes)`);
                        } else {
                            console.log(`⚠️ Imagen vacía en info/${botNumber}/banner.jpg`);
                        }
                    } catch (bannerError) {
                        console.log(`⚠️ Error cargando imagen específica:`, bannerError.message);
                    }
                }
            }
            
            // Si no hay imagen específica, buscar imagen general
            if (!useImage) {
                const generalBannerPath = path.join(__dirname, '..', 'img', 'banner.jpg');
                if (fs.existsSync(generalBannerPath)) {
                    try {
                        bannerBuffer = fs.readFileSync(generalBannerPath);
                        imagePath = generalBannerPath;
                        if (bannerBuffer && bannerBuffer.length > 0) {
                            useImage = true;
                            console.log(`✅ Imagen general cargada para menú (${bannerBuffer.length} bytes)`);
                        } else {
                            console.log(`⚠️ Imagen general vacía`);
                        }
                    } catch (bannerError) {
                        console.log(`⚠️ Error cargando imagen general:`, bannerError.message);
                    }
                }
            }
            
            // Preparar el mensaje con menciones
            const mentions = [sender];
            
            // ====================
            // ENVIAR MENSAJE CON O SIN IMAGEN (MANEJO DE ERRORES MEJORADO)
            // ====================
            let messageSent = false;
            
            // Intentar enviar con imagen si está disponible
            if (useImage && bannerBuffer && bannerBuffer.length > 0) {
                try {
                    // Determinar el tipo MIME de la imagen
                    const mimeType = imagePath.endsWith('.png') ? 'image/png' : 'image/jpeg';
                    
                    // Intentar enviar como imagen
                    await sock.sendMessage(from, {
                        image: bannerBuffer,
                        caption: menuText,
                        mentions: mentions,
                        mimetype: mimeType,
                        contextInfo: {
                            mentionedJid: mentions,
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: botConfig.canalId || config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: botConfig.canalNombre || config.canalNombre || '⭐̸̷᪲ 𝕸𝖔𝖔𝖓𝖑𝖎𝖌𝖍𝖙 𝕸𝖊𝖓𝖚 ♡⃘꤬֟🎑ꨩּ݄҇ᬊ໋۟'
                            }
                        }
                    }, { quoted: msg });
                    
                    messageSent = true;
                    console.log('✅ Imagen enviada con el menú como caption');
                    
                } catch (imageError) {
                    console.error('❌ Error al enviar imagen:', imageError.message);
                    console.log('⚠️ Falló envío con imagen, intentando solo texto...');
                    useImage = false; // Marcar para no reintentar imagen
                }
            }
            
            // Si no se pudo enviar con imagen o no hay imagen, enviar solo texto
            if (!messageSent) {
                try {
                    await sock.sendMessage(from, {
                        text: menuText,
                        mentions: mentions,
                        contextInfo: {
                            mentionedJid: mentions,
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: botConfig.canalId || config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: botConfig.canalNombre || config.canalNombre || '⭐̸̷᪲ 𝕸𝖔𝖔𝖓𝖑𝖎𝖌𝖍𝖙 𝕸𝖊𝖓𝖚 ♡⃘꤬֟🎑ꨩּ݄҇ᬊ໋۟'
                            }
                        }
                    }, { quoted: msg });
                    
                    messageSent = true;
                    console.log('✅ Texto del menú enviado (sin imagen)');
                    
                } catch (textError) {
                    console.error('❌ Error al enviar texto:', textError.message);
                    throw textError; // Re-lanzar el error si también falla el texto
                }
            }
            
            console.log(`📋 Menú ${isSpecificCategory ? `de categoría ${categoriesToShow[0].name}` : 'general'} enviado - Bot: ${botNumber || 'desconocido'}`);
            
        } catch (error) {
            console.error('❌ Error en allmenu:', error);
            
            try {
                // Intentar enviar un mensaje de error más simple
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `🏮 Error al generar el menú. Por favor intenta más tarde.\nDetalle: ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('❌ Error crítico, no se pudo enviar mensaje de error:', e);
            }
        }
    },
    
    formatUptime(uptime) {
        const seconds = Math.floor(uptime / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
        
        if (days > 0) return `${days}d ${hours % 24}h`;
        if (hours > 0) return `${hours}h ${minutes % 60}m`;
        if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
        return `${seconds}s`;
    }
};