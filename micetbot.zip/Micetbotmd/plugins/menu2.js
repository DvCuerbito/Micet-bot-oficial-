import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let botStartTime = Date.now();

function getMexicoTimeAndGreeting() {
    const options = { timeZone: 'America/Merida', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true };
    const mexicoTime = new Date().toLocaleString('es-MX', options);
    const mexicoDate = new Date().toLocaleString('en-US', { timeZone: 'America/Merida' });
    const mexicoHour = new Date(mexicoDate).getHours();
    let greeting = mexicoHour >=5 && mexicoHour <12? 'Buenos días 🏙️' : mexicoHour <19? 'Buenas tardes 🌆' : 'Buenas noches 🌃';
    return { time: mexicoTime, greeting };
}

export default {
    name: 'menu2',
    alias: ['menuowner'],

    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName } = options;
            const from = msg.key.remoteJid;

            if (usersDB && senderNumber &&!usersDB[senderNumber]) {
                await sock.sendMessage(from, { text: `🍒 Registrate primero.` }, { quoted: msg });
                return;
            }

            const isOwner = config.owner && config.owner.some(num => num.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, ''));
            if (!isOwner) {
                await sock.sendMessage(from, {
                    text: `🙀 Mejor vete a usar Neos Club`,
                    contextInfo: { mentionedJid: [senderJid], forwardingScore: 9999999, isForwarded: true }
                }, { quoted: msg });
                return;
            }

            let botNumber = '';
            if (sock.user?.id) botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            let botConfig = {...config };
            if (botNumber) {
                const cfgPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
                if (fs.existsSync(cfgPath)) {
                    try {
                        const content = fs.readFileSync(cfgPath, 'utf8');
                        const m = content.match(/export default\s+({[\s\S]*})/);
                        if (m) botConfig = eval('(' + m[1] + ')');
                    } catch {}
                }
            }

            const pluginsDir = path.join(__dirname, '..', 'plugins');
            let commandMap = new Map();
            if (fs.existsSync(pluginsDir)) {
                for (const file of fs.readdirSync(pluginsDir).filter(f => f.endsWith('.js'))) {
                    try {
                        const mod = await import(`file://${path.join(pluginsDir, file)}?u=${Date.now()}`);
                        const data = mod.default || mod;
                        if (data?.name) commandMap.set(data.name, { alias: data.alias || [] });
                    } catch {}
                }
            }

            const { time: mexicoTime } = getMexicoTimeAndGreeting();
            const totalUsers = Object.keys(usersDB || {}).length;

            const menuPath = path.join(__dirname, '..', 'databases', 'menu2.json');
            let menuData = { categories: [] };
            if (fs.existsSync(menuPath)) menuData = JSON.parse(fs.readFileSync(menuPath, 'utf8'));

            let menuText = `╭ ࣪ 𖹭֗ ּ ֵ֘֘Ⳓׄ ᮫ׅ 🎑ۭᩙ ׄ ּპֵ֘֘ ּ ֗𖹭 ࣪ ╮࣭
寝ׅる۪࣪ Nombre » ${pushName}
寝ׅる۪࣪ Bot » ${botConfig.name || config.name}
寝ׅる۪࣪ Usuarios » ${totalUsers}
寝ׅる۪࣪ Hora » ${mexicoTime}
╰ ࣭ 𖹭֗ ּ ֵ֘֘Ⳓׄ ᮫ׅ 🎑ۭᩙ ׄ ּპֵ֘֘ ּ ֗𖹭 ࣭ ╯࣪

`;

            for (const cat of menuData.categories || []) {
                menuText += `> ๋۪✿᳞ׄ ּ╰࣪ ᳝🌖࣮۫ ╮۪֗ *${cat.name}* ╭ ࣮۫🌖᳝ ࣪╯ּ ࡙ׄ✿๋۪\n`;
                for (const cmd of cat.commands || []) {
                    const info = commandMap.get(cmd);
                    let line = `𔖭۫🌽꯭𝕿ּ ${botConfig.prefix || config.prefix}${cmd}`;
                    if (info?.alias?.length) {
                        const als = info.alias.filter(a => a!== cmd).map(a => `${botConfig.prefix || config.prefix}${a}`).join(' › ');
                        if (als) line += ` › ${als}`;
                    }
                    menuText += line + '\n';
                }
                menuText += `\n`;
            }

            let iconBuffer = null;
            if (botNumber) {
                const iconPath = path.join(process.cwd(), 'info', botNumber, 'icon.jpg');
                if (fs.existsSync(iconPath)) iconBuffer = fs.readFileSync(iconPath);
            }
            if (!iconBuffer) {
                const generalIcon = path.join(__dirname, '..', 'img', 'icon.jpg');
                if (fs.existsSync(generalIcon)) iconBuffer = fs.readFileSync(generalIcon);
            }

            await sock.sendMessage(from, {
                text: menuText,
                contextInfo: {
                    mentionedJid: [senderJid],
                    externalAdReply: iconBuffer? {
                        title: `✿  ꒰ㅤ⃞̸̷ֺ᪱๑ֺ—  Moonlight Staff 𐙚ㅤしし`,
                        body: `Made with ❤️, Moonlight Staff`,
                        mediaType: 1,
                        thumbnail: iconBuffer,
                        sourceUrl: botConfig.canalUrl || config.canalUrl || '',
                        showAdAttribution: false,
                        renderLargerThumbnail: false
                    } : {},
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: botConfig.canalId || config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: botConfig.canalNombre || config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });

        } catch (error) {
            await sock.sendMessage(msg.key.remoteJid, { text: `Error: ${error.message}` }, { quoted: msg });
        }
    }
};