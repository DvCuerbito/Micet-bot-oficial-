import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

// Cargar economía
function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

// Guardar economía
function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

// Inicializar usuario en economía si no existe
function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 0,
            minerals: {
                piedras: 0,
                diamantes: 0,
                esmeraldas: 0,
                oro: 0
            },
            health: 100,
            lastMine: 0,
            lastWork: 0,
            lastCrime: 0,
            items: {
                agua: 0,
                vendas: 0,
                pastillas: 0
            }
        };
    }
    return economy[userNumber];
}

// Formatear tiempo restante
function getRemainingTime(lastUsed, cooldownMs = 120000) {
    const now = Date.now();
    const timePassed = now - lastUsed;
    
    if (timePassed >= cooldownMs) return 0;
    
    const remaining = cooldownMs - timePassed;
    const seconds = Math.floor(remaining / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    
    if (minutes > 0) {
        return `${minutes}m ${remainingSeconds}s`;
    }
    return `${remainingSeconds}s`;
}

export default {
    name: 'minar',
    alias: ['mine', 'mineria'],
    
    async execute(sock, msg, options) {
        try {
            const { 
                config, 
                senderNumber, 
                pushName,
                replyWithContext,
                senderJid 
            } = options;
            
            const from = msg.key.remoteJid;
            
            // Verificar que tenemos número de usuario
            if (!senderNumber) {
                return await replyWithContext(
                    '❌ No se pudo identificar tu número',
                    [senderJid]
                );
            }
            
            // Cargar economía
            let economy = loadEconomy();
            
            // Inicializar usuario
            const user = initUserEconomy(economy, senderNumber, pushName);
            
            // Verificar salud
            if (user.health <= 10) {
                return await replyWithContext(
                    '⚠️ *Tu salud es muy baja para seguir minando* ⚠️\n> Usa *heal* para recuperarte',
                    [senderJid]
                );
            }
            
            // Verificar cooldown de 2 minutos (120,000 ms)
            const cooldownTime = 120000; // 2 minutos en milisegundos
            const now = Date.now();
            
            if (user.lastMine && (now - user.lastMine) < cooldownTime) {
                const remaining = getRemainingTime(user.lastMine, cooldownTime);
                return await replyWithContext(
                    `⏳ *Debes esperar ${remaining}* para volver a minar`,
                    [senderJid]
                );
            }
            
            // Actualizar tiempo de última minada
            user.lastMine = now;
            saveEconomy(economy);
            
            // Generar recursos aleatorios
            const piedraGanada = Math.floor(Math.random() * 50) + 20; // 20-70 piedras
            const diamantesGanados = Math.floor(Math.random() * 5) + 1; // 1-6 diamantes
            const esmeraldasGanadas = Math.floor(Math.random() * 8) + 2; // 2-10 esmeraldas
            const oroGanado = Math.floor(Math.random() * 10) + 3; // 3-13 oro
            
            // Reducir salud (5-15 puntos)
            const healthLoss = Math.floor(Math.random() * 11) + 5; // 5-15
            
            // Actualizar recursos
            user.minerals.piedras += piedraGanada;
            user.minerals.diamantes += diamantesGanados;
            user.minerals.esmeraldas += esmeraldasGanadas;
            user.minerals.oro += oroGanado;
            user.health = Math.max(0, user.health - healthLoss);
            
            saveEconomy(economy);
            
            // Mensaje de recompensas
            const rewardText = `⛏️ *VIAJE A MINA*\n` +
                `🧭 Trabajaste en una minería para encontrar recursos\n\n` +
                `🎑 *RECOMPENSAS*\n\n` +
                `🪨 Piedras » *${piedraGanada}*\n` +
                `💎 Diamantes » *${diamantesGanados}*\n` +
                `💚 Esmeraldas » *${esmeraldasGanadas}*\n` +
                `🪙 Oro » *${oroGanado}*\n\n` +
                `❤️ Salud perdida » *-${healthLoss}*`;
            
            await replyWithContext(rewardText, [senderJid]);
            
        } catch (error) {
            console.error('❌ Error en comando minar:', error);
        }
    }
};
