import fetch from 'node-fetch';

const regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i;

export default {
    name: 'gitclone',
    alias: ['github', 'git', 'clonar'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            const url = args[0];

            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Sumi.18`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            if (!url) {
                await sock.sendMessage(from, { 
                    text: `🌠 Por favor, ingresa la URL de un repositorio de GitHub que deseas descargar.\n\nEjemplo: *${config.prefix}gitclone* https://github.com/usuario/repositorio`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            if (!regex.test(url)) {
                await sock.sendMessage(from, {
                    react: {
                        text: '❌',
                        key: msg.key
                    }
                });
                
                await sock.sendMessage(from, { 
                    text: `🌠 Verifica que la *URL* sea de GitHub\n\nEjemplo: https://github.com/usuario/repositorio`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            let [_, userRepo, repo] = url.match(regex) || [];
            let sanitizedRepo = repo.replace(/.git$/, '');
            let repoUrl = `https://api.github.com/repos/${userRepo}/${sanitizedRepo}`;
            let zipUrl = `https://api.github.com/repos/${userRepo}/${sanitizedRepo}/zipball`;

            // Reacción indicando procesamiento
            await sock.sendMessage(from, {
                react: {
                    text: '🔄',
                    key: msg.key
                }
            });

            // Mensaje de espera
            await sock.sendMessage(from, { 
                text: `🥕 Descargando repositorio...\n> ${userRepo}/${sanitizedRepo}`,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });

            let repoResponse, zipResponse;
            try {
                [repoResponse, zipResponse] = await Promise.all([
                    fetch(repoUrl),
                    fetch(zipUrl),
                ]);
            } catch (fetchError) {
                await sock.sendMessage(from, {
                    react: {
                        text: '❌',
                        key: msg.key
                    }
                });
                
                await sock.sendMessage(from, { 
                    text: `🍁 Error al conectar con GitHub`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            if (!repoResponse.ok || !zipResponse.ok) {
                await sock.sendMessage(from, {
                    react: {
                        text: '❌',
                        key: msg.key
                    }
                });
                
                await sock.sendMessage(from, { 
                    text: `🍁 Repositorio no encontrado o no accesible\n\nVerifica que el repositorio exista y sea público`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            let repoData = await repoResponse.json();
            let zipBuffer = await zipResponse.buffer();
            
            // Obtener nombre del archivo del header o generar uno
            let filename = `${userRepo}_${sanitizedRepo}.zip`;
            const contentDisposition = zipResponse.headers.get('content-disposition');
            if (contentDisposition) {
                const match = contentDisposition.match(/filename="?([^"]+)"?/);
                if (match && match[1]) {
                    filename = match[1];
                }
            }

            // Crear texto informativo
            let txt = `*✧ G I T H U B  -  D O W N L O A D ✧*\n\n`;
            txt += `✦  *Nombre* : ${sanitizedRepo}\n`;
            txt += `✦  *Repositorio* : ${userRepo}/${sanitizedRepo}\n`;
            txt += `✦  *Creador* : ${repoData.owner?.login || 'Desconocido'}\n`;
            txt += `✦  *Estrellas* : ${repoData.stargazers_count || 0}\n`;
            txt += `✦  *Forks* : ${repoData.forks_count || 0}\n`;
            txt += `✦  *Descripción* : ${repoData.description || 'Sin descripción'}\n`;
            txt += `✦  *Url* : ${url}\n`;
            txt += `✦  *Tamaño* : ${Math.round(zipBuffer.length / 1024 / 1024 * 100) / 100} MB\n\n`;
            txt += `> Archivo: ${filename}`;

            // Enviar archivo ZIP
            await sock.sendMessage(from, {
                document: zipBuffer,
                fileName: filename,
                caption: txt,
                mimetype: 'application/zip',
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });

            // Reacción de éxito
            await sock.sendMessage(from, {
                react: {
                    text: '✅',
                    key: msg.key
                }
            });

            console.log(`✅ Gitclone ejecutado por ${pushName || senderNumber}: ${userRepo}/${sanitizedRepo}`);

        } catch (error) {
            console.error('❌ Error en comando gitclone:', error);
            
            // Reacción de error
            await sock.sendMessage(msg.key.remoteJid, {
                react: {
                    text: '❌',
                    key: msg.key
                }
            });
            
            await sock.sendMessage(msg.key.remoteJid, { 
                text: `⚠︎ Se ha producido un problema.\n> Usa *${options.config.prefix}report* para informarlo.\n\nError: ${error.message}`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};