import fs from 'fs';
import path from 'path';
import { randomBytes } from 'crypto';
import ffmpeg from 'fluent-ffmpeg';
import pkg from 'node-webpmux';
import { fileURLToPath } from 'url';
import { downloadMediaMessage } from '@whiskeysockets/baileys';
import petPetGif from 'pet-pet-gif';
import sharp from 'sharp';

const { Image } = pkg;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const tempFolder = path.join(__dirname, '../databases/');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

// Cargar metadatos
function loadUserMetadata() {
    try {
        const metadataFile = path.join(__dirname, '../databases/user_metadata.json');
        if (fs.existsSync(metadataFile)) {
            const data = fs.readFileSync(metadataFile, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.log('Error cargando metadatos:', error);
    }
    return {};
}

function getUserMetadata(userNumber) {
    const metadata = loadUserMetadata();
    return metadata[userNumber] || null;
}

async function getGroupName(sock, groupId) {
    try {
        if (groupId.endsWith('@g.us')) {
            const groupMetadata = await sock.groupMetadata(groupId);
            return groupMetadata.subject || 'Grupo';
        }
    } catch (error) {
        console.log('Error obteniendo nombre del grupo:', error);
    }
    return 'Grupo';
}

function randomFileName(ext) {
    return `${randomBytes(6).readUIntLE(0, 6).toString(36)}.${ext}`;
}

async function addExif(webpBuffer, metadata) {
    const tmpIn = path.join(tempFolder, randomFileName('webp'));
    const tmpOut = path.join(tempFolder, randomFileName('webp'));
    fs.writeFileSync(tmpIn, webpBuffer);

    const json = {
        "sticker-pack-id": "starry_moonlight",
        "sticker-pack-name": metadata.packname || "",
        "sticker-pack-publisher": metadata.author || "",
        "emojis": ["✨"]
    };

    const exifAttr = Buffer.from([
        0x49, 0x49, 0x2A, 0x00,
        0x08, 0x00, 0x00, 0x00,
        0x01, 0x00, 0x41, 0x57,
        0x07, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x16, 0x00,
        0x00, 0x00
    ]);
    const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8");
    const exif = Buffer.concat([exifAttr, jsonBuff]);
    exif.writeUIntLE(jsonBuff.length, 14, 4);

    const img = new Image();
    await img.load(tmpIn);
    img.exif = exif;
    await img.save(tmpOut);
    fs.unlinkSync(tmpIn);
    return tmpOut;
}

// Normalizar imagen para petpet
const normalizePetpetInput = async (media, mime = '') => {
    let input = Buffer.isBuffer(media) ? media : Buffer.from(media || []);
    if (!input.length) throw new Error('Buffer de imagen vacío');

    try {
        const isWebp = /webp/i.test(String(mime || ''));
        const meta = await sharp(input, { animated: true }).metadata().catch(() => null);
        const hasAlpha = Boolean(meta?.hasAlpha);

        if (isWebp || hasAlpha) {
            input = await sharp(input, { animated: true })
                .flatten({ background: '#ffffff' })
                .png()
                .toBuffer();
        } else {
            input = await sharp(input, { animated: true })
                .png()
                .toBuffer();
        }
    } catch (e) {
        // Si falla sharp, usar el buffer original
    }

    return input;
};

// Generar sticker petpet
const buildPetpetSticker = async (media) => {
    const variants = [
        { resolution: 256, delay: 20 },
        { resolution: 256, delay: 20, backgroundColor: '#ffffff' },
        { resolution: 128, delay: 20, backgroundColor: '#ffffff' }
    ];

    let lastError = null;
    for (const options of variants) {
        try {
            const gifBuffer = await petPetGif(media, options);
            
            // Convertir GIF a WebP sticker
            const stickerBuffer = await gifToWebpSticker(gifBuffer);
            
            if (Buffer.isBuffer(stickerBuffer) && stickerBuffer.length > 0) return stickerBuffer;
            throw new Error('Sticker vacío');
        } catch (e) {
            lastError = e;
        }
    }
    throw lastError || new Error('[ ★ ] No se pudo generar sticker');
};

// Convertir GIF a WebP sticker
async function gifToWebpSticker(gifBuffer) {
    const tmpIn = path.join(tempFolder, randomFileName('gif'));
    const tmpOut = path.join(tempFolder, randomFileName('webp'));
    fs.writeFileSync(tmpIn, gifBuffer);

    return new Promise((resolve, reject) => {
        ffmpeg(tmpIn)
            .on('error', (err) => {
                try { fs.unlinkSync(tmpIn); } catch (e) {}
                reject(err);
            })
            .on('end', () => {
                try {
                    const buff = fs.readFileSync(tmpOut);
                    try { fs.unlinkSync(tmpIn); } catch (e) {}
                    try { fs.unlinkSync(tmpOut); } catch (e) {}
                    resolve(buff);
                } catch (err) {
                    reject(err);
                }
            })
            .addOutputOptions([
                "-vcodec", "libwebp",
                "-vf", "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=10,pad=320:320:-1:-1:color=white@0.0,split[a][b];[a]palettegen=reserve_transparent=on:transparency_color=ffffff[p];[b][p]paletteuse",
                "-loop", "0",
                "-preset", "default",
                "-an",
                "-vsync", "0"
            ])
            .toFormat('webp')
            .save(tmpOut);
    });
}

export default {
    name: 'petpet',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `[ ★ ] Para usar mis comandos tienes que estar registrado.\n> Uso: ${config.prefix}reg nombre`
                }, { quoted: msg });
                return;
            }
            
            await sock.sendPresenceUpdate('composing', from);

            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            if (!quotedMsg?.quotedMessage) {
                await sock.sendMessage(from, { 
                    text: `[ ★ ] Responde a una imagen o sticker con el comando\n> Uso: ${config.prefix}petpet`
                }, { quoted: msg });
                return;
            }

            const quotedMessage = quotedMsg.quotedMessage;
            let mediaType;
            let mediaMessage;
            let mimeType = '';
            
            if (quotedMessage.imageMessage) {
                mediaType = 'image';
                mediaMessage = quotedMessage.imageMessage;
                mimeType = mediaMessage.mimetype || 'image/jpeg';
            } else if (quotedMessage.stickerMessage) {
                mediaType = 'sticker';
                mediaMessage = quotedMessage.stickerMessage;
                mimeType = 'image/webp';
            } else {
                await sock.sendMessage(from, { 
                    text: '[ ★ ] Solo funciona con imagen o sticker.'
                }, { quoted: msg });
                return;
            }

            // Reacción de carga
            await sock.sendMessage(from, {
                react: { text: '⌛', key: msg.key }
            });

            // Descargar el medio
            const quotedMsgObj = {
                key: {
                    remoteJid: from,
                    id: quotedMsg.stanzaId,
                    participant: quotedMsg.participant || from,
                    fromMe: false
                },
                message: {
                    [mediaType + 'Message']: mediaMessage
                }
            };
            
            const buffer = await downloadMediaMessage(
                quotedMsgObj,
                'buffer',
                {},
                {
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage
                }
            );

            if (!buffer || buffer.length === 0) {
                throw new Error('No se pudo descargar el archivo');
            }

            // Normalizar y generar petpet
            const normalized = await normalizePetpetInput(buffer, mimeType);
            const petpetBuffer = await buildPetpetSticker(normalized);

            // Obtener metadata
            const userMetadata = getUserMetadata(senderNumber);
            let customPackname = '';
            let customAuthor = '';

            let groupName = '';
            if (from.endsWith('@g.us')) {
                groupName = await getGroupName(sock, from);
            }

            if (userMetadata && (userMetadata.packname || userMetadata.author)) {
                customPackname = userMetadata.packname || '';
                customAuthor = userMetadata.author || '';
            } else {
                customPackname = `🌵 ${pushName || senderNumber}`;
                customAuthor = `🌵 Bot » ${config.name || 'Moonlight'}`;
                if (from.endsWith('@g.us') && groupName) {
                    customAuthor = `🌵 Grupo » ${groupName}`;
                }
            }

            const metadata = { packname: customPackname, author: customAuthor };
            const stickerPath = await addExif(petpetBuffer, metadata);

            // Enviar sticker
            await sock.sendMessage(from, {
                sticker: fs.readFileSync(stickerPath)
            }, { quoted: msg });
            
            // Limpiar archivo temporal
            try { fs.unlinkSync(stickerPath); } catch (e) {}
            
            // Reacción de éxito
            await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            
            console.log(`[ ★ ] Petpet creado para ${pushName || senderNumber}`);

        } catch (error) {
            console.error('[ ★ ] Error en petpet:', error);
            
            // Reacción de error
            try {
                await sock.sendMessage(msg.key.remoteJid, { 
                    react: { text: '❌', key: msg.key }
                });
            } catch (e) {}
            
            await sock.sendMessage(msg.key.remoteJid, { 
                text: `[ ★ ] No pude generar el sticker petpet.\n> ${error.message}`
            }, { quoted: msg });
        }
    }
};