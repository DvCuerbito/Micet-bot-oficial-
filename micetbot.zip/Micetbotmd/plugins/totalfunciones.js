import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
  name: 'totalfunciones',
  alias: ['totalcmd'],
  async execute(sock, msg, options) {
    try {
      const { config, usersDB, senderNumber, senderJid, pushName } = options;
      const from = msg.key.remoteJid;

      // ==========================================
      // OBTENER NÚMERO DEL BOT
      // ==========================================
      let botNumber = '';
      if (sock.phoneNumber) {
        botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
      } else if (sock.user?.id) {
        botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
      }

      // Verificar registro
      if (usersDB && senderNumber && !usersDB[senderNumber]) {
        await sock.sendMessage(from, {
          text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
          contextInfo: {
            forwardedNewsletterMessageInfo: {
              newsletterJid: config.canalId || '',
              serverMessageId: 0,
              newsletterName: config.canalNombre || ''
            },
            forwardingScore: 9999999,
            isForwarded: true
          }
        }, { quoted: msg });
        return;
      }

      // Contar archivos en la carpeta plugins
      const pluginsDir = path.join(__dirname, '../plugins');
      const files = fs.readdirSync(pluginsDir);
      const totalFunciones = files.filter(file => file.endsWith('.js')).length;

      // Mensaje con el formato exacto que solicitas
      const message = `🌺 *Total funciones* » *${totalFunciones}*`;

      // ==========================================
      // CARGAR ICONO DESDE INFO/{NÚMERO}/ICON.JPG
      // ==========================================
      let iconBuffer = null;
      
      if (botNumber) {
        const iconPath = path.join(process.cwd(), 'info', botNumber, 'icon.jpg');
        if (fs.existsSync(iconPath)) {
          try {
            iconBuffer = fs.readFileSync(iconPath);
            console.log(`✅ Icono cargado desde info/${botNumber}/icon.jpg para totalfunciones`);
          } catch (iconError) {
            console.log(`⚠️ Error cargando icono específico:`, iconError.message);
          }
        }
      }
      
      // Si no hay icono específico, buscar icono general
      if (!iconBuffer) {
        const generalIconPath = path.join(__dirname, '../img/icon.jpg');
        if (fs.existsSync(generalIconPath)) {
          iconBuffer = fs.readFileSync(generalIconPath);
          console.log('✅ Icono general cargado para totalfunciones');
        }
      }

      try {
        if (iconBuffer) {
          await sock.sendMessage(from, {
            text: message,
            contextInfo: {
              mentionedJid: [senderJid],
              externalAdReply: {
                title: `🌠 ${config.name || 'BOT'}`,
                body: `Moonlight studios`,
                mediaType: 1,
                thumbnail: iconBuffer,
                sourceUrl: config.canalUrl || '',
                showAdAttribution: false,
                renderLargerThumbnail: false
              },
              forwardedNewsletterMessageInfo: {
                newsletterJid: config.canalId || '',
                serverMessageId: 0,
                newsletterName: config.canalNombre || ''
              },
              forwardingScore: 9999999,
              isForwarded: true
            }
          }, { quoted: msg });
        } else {
          // Si no existe la imagen, enviar solo el texto
          await sock.sendMessage(from, {
            text: message,
            contextInfo: {
              mentionedJid: [senderJid],
              forwardedNewsletterMessageInfo: {
                newsletterJid: config.canalId || '',
                serverMessageId: 0,
                newsletterName: config.canalNombre || ''
              },
              forwardingScore: 9999999,
              isForwarded: true
            }
          }, { quoted: msg });
        }
        console.log(`✅ Total funciones consultado por ${pushName || senderNumber}: ${totalFunciones} - Bot: ${botNumber || 'desconocido'}`);
      } catch (error) {
        console.error('Error en comando totalfunciones:', error);
        // Fallback: enviar solo texto
        await sock.sendMessage(from, {
          text: message,
          contextInfo: {
            mentionedJid: [senderJid],
            forwardedNewsletterMessageInfo: {
              newsletterJid: config.canalId || '',
              serverMessageId: 0,
              newsletterName: config.canalNombre || ''
            },
            forwardingScore: 9999999,
            isForwarded: true
          }
        }, { quoted: msg });
      }
    } catch (error) {
      console.error('❌ Error en totalfunciones:', error);
      try {
        await sock.sendMessage(msg.key.remoteJid, {
          text: `｡ﾟﾟ･｡･ﾟﾟ｡\n ﾟ。 *Error* » ${error.message}\n ﾟ･｡･ﾟ`,
          contextInfo: {
            forwardedNewsletterMessageInfo: {
              newsletterJid: options.config.canalId || '',
              serverMessageId: 0,
              newsletterName: options.config.canalNombre || ''
            },
            forwardingScore: 9999999,
            isForwarded: true
          }
        }, { quoted: msg });
      } catch (e) {
        console.error('Error enviando mensaje de error:', e);
      }
    }
  }
};
