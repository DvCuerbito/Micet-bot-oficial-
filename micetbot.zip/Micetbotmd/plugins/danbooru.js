import fetch from 'node-fetch';

export default {
    name: 'danbooru',
    alias: ['dbooru'],

    execute: async (sock, msg, options) => {
        const { 
            replyWithContext, 
            sender, 
            args, 
            config, 
            pushName 
        } = options;

        const from = msg.key.remoteJid;

        try {
            // Validar si hay tags para buscar
            if (!args[0]) {
                return replyWithContext(
                    `⭐ Debes especificar etiquetas para buscar en Danbooru.\n> Ejemplo: *${config.prefix || '.'}danbooru neko*`, 
                    [sender]
                );
            }

            // Reacción de espera
            try { await sock.sendMessage(from, { react: { text: '🕒', key: msg.key } }); } catch {}

            // Unir argumentos con guiones bajos y codificar para la URL
            const tag = args.join('_');
            const url = `https://danbooru.donmai.us/posts.json?tags=${encodeURIComponent(tag)}`;

            const res = await fetch(url);
            if (!res.ok) throw new Error('Error en la respuesta de Danbooru');

            const json = await res.json();
            
            // Danbooru devuelve un array directamente. Filtramos URLs válidas de imagen/gif
            const validMedia = json
                .map(p => p?.file_url)
                .filter(u => typeof u === 'string' && /\.(jpe?g|png|gif)$/i.test(u));

            if (!validMedia.length) {
                try { await sock.sendMessage(from, { react: { text: '❌', key: msg.key } }); } catch {}
                return replyWithContext(`《✧》 No se encontraron imágenes para: *${tag}*`, [sender]);
            }

            // Seleccionar una imagen al azar de los resultados
            const selected = validMedia[Math.floor(Math.random() * validMedia.length)];
            const caption = `🎨 *Danbooru Results* 🎨\n> Tag: ${tag}\n> Pedido por: ${pushName}`;

            // Enviar la imagen
            await sock.sendMessage(from, { 
                image: { url: selected }, 
                caption: caption,
                mentions: [sender]
            }, { quoted: msg });

            // Reacción de éxito
            try { await sock.sendMessage(from, { react: { text: '✔️', key: msg.key } }); } catch {}

        } catch (error) {
            console.error('Error en Danbooru:', error);
            try { await sock.sendMessage(from, { react: { text: '✖️', key: msg.key } }); } catch {}
            replyWithContext(`❌ Error en la búsqueda: ${error.message}`, [sender]);
        }
    }
}