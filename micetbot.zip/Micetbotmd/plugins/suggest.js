import fs from 'fs';
import path from 'path';

// ID del grupo donde se enviarán las sugerencias
const SUGGEST_GROUP_ID = "120363406310003071@g.us";

export default {
    name: 'suggest',
    alias: ['sugerencia'],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // Verificar si se proporcionó texto
            const texto = args.join(' ').trim();
            
            if (!texto) {
                await sock.sendMessage(from, {
                    text: `🦋 Debes proporcionar un texto para enviar cómo sugerencia`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Obtener información del grupo de origen (si es un grupo)
            let groupName = "Chat privado";
            let groupId = from;
            
            if (from.endsWith('@g.us')) {
                try {
                    const groupMetadata = await sock.groupMetadata(from);
                    groupName = groupMetadata.subject || "Grupo sin nombre";
                    groupId = from;
                } catch (error) {
                    console.error('Error obteniendo metadata del grupo:', error);
                    groupName = "Grupo desconocido";
                }
            }
            
            // Buscar el bot principal para enviar la sugerencia
            if (global.principalBot && global.principalBot.user) {
                // Enviar usando el bot principal
                await sendSuggestion(global.principalBot, config, senderJid, senderNumber, pushName, groupName, groupId, texto);
            } else {
                // Si no hay bot principal, enviar desde el bot actual
                console.log('[SUGGEST] No se encontró bot principal, enviando desde el actual');
                await sendSuggestion(sock, config, senderJid, senderNumber, pushName, groupName, groupId, texto);
            }
            
            // Responder al usuario confirmando (SIEMPRE desde el bot actual)
            await sock.sendMessage(from, {
                text: `🌠 Tu Sugerencia fue enviada.\n> Gracias por tu sugerencia ฅ⁠^⁠•⁠ﻌ⁠•⁠^⁠ฅ`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
        } catch (error) {
            console.error('Error en suggest:', error);
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ Error al enviar sugerencia: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};

// Función para enviar la sugerencia
async function sendSuggestion(botSocket, config, senderJid, senderNumber, pushName, groupName, groupId, texto) {
    try {
        // Construir el mensaje de sugerencia
        const suggestionText = 
`ᨙᨐ͜᷍ᨏㅤsuggest ⪨꯭⪨

ᣟ🌠᪲ᤢᣟ Nombre » *${pushName || 'Usuario sin nombre'}*
ᣟ🌠᪲ᤢᣟ Tag » @${senderNumber}
ᣟ🌠᪲ᤢᣟ Número » *${senderNumber}*
ᣟ🌠᪲ᤢᣟ Grupo » *${groupName}*
ᣟ🌠᪲ᤢᣟ Id » *${groupId}*
ᣟ🌠᪲ᤢᣟ Sugerencia » *${texto}*`;

        // Buscar el banner
        const bannerPath = path.join(process.cwd(), 'img', 'banner.jpg');
        let bannerBuffer = null;
        
        try {
            if (fs.existsSync(bannerPath)) {
                bannerBuffer = fs.readFileSync(bannerPath);
                console.log('✅ Banner cargado para suggest');
            }
        } catch (error) {
            console.log('⚠️ No se pudo cargar el banner:', error.message);
        }

        // Preparar el mensaje
        const messageData = {
            text: suggestionText,
            mentions: [senderJid],
            contextInfo: {
                mentionedJid: [senderJid],
                forwardingScore: 9999999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.canalId || '',
                    serverMessageId: 0,
                    newsletterName: config.canalNombre || ''
                }
            }
        };

        // Añadir banner si existe
        if (bannerBuffer) {
            messageData.contextInfo.externalAdReply = {
                title: `🌠 NUEVA SUGERENCIA 🌠`,
                body: `De: ${pushName || 'Usuario'}`,
                thumbnail: bannerBuffer,
                mediaType: 1,
                showAdAttribution: false,
                renderLargerThumbnail: true
            };
        }

        // Enviar al grupo de sugerencias
        await botSocket.sendMessage(SUGGEST_GROUP_ID, messageData);
        
        console.log(`📝 Sugerencia enviada al grupo ${SUGGEST_GROUP_ID} desde ${pushName || senderNumber}`);
        
    } catch (error) {
        console.error('Error enviando sugerencia al grupo:', error);
        throw error;
    }
}