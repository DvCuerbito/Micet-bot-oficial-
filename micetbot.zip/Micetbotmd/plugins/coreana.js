import axios from 'axios';

export default {
    name: 'coreana',
    alias: ['korea', 'korean'],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderJid, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            try {
                await sock.sendMessage(from, { react: { text: '🇰🇷', key: msg.key } });
            } catch (e) {}
            
            const response = await axios.get('https://api.siputzx.my.id/api/r/cecan/korea', {
                responseType: 'arraybuffer',
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (!response.data || response.data.length === 0) {
                throw new Error('No se pudo obtener la imagen');
            }
            
            const imageBuffer = Buffer.from(response.data);
            
            await sock.sendMessage(from, {
                image: imageBuffer,
                caption: `> Solicitado por: ${pushName || 'Usuario'}`,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Imagen coreana enviada por ${pushName || 'Usuario'}`);
            
        } catch (error) {
            console.error('❌ Error en coreana:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(
                `❌ *Error:* No se pudo obtener la imagen. Intenta más tarde.`,
                []
            );
        }
    }
};
