import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'setname',
    alias: ['setnombre'],
    
    async execute(sock, msg, options) {
        try {
            const { config, sender, args, senderNumber } = options;
            const from = msg.key.remoteJid;
            
            // ==========================================
            // OBTENER NÚMERO DEL BOT
            // ==========================================
            let botNumber = '';
            if (sock.phoneNumber) {
                botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            if (!botNumber) {
                throw new Error('No se pudo identificar el número del bot');
            }
            
            // ==========================================
            // VERIFICAR SI EL USUARIO ES EL BOTOWNER
            // ==========================================
            const isBotOwner = config.botowner && 
                              config.botowner.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '');
            
            if (!isBotOwner) {
                // Mensaje personalizado para no autorizados
                await sock.sendMessage(from, {
                    text: `❀ *Solo el dueño del bot puede cambiar su nombre*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar que se proporcionó un nombre
            if (!args || args.length === 0) {
                await sock.sendMessage(from, {
                    text: `🫧 *Formato incorrecto*\n> Uso: *${config.prefix}setname +NombreDelBot*\n> Ejemplo: *${config.prefix}setname +Moonlight Bot*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Obtener el nombre (unir todos los argumentos)
            let newName = args.join(' ');
            
            // Eliminar el '+' si está presente al inicio
            if (newName.startsWith('+')) {
                newName = newName.substring(1).trim();
            }
            
            // Verificar que el nombre no esté vacío
            if (!newName || newName.length === 0) {
                await sock.sendMessage(from, {
                    text: `🫧 *El nombre no puede estar vacío*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            try {
                console.log(`📝 Botowner ${senderNumber} está cambiando el nombre del bot ${botNumber}...`);
                
                // ==========================================
                // RUTA DEL ARCHIVO DE CONFIGURACIÓN
                // ==========================================
                const configPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
                
                if (!fs.existsSync(configPath)) {
                    throw new Error(`No se encontró configuración para el bot ${botNumber}`);
                }
                
                console.log(`📝 Leyendo configuración actual de: ${configPath}`);
                
                // Leer el archivo actual
                let configContent = fs.readFileSync(configPath, 'utf8');
                
                // Extraer el objeto JSON
                const jsonMatch = configContent.match(/export default\s+({[\s\S]*})/);
                if (!jsonMatch || !jsonMatch[1]) {
                    throw new Error('Formato de archivo config.js inválido');
                }
                
                // Evaluar el objeto actual
                const currentConfig = eval('(' + jsonMatch[1] + ')');
                
                // ==========================================
                // ACTUALIZAR EL NOMBRE
                // ==========================================
                // Guardar el nombre original en name1 si no existe
                if (!currentConfig.name1 && currentConfig.name) {
                    currentConfig.name1 = currentConfig.name;
                }
                
                // Actualizar name y name1
                currentConfig.name = newName;
                currentConfig.name1 = newName;
                
                console.log(`📝 Actualizando nombre de "${currentConfig.name1}" a "${newName}"`);
                
                // ==========================================
                // GUARDAR EL ARCHIVO ACTUALIZADO
                // ==========================================
                const newConfigContent = `// Configuración del Bot - ${currentConfig.tipo || 'Sub-Bot'}
// Creado para el número: ${botNumber}
// Actualizado el: ${new Date().toLocaleString()}

export default ${JSON.stringify(currentConfig, null, 2)}
`;
                
                fs.writeFileSync(configPath, newConfigContent);
                console.log(`✅ Configuración actualizada para bot ${botNumber}`);
                
                // ==========================================
                // ENVIAR CONFIRMACIÓN
                // ==========================================
                await sock.sendMessage(from, {
                    text: `🫧 *Nombre actualizado con éxito*\n\n` +
                          `> *Nuevo nombre:* ${newName}\n` +
                          `> *Bot:* ${botNumber}\n` +
                          `> *Tipo:* ${currentConfig.tipo || 'Sub-Bot'}\n\n` +
                          `✨ Usa ${config.prefix}botinfo para ver los cambios`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
                // También actualizar en memoria si es posible
                try {
                    if (sock.botName) {
                        sock.botName = newName;
                    }
                } catch (memoryError) {}
                
            } catch (error) {
                console.error('Error en setname:', error);
                
                await sock.sendMessage(from, {
                    text: `🫧 *Error al cambiar el nombre*\n> ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
        } catch (error) {
            console.error('Error general en setname:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ Error inesperado en setname`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};
