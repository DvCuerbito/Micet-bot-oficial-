export default {
    name: 'ping',
    alias: ['speed', 'p'],

    execute: async (sock, msg, options) => {
        try {
            const { startTime, config, pushName, sender, isBotSelf, replyWithContext } = options;
            const endTime = Date.now();
            const latency = endTime - startTime;
            
            // Mensaje más limpio
            const message = `🌸 ¡Pong!\n> Velocidad: *${latency}ms*`;
            
            // Usar replyWithContext para responder al mensaje del usuario
            await replyWithContext(message, [sender]);
            
            // Mostrar en consola
            const userType = isBotSelf ? '🤖 Bot' : '👤 Usuario';
            console.log(`✅ Ping ejecutado por ${userType} ${pushName} (${latency}ms)`);
            
        } catch (error) {
            console.error('Error en comando ping:', error);
            
            // En caso de error, intentar respuesta básica
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: '❌ Error al ejecutar ping',
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
}