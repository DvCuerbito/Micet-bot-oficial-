import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'savefile',
    alias: [], // Sin alias como solicitaste
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            
            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar si el usuario es el owner (desde config.js)
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isOwner) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}savefile\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar si se proporcionó nombre de archivo
            if (!args || args.length === 0) {
                await sock.sendMessage(from, {
                    text: `💐 *Debes proporcionar el nombre de un archivo y responder a un texto*\n> *Ejemplo* » ${config.prefix}savefile plugins/ping.js\n> ${config.prefix}savefile index.js\n> ${config.prefix}savefile lib/sticker.js`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar si se respondió a un mensaje
            if (!quoted) {
                await sock.sendMessage(from, {
                    text: `💐 *Debes responder a un texto*`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar si el mensaje citado es de texto
            const messageType = Object.keys(quoted)[0];
            
            if (messageType !== 'conversation' && messageType !== 'extendedTextMessage') {
                await sock.sendMessage(from, {
                    text: `💐 *Debes responder a un texto*`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Obtener el texto del mensaje citado
            const texto = quoted.conversation || 
                         quoted.extendedTextMessage?.text || 
                         '';
            
            if (!texto.trim()) {
                await sock.sendMessage(from, {
                    text: `💐 *El texto está vacío*`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);
            
            // Obtener nombre del archivo
            const fileName = args[0];
            
            // Prevenir acceso a directorios padres
            if (fileName.includes('..')) {
                await sock.sendMessage(from, {
                    text: `💐 *Nombre no válido*\n> No se permiten rutas con '..'`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Obtener la ruta base del proyecto (una carpeta arriba de commands)
            const baseDir = path.join(__dirname, '..');
            const filePath = path.join(baseDir, fileName);
            
            // Crear directorios si no existen
            const dirPath = path.dirname(filePath);
            if (!fs.existsSync(dirPath)) {
                fs.mkdirSync(dirPath, { recursive: true });
                console.log(`📁 Directorio creado: ${dirPath}`);
            }
            
            // Verificar si el archivo ya existe
            const fileExists = fs.existsSync(filePath);
            
            // Guardar/actualizar el archivo
            fs.writeFileSync(filePath, texto, 'utf8');
            
            // Verificar que se guardó correctamente
            if (!fs.existsSync(filePath)) {
                throw new Error('No se pudo crear el archivo');
            }
            
            // Obtener estadísticas del archivo
            const stats = fs.statSync(filePath);
            
            // Responder según si se creó o actualizó (con letras normales)
            if (fileExists) {
                await sock.sendMessage(from, {
                    text: `🌹 *Archivo Actualizado*\n\n🍃 *Nombre:* ${fileName}\n🍃 *Tamaño:* ${stats.size} bytes\n🍃 *Modificado:* ${new Date().toLocaleTimeString()}\n\n> Archivo actualizado correctamente.`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, {
                    text: `💤 *Archivo Creado*\n\n🍃 *Nombre:* ${fileName}\n🍃 *Tamaño:* ${stats.size} bytes\n🍃 *Ruta:* ${filePath}\n🍃 *Creado:* ${new Date().toLocaleTimeString()}\n\n> Archivo creado correctamente.`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            }
            
            console.log(`✅ Archivo ${fileExists ? 'actualizado' : 'creado'}: ${fileName} por OWNER ${pushName || senderNumber}`);
            console.log(`📏 Tamaño: ${stats.size} bytes, Ruta: ${filePath}`);
            
        } catch (error) {
            console.error('❌ Error en comando savefile:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `💐 *Error al procesar el archivo*\n> ${error.message.substring(0, 100)}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
};
