import fetch from 'node-fetch';

export default {
    name: 'loli',
    alias: [],  // Sin alias como pediste
    
    async execute(sock, msg, options) {
        try {
            const { config, sender, pushName } = options;
            const from = msg.key.remoteJid;
            
            // Obtener número del bot para configuración
            let botNumber = '';
            if (sock.phoneNumber) {
                botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            // ==========================================
            // OBTENER IMAGEN DE LA API
            // ==========================================
            const apiUrl = 'https://api.ootaizumi.web.id/random/loli';
            
            const response = await fetch(apiUrl, {
                method: 'GET',
                headers: {
                    'accept': '*/*'
                }
            });
            
            if (!response.ok) {
                throw new Error(`API respondió con error: ${response.status}`);
            }
            
            // Obtener la imagen como buffer
            const imageBuffer = await response.buffer();
            
            // Verificar que el buffer no esté vacío
            if (!imageBuffer || imageBuffer.length === 0) {
                throw new Error('La API devolvió una imagen vacía');
            }
            
            // ==========================================
            // PREPARAR MENSAJE
            // ==========================================
            const caption = `> Aquí tienes tu loli ฅ⁠^⁠•⁠ﻌ⁠•⁠^⁠ฅ`;
            
            const mentions = [sender];
            
            // ==========================================
            // ENVIAR IMAGEN
            // ==========================================
            await sock.sendMessage(from, {
                image: imageBuffer,
                caption: caption,
                mentions: mentions,
                mimetype: 'image/jpeg',
                contextInfo: {
                    mentionedJid: mentions,
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || '⭐̸̷᪲ 𝕸𝖔𝖔𝖓𝖑𝖎𝖌𝖍𝖙 𝕸𝖊𝖓𝖚 ♡⃘꤬֟🎑ꨩּ݄҇ᬊ໋۟'
                    }
                }
            }, { quoted: msg });
            
            console.log(`✅ Imagen loli enviada a ${pushName || sender}`);
            
        } catch (error) {
            console.error('❌ Error en comando loli:', error);
            
            // Intentar enviar mensaje de error
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ Error al obtener la imagen loli: ${error.message}\nIntenta de nuevo más tarde.`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('❌ Error crítico al enviar mensaje de error:', e);
            }
        }
    }
};