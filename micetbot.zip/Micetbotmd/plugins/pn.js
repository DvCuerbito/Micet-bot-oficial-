import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Mapa completo de códigos de país con nombres y banderas
const countryData = {
    // América
    '1': { name: 'Estados Unidos', flag: '🇺🇸' },
    '1-1': { name: 'Canadá', flag: '🇨🇦' }, // Canadá también usa +1
    
    // América Latina y Caribe
    '52': { name: 'México', flag: '🇲🇽' },
    '53': { name: 'Cuba', flag: '🇨🇺' },
    '54': { name: 'Argentina', flag: '🇦🇷' },
    '55': { name: 'Brasil', flag: '🇧🇷' },
    '56': { name: 'Chile', flag: '🇨🇱' },
    '57': { name: 'Colombia', flag: '🇨🇴' },
    '58': { name: 'Venezuela', flag: '🇻🇪' },
    '591': { name: 'Bolivia', flag: '🇧🇴' },
    '592': { name: 'Guyana', flag: '🇬🇾' },
    '593': { name: 'Ecuador', flag: '🇪🇨' },
    '594': { name: 'Guayana Francesa', flag: '🇬🇫' },
    '595': { name: 'Paraguay', flag: '🇵🇾' },
    '596': { name: 'Martinica', flag: '🇲🇶' },
    '597': { name: 'Surinam', flag: '🇸🇷' },
    '598': { name: 'Uruguay', flag: '🇺🇾' },
    '599': { name: 'Antillas Neerlandesas', flag: '🇧🇶' },
    '501': { name: 'Belice', flag: '🇧🇿' },
    '502': { name: 'Guatemala', flag: '🇬🇹' },
    '503': { name: 'El Salvador', flag: '🇸🇻' },
    '504': { name: 'Honduras', flag: '🇭🇳' },
    '505': { name: 'Nicaragua', flag: '🇳🇮' },
    '506': { name: 'Costa Rica', flag: '🇨🇷' },
    '507': { name: 'Panamá', flag: '🇵🇦' },
    '508': { name: 'San Pedro y Miquelón', flag: '🇵🇲' },
    '509': { name: 'Haití', flag: '🇭🇹' },
    '1-264': { name: 'Anguila', flag: '🇦🇮' },
    '1-268': { name: 'Antigua y Barbuda', flag: '🇦🇬' },
    '1-242': { name: 'Bahamas', flag: '🇧🇸' },
    '1-246': { name: 'Barbados', flag: '🇧🇧' },
    '1-441': { name: 'Bermudas', flag: '🇧🇲' },
    '1-284': { name: 'Islas Vírgenes Británicas', flag: '🇻🇬' },
    '1-345': { name: 'Islas Caimán', flag: '🇰🇾' },
    '1-767': { name: 'Dominica', flag: '🇩🇲' },
    '1-809': { name: 'República Dominicana', flag: '🇩🇴' },
    '1-829': { name: 'República Dominicana', flag: '🇩🇴' },
    '1-849': { name: 'República Dominicana', flag: '🇩🇴' },
    '1-473': { name: 'Granada', flag: '🇬🇩' },
    '1-671': { name: 'Guam', flag: '🇬🇺' },
    '1-876': { name: 'Jamaica', flag: '🇯🇲' },
    '1-658': { name: 'Jamaica', flag: '🇯🇲' },
    '1-664': { name: 'Montserrat', flag: '🇲🇸' },
    '1-787': { name: 'Puerto Rico', flag: '🇵🇷' },
    '1-939': { name: 'Puerto Rico', flag: '🇵🇷' },
    '1-869': { name: 'San Cristóbal y Nieves', flag: '🇰🇳' },
    '1-758': { name: 'Santa Lucía', flag: '🇱🇨' },
    '1-784': { name: 'San Vicente y las Granadinas', flag: '🇻🇨' },
    '1-868': { name: 'Trinidad y Tobago', flag: '🇹🇹' },
    '1-649': { name: 'Islas Turcas y Caicos', flag: '🇹🇨' },
    '1-340': { name: 'Islas Vírgenes de EE.UU.', flag: '🇻🇮' },
    
    // Europa
    '30': { name: 'Grecia', flag: '🇬🇷' },
    '31': { name: 'Países Bajos', flag: '🇳🇱' },
    '32': { name: 'Bélgica', flag: '🇧🇪' },
    '33': { name: 'Francia', flag: '🇫🇷' },
    '34': { name: 'España', flag: '🇪🇸' },
    '36': { name: 'Hungría', flag: '🇭🇺' },
    '39': { name: 'Italia', flag: '🇮🇹' },
    '40': { name: 'Rumania', flag: '🇷🇴' },
    '41': { name: 'Suiza', flag: '🇨🇭' },
    '43': { name: 'Austria', flag: '🇦🇹' },
    '44': { name: 'Reino Unido', flag: '🇬🇧' },
    '45': { name: 'Dinamarca', flag: '🇩🇰' },
    '46': { name: 'Suecia', flag: '🇸🇪' },
    '47': { name: 'Noruega', flag: '🇳🇴' },
    '48': { name: 'Polonia', flag: '🇵🇱' },
    '49': { name: 'Alemania', flag: '🇩🇪' },
    '350': { name: 'Gibraltar', flag: '🇬🇮' },
    '351': { name: 'Portugal', flag: '🇵🇹' },
    '352': { name: 'Luxemburgo', flag: '🇱🇺' },
    '353': { name: 'Irlanda', flag: '🇮🇪' },
    '354': { name: 'Islandia', flag: '🇮🇸' },
    '355': { name: 'Albania', flag: '🇦🇱' },
    '356': { name: 'Malta', flag: '🇲🇹' },
    '357': { name: 'Chipre', flag: '🇨🇾' },
    '358': { name: 'Finlandia', flag: '🇫🇮' },
    '359': { name: 'Bulgaria', flag: '🇧🇬' },
    '370': { name: 'Lituania', flag: '🇱🇹' },
    '371': { name: 'Letonia', flag: '🇱🇻' },
    '372': { name: 'Estonia', flag: '🇪🇪' },
    '373': { name: 'Moldavia', flag: '🇲🇩' },
    '374': { name: 'Armenia', flag: '🇦🇲' },
    '375': { name: 'Bielorrusia', flag: '🇧🇾' },
    '376': { name: 'Andorra', flag: '🇦🇩' },
    '377': { name: 'Mónaco', flag: '🇲🇨' },
    '378': { name: 'San Marino', flag: '🇸🇲' },
    '379': { name: 'Ciudad del Vaticano', flag: '🇻🇦' },
    '380': { name: 'Ucrania', flag: '🇺🇦' },
    '381': { name: 'Serbia', flag: '🇷🇸' },
    '382': { name: 'Montenegro', flag: '🇲🇪' },
    '383': { name: 'Kosovo', flag: '🇽🇰' },
    '385': { name: 'Croacia', flag: '🇭🇷' },
    '386': { name: 'Eslovenia', flag: '🇸🇮' },
    '387': { name: 'Bosnia y Herzegovina', flag: '🇧🇦' },
    '389': { name: 'Macedonia del Norte', flag: '🇲🇰' },
    '420': { name: 'República Checa', flag: '🇨🇿' },
    '421': { name: 'Eslovaquia', flag: '🇸🇰' },
    '423': { name: 'Liechtenstein', flag: '🇱🇮' },
    
    // Asia
    '60': { name: 'Malasia', flag: '🇲🇾' },
    '61': { name: 'Australia', flag: '🇦🇺' },
    '62': { name: 'Indonesia', flag: '🇮🇩' },
    '63': { name: 'Filipinas', flag: '🇵🇭' },
    '64': { name: 'Nueva Zelanda', flag: '🇳🇿' },
    '65': { name: 'Singapur', flag: '🇸🇬' },
    '66': { name: 'Tailandia', flag: '🇹🇭' },
    '81': { name: 'Japón', flag: '🇯🇵' },
    '82': { name: 'Corea del Sur', flag: '🇰🇷' },
    '84': { name: 'Vietnam', flag: '🇻🇳' },
    '86': { name: 'China', flag: '🇨🇳' },
    '90': { name: 'Turquía', flag: '🇹🇷' },
    '91': { name: 'India', flag: '🇮🇳' },
    '92': { name: 'Pakistán', flag: '🇵🇰' },
    '93': { name: 'Afganistán', flag: '🇦🇫' },
    '94': { name: 'Sri Lanka', flag: '🇱🇰' },
    '95': { name: 'Myanmar', flag: '🇲🇲' },
    '98': { name: 'Irán', flag: '🇮🇷' },
    '212': { name: 'Marruecos', flag: '🇲🇦' },
    '213': { name: 'Argelia', flag: '🇩🇿' },
    '216': { name: 'Túnez', flag: '🇹🇳' },
    '218': { name: 'Libia', flag: '🇱🇾' },
    '220': { name: 'Gambia', flag: '🇬🇲' },
    '221': { name: 'Senegal', flag: '🇸🇳' },
    '222': { name: 'Mauritania', flag: '🇲🇷' },
    '223': { name: 'Malí', flag: '🇲🇱' },
    '224': { name: 'Guinea', flag: '🇬🇳' },
    '225': { name: 'Costa de Marfil', flag: '🇨🇮' },
    '226': { name: 'Burkina Faso', flag: '🇧🇫' },
    '227': { name: 'Níger', flag: '🇳🇪' },
    '228': { name: 'Togo', flag: '🇹🇬' },
    '229': { name: 'Benín', flag: '🇧🇯' },
    '230': { name: 'Mauricio', flag: '🇲🇺' },
    '231': { name: 'Liberia', flag: '🇱🇷' },
    '232': { name: 'Sierra Leona', flag: '🇸🇱' },
    '233': { name: 'Ghana', flag: '🇬🇭' },
    '234': { name: 'Nigeria', flag: '🇳🇬' },
    '235': { name: 'Chad', flag: '🇹🇩' },
    '236': { name: 'República Centroafricana', flag: '🇨🇫' },
    '237': { name: 'Camerún', flag: '🇨🇲' },
    '238': { name: 'Cabo Verde', flag: '🇨🇻' },
    '239': { name: 'Santo Tomé y Príncipe', flag: '🇸🇹' },
    '240': { name: 'Guinea Ecuatorial', flag: '🇬🇶' },
    '241': { name: 'Gabón', flag: '🇬🇦' },
    '242': { name: 'República del Congo', flag: '🇨🇬' },
    '243': { name: 'República Democrática del Congo', flag: '🇨🇩' },
    '244': { name: 'Angola', flag: '🇦🇴' },
    '245': { name: 'Guinea-Bisáu', flag: '🇬🇼' },
    '246': { name: 'Diego García', flag: '🇮🇴' },
    '247': { name: 'Isla Ascensión', flag: '🇦🇨' },
    '248': { name: 'Seychelles', flag: '🇸🇨' },
    '249': { name: 'Sudán', flag: '🇸🇩' },
    '250': { name: 'Ruanda', flag: '🇷🇼' },
    '251': { name: 'Etiopía', flag: '🇪🇹' },
    '252': { name: 'Somalia', flag: '🇸🇴' },
    '253': { name: 'Yibuti', flag: '🇩🇯' },
    '254': { name: 'Kenia', flag: '🇰🇪' },
    '255': { name: 'Tanzania', flag: '🇹🇿' },
    '256': { name: 'Uganda', flag: '🇺🇬' },
    '257': { name: 'Burundi', flag: '🇧🇮' },
    '258': { name: 'Mozambique', flag: '🇲🇿' },
    '259': { name: 'Zanzíbar', flag: '🇹🇿' },
    '260': { name: 'Zambia', flag: '🇿🇲' },
    '261': { name: 'Madagascar', flag: '🇲🇬' },
    '262': { name: 'Reunión', flag: '🇷🇪' },
    '263': { name: 'Zimbabue', flag: '🇿🇼' },
    '264': { name: 'Namibia', flag: '🇳🇦' },
    '265': { name: 'Malawi', flag: '🇲🇼' },
    '266': { name: 'Lesoto', flag: '🇱🇸' },
    '267': { name: 'Botsuana', flag: '🇧🇼' },
    '268': { name: 'Suazilandia', flag: '🇸🇿' },
    '269': { name: 'Comoras', flag: '🇰🇲' },
    '290': { name: 'Santa Elena', flag: '🇸🇭' },
    '291': { name: 'Eritrea', flag: '🇪🇷' },
    '297': { name: 'Aruba', flag: '🇦🇼' },
    '298': { name: 'Islas Feroe', flag: '🇫🇴' },
    '299': { name: 'Groenlandia', flag: '🇬🇱' },
    
    // Medio Oriente
    '20': { name: 'Egipto', flag: '🇪🇬' },
    '212': { name: 'Marruecos', flag: '🇲🇦' },
    '213': { name: 'Argelia', flag: '🇩🇿' },
    '216': { name: 'Túnez', flag: '🇹🇳' },
    '218': { name: 'Libia', flag: '🇱🇾' },
    '961': { name: 'Líbano', flag: '🇱🇧' },
    '962': { name: 'Jordania', flag: '🇯🇴' },
    '963': { name: 'Siria', flag: '🇸🇾' },
    '964': { name: 'Irak', flag: '🇮🇶' },
    '965': { name: 'Kuwait', flag: '🇰🇼' },
    '966': { name: 'Arabia Saudita', flag: '🇸🇦' },
    '967': { name: 'Yemen', flag: '🇾🇪' },
    '968': { name: 'Omán', flag: '🇴🇲' },
    '970': { name: 'Palestina', flag: '🇵🇸' },
    '971': { name: 'Emiratos Árabes Unidos', flag: '🇦🇪' },
    '972': { name: 'Israel', flag: '🇮🇱' },
    '973': { name: 'Baréin', flag: '🇧🇭' },
    '974': { name: 'Catar', flag: '🇶🇦' },
    '975': { name: 'Bután', flag: '🇧🇹' },
    '976': { name: 'Mongolia', flag: '🇲🇳' },
    '977': { name: 'Nepal', flag: '🇳🇵' },
    '992': { name: 'Tayikistán', flag: '🇹🇯' },
    '993': { name: 'Turkmenistán', flag: '🇹🇲' },
    '994': { name: 'Azerbaiyán', flag: '🇦🇿' },
    '995': { name: 'Georgia', flag: '🇬🇪' },
    '996': { name: 'Kirguistán', flag: '🇰🇬' },
    '998': { name: 'Uzbekistán', flag: '🇺🇿' },
    
    // Oceanía
    '61': { name: 'Australia', flag: '🇦🇺' },
    '64': { name: 'Nueva Zelanda', flag: '🇳🇿' },
    '674': { name: 'Nauru', flag: '🇳🇷' },
    '675': { name: 'Papúa Nueva Guinea', flag: '🇵🇬' },
    '676': { name: 'Tonga', flag: '🇹🇴' },
    '677': { name: 'Islas Salomón', flag: '🇸🇧' },
    '678': { name: 'Vanuatu', flag: '🇻🇺' },
    '679': { name: 'Fiyi', flag: '🇫🇯' },
    '680': { name: 'Palau', flag: '🇵🇼' },
    '681': { name: 'Wallis y Futuna', flag: '🇼🇫' },
    '682': { name: 'Islas Cook', flag: '🇨🇰' },
    '683': { name: 'Niue', flag: '🇳🇺' },
    '685': { name: 'Samoa', flag: '🇼🇸' },
    '686': { name: 'Kiribati', flag: '🇰🇮' },
    '687': { name: 'Nueva Caledonia', flag: '🇳🇨' },
    '688': { name: 'Tuvalu', flag: '🇹🇻' },
    '689': { name: 'Polinesia Francesa', flag: '🇵🇫' },
    '690': { name: 'Tokelau', flag: '🇹🇰' },
    '691': { name: 'Micronesia', flag: '🇫🇲' },
    '692': { name: 'Islas Marshall', flag: '🇲🇭' }
};

// Función para obtener código de país y país desde un número de teléfono
function getCountryFromNumber(phoneNumber) {
    try {
        // Limpiar el número: eliminar @s.whatsapp.net, + y espacios
        let cleanNumber = phoneNumber.split('@')[0];
        cleanNumber = cleanNumber.replace(/[^0-9]/g, '');
        
        // Ordenar códigos de mayor a menor longitud para encontrar la mejor coincidencia
        const sortedCodes = Object.keys(countryData).sort((a, b) => b.length - a.length);
        
        for (const code of sortedCodes) {
            if (cleanNumber.startsWith(code)) {
                const country = countryData[code];
                return {
                    code: code,
                    name: country.name,
                    flag: country.flag
                };
            }
        }
        
        // Si no se encuentra, intentar con código de 1-3 dígitos
        if (cleanNumber.startsWith('1')) {
            return { code: '1', name: 'Estados Unidos/Canadá', flag: '🇺🇸🇨🇦' };
        } else if (cleanNumber.startsWith('52')) {
            return { code: '52', name: 'México', flag: '🇲🇽' };
        } else if (cleanNumber.startsWith('34')) {
            return { code: '34', name: 'España', flag: '🇪🇸' };
        } else if (cleanNumber.startsWith('44')) {
            return { code: '44', name: 'Reino Unido', flag: '🇬🇧' };
        } else if (cleanNumber.startsWith('33')) {
            return { code: '33', name: 'Francia', flag: '🇫🇷' };
        } else if (cleanNumber.startsWith('49')) {
            return { code: '49', name: 'Alemania', flag: '🇩🇪' };
        } else if (cleanNumber.startsWith('39')) {
            return { code: '39', name: 'Italia', flag: '🇮🇹' };
        }
        
        return {
            code: '??',
            name: 'Desconocido',
            flag: '🌍'
        };
    } catch (error) {
        console.log('Error al obtener país:', error);
        return {
            code: '??',
            name: 'Error',
            flag: '❌'
        };
    }
}

export default {
    name: 'pn',
    alias: ['numero', 'telefono'],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderJid } = options;
            const from = msg.key.remoteJid;
            
            // Obtener el número del usuario que ejecutó el comando
            const userNumber = senderJid || '';
            
            // Obtener información del país
            const countryInfo = getCountryFromNumber(userNumber);
            
            // Formatear el mensaje con la información del país
            const message = `𓊔꯭ֹ𓋰꯭᪲͡𓋰꯭֔𓊔ֵNUMBER𓊔꯭ֹ𓋰꯭᪲͡𓋰꯭֔𓊔ֵ
 𑂠۪𔖳〪𝆬𐨂⭐ᩙᰰ〪〫ᮬ᳘ ۪𔘺 ᪲᪲ *${userNumber}*
 𑂠۪𔖳〪𝆬𐨂⭐ᩙᰰ〪〫ᮬ᳘ ۪𔘺 ᪲᪲ *+${countryInfo.code}*
 𑂠۪𔖳〪𝆬𐨂⭐ᩙᰰ〪〫ᮬ᳘ ۪𔘺 ᪲᪲ *${countryInfo.name} ${countryInfo.flag}*`;
            
            console.log('🔍 Comando pn ejecutado:');
            console.log('  Sender JID:', userNumber);
            console.log('  País:', countryInfo.name, countryInfo.flag);
            console.log('  Código:', countryInfo.code);
            
            // Enviar mensaje
            await sock.sendMessage(from, {
                text: message,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            console.log(`✅ Comando pn ejecutado para: ${userNumber}`);
            
        } catch (error) {
            console.log(`❌ Error en comando pn:`, error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❖ Error al ejecutar el comando: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};