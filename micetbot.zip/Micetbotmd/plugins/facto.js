import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Función para cargar factos desde el JSON
function loadFactos() {
    try {
        const factosPath = path.join(__dirname, '..', 'databases', 'factos.json');
        if (fs.existsSync(factosPath)) {
            const data = fs.readFileSync(factosPath, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando factos.json:', error);
    }
    
    // Factos por defecto si no existe el archivo
    return [
        "Eres la razón por la que hay instrucciones en los champús.",
        "Si fueras un libro, serías el que nadie quiere leer.",
        "Tu vida es como un programa de televisión que nadie ve."
    ];
}

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}

export default {
    name: 'facto',
    alias: ['factos'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🌸 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Verificar que sea un grupo
            if (!from.includes('@g.us')) {
                await sock.sendMessage(from, {
                    text: `🌸 Este comando solo funciona en grupos.`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            // Mensaje de búsqueda
            await sock.sendMessage(from, {
                text: '🌸 Buscando un facto, espere un momento...',
                contextInfo: {
                    mentionedJid: [senderJid],
                    externalAdReply: {
                        title: config.name || '',
                        body: `Solicitado por: ${pushName || senderNumber}`,
                        mediaType: 1,
                        thumbnailUrl: 'https://i.postimg.cc/gcTfxfYg/16d562a00992e644e93b4c5093d4f028.jpg',
                        sourceUrl: config.canalUrl || 'https://whatsapp.com/channel/0029Vb6qIht5q08ZMPggVrA1y',
                        showAdAttribution: false,
                        renderLargerThumbnail: false
                    },
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });

            // Cargar factos
            const factos = loadFactos();
            const factoSeleccionado = pickRandom(factos);

            // Construir mensaje con diseño original pero letras normales
            const factoMessage = `┏━_͜͡-͜͡-͜͡-͜͡-͜͡-͜͡-͜͡🌸-͜͡-͜͡-͜͡-͜͡-͜͡-͜͡-͜͡🌸-͜͡-͜͡-͜͡-͜͡-͜͡-͜͡-͜͡🌸-͜͡-͜͡-͜͡-͜͡-͜͡-͜͡_͜͡━┓\n\n❥ *"${factoSeleccionado}"*\n\n┗━_͜͡-͜͡-͜͡-͜͡-͜͡-͜͡-͜͡🌸-͜͡-͜͡-͜͡-͜͡-͜͡-͜͡-͜͡🌸-͜͡-͜͡-͜͡-͜͡-͜͡-͜͡-͜͡🌸-͜͡-͜͡-͜͡-͜͡-͜͡-͜͡_͜͡━┛`;

            // Enviar resultado
            await sock.sendMessage(from, {
                text: factoMessage,
                contextInfo: {
                    mentionedJid: [senderJid],
                    externalAdReply: {
                        title: config.name || 'Shinobu Bot',
                        body: `Facto para: ${pushName || senderNumber}`,
                        mediaType: 1,
                        thumbnailUrl: 'https://i.postimg.cc/gcTfxfYg/16d562a00992e644e93b4c5093d4f028.jpg',
                        sourceUrl: config.canalUrl || 'https://whatsapp.com/channel/0029Vb6qIht5q08ZMPggVrA1y',
                        showAdAttribution: false,
                        renderLargerThumbnail: false
                    },
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });

            console.log(`🌸 Facto enviado a ${pushName || senderNumber}: ${factoSeleccionado.substring(0, 50)}...`);

        } catch (error) {
            console.error('❌ Error en comando facto:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `🌸 Error al obtener un facto: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};
