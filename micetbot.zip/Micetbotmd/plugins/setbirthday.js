import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERS_FILE = path.join(__dirname, '..', 'databases', 'users.json');

function loadUsersDB() {
    try {
        if (fs.existsSync(USERS_FILE)) {
            return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando users.json:', error);
        return {};
    }
}

function saveUsersDB(users) {
    try {
        fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando users.json:', error);
        return false;
    }
}

export default {
    name: 'setbirthday',
    alias: ['setcumple', 'setbd'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderNumber, senderJid, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const birthday = args.join(' ').trim();
            
            if (!birthday) {
                await replyWithContext(
                    `🌟 Debes proporcionar tu fecha de cumpleaños\n> Formato: DD/MM\n> Ejemplo: 15/08`,
                    []
                );
                return;
            }
            
            // Validar formato DD/MM
            const birthdayRegex = /^(\d{1,2})\/(\d{1,2})$/;
            const match = birthday.match(birthdayRegex);
            
            if (!match) {
                await replyWithContext(
                    `🌟 Formato incorrecto\n> Usa el formato: DD/MM\n> Ejemplo: 15/08`,
                    []
                );
                return;
            }
            
            const day = parseInt(match[1]);
            const month = parseInt(match[2]);
            
            if (day < 1 || day > 31) {
                await replyWithContext(`🌟 Día inválido. Debe ser entre 1 y 31`, []);
                return;
            }
            
            if (month < 1 || month > 12) {
                await replyWithContext(`🌟 Mes inválido. Debe ser entre 1 y 12`, []);
                return;
            }
            
            const users = loadUsersDB();
            
            if (!users[senderNumber]) {
                users[senderNumber] = {
                    number: senderNumber,
                    pushName: pushName || 'Usuario',
                    registered: new Date().toISOString()
                };
            }
            
            users[senderNumber].birthday = birthday;
            saveUsersDB(users);
            
            await replyWithContext(
                `🌵 Cumpleaños establecido con éxito: ${birthday}`,
                []
            );
            
        } catch (error) {
            console.error('❌ Error en setbirthday:', error);
            await replyWithContext(`❌ Error: ${error.message}`, []);
        }
    }
};