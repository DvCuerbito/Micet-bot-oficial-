import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const API_URL = 'https://neji-api.vercel.app/api/downloader/mediafire';

const tempFolder = path.join(__dirname, '..', 'tmp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `mediafire_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

function getFileTypeInfo(filename, fileType) {
    const lowerName = filename.toLowerCase();
    const type = fileType || '';
    
    // APK y variantes
    if (type === '.apk' || lowerName.endsWith('.apk')) {
        return { type: 'apk', emoji: '📱', name: 'APK (Android App)' };
    }
    if (lowerName.includes('apk+') || lowerName.includes('apkplus')) {
        return { type: 'apkplus', emoji: '📱✨', name: 'APK+ (App Modificada)' };
    }
    
    // Minecraft packs
    if (type === '.mcpack' || lowerName.endsWith('.mcpack')) {
        return { type: 'mcpack', emoji: '🎮', name: 'Minecraft Pack (.mcpack)' };
    }
    if (type === '.mcaddon' || lowerName.endsWith('.mcaddon')) {
        return { type: 'mcaddon', emoji: '🎮', name: 'Minecraft Addon' };
    }
    if (type === '.mcworld' || lowerName.endsWith('.mcworld')) {
        return { type: 'mcworld', emoji: '🌍', name: 'Minecraft World' };
    }
    if (type === '.mctemplate' || lowerName.endsWith('.mctemplate')) {
        return { type: 'mctemplate', emoji: '📐', name: 'Minecraft Template' };
    }
    
    // Archivos comprimidos
    if (type === '.zip' || lowerName.endsWith('.zip')) {
        return { type: 'zip', emoji: '🗜️', name: 'Archivo ZIP' };
    }
    if (type === '.rar' || lowerName.endsWith('.rar')) {
        return { type: 'rar', emoji: '🗜️', name: 'Archivo RAR' };
    }
    if (type === '.7z' || lowerName.endsWith('.7z')) {
        return { type: '7z', emoji: '🗜️', name: 'Archivo 7Z' };
    }
    
    // Videos
    if (type === '.mp4' || lowerName.endsWith('.mp4')) {
        return { type: 'video', emoji: '🎬', name: 'Video MP4' };
    }
    if (type === '.mkv' || lowerName.endsWith('.mkv')) {
        return { type: 'video', emoji: '🎬', name: 'Video MKV' };
    }
    
    // Audios
    if (type === '.mp3' || lowerName.endsWith('.mp3')) {
        return { type: 'audio', emoji: '🎵', name: 'Audio MP3' };
    }
    
    // Imágenes
    if (type === '.jpg' || type === '.jpeg' || lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg')) {
        return { type: 'image', emoji: '🖼️', name: 'Imagen JPG' };
    }
    if (type === '.png' || lowerName.endsWith('.png')) {
        return { type: 'image', emoji: '🖼️', name: 'Imagen PNG' };
    }
    
    // Documentos
    if (type === '.pdf' || lowerName.endsWith('.pdf')) {
        return { type: 'pdf', emoji: '📄', name: 'Documento PDF' };
    }
    if (type === '.txt' || lowerName.endsWith('.txt')) {
        return { type: 'text', emoji: '📝', name: 'Texto' };
    }
    
    // Ejecutables
    if (type === '.exe' || lowerName.endsWith('.exe')) {
        return { type: 'exe', emoji: '⚙️', name: 'Ejecutable EXE' };
    }
    
    return { type: 'file', emoji: '📁', name: 'Archivo' };
}

function getMimeType(filename, fileType) {
    const lowerName = filename.toLowerCase();
    const type = fileType || '';
    
    if (type === '.apk' || lowerName.endsWith('.apk')) return 'application/vnd.android.package-archive';
    if (type === '.mcpack' || lowerName.endsWith('.mcpack')) return 'application/octet-stream';
    if (type === '.mcaddon' || lowerName.endsWith('.mcaddon')) return 'application/octet-stream';
    if (type === '.mcworld' || lowerName.endsWith('.mcworld')) return 'application/octet-stream';
    if (type === '.mctemplate' || lowerName.endsWith('.mctemplate')) return 'application/octet-stream';
    if (type === '.zip' || lowerName.endsWith('.zip')) return 'application/zip';
    if (type === '.rar' || lowerName.endsWith('.rar')) return 'application/x-rar-compressed';
    if (type === '.7z' || lowerName.endsWith('.7z')) return 'application/x-7z-compressed';
    if (type === '.mp4' || lowerName.endsWith('.mp4')) return 'video/mp4';
    if (type === '.mkv' || lowerName.endsWith('.mkv')) return 'video/x-matroska';
    if (type === '.mp3' || lowerName.endsWith('.mp3')) return 'audio/mpeg';
    if (type === '.jpg' || type === '.jpeg' || lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg')) return 'image/jpeg';
    if (type === '.png' || lowerName.endsWith('.png')) return 'image/png';
    if (type === '.pdf' || lowerName.endsWith('.pdf')) return 'application/pdf';
    if (type === '.txt' || lowerName.endsWith('.txt')) return 'text/plain';
    if (type === '.exe' || lowerName.endsWith('.exe')) return 'application/x-msdownload';
    
    return 'application/octet-stream';
}

export default {
    name: 'mediafire',
    alias: ['mf', 'mediafiredl'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const url = args.join(' ').trim();
            
            if (!url) {
                await replyWithContext(
                    `🌸 Debes proporcionar un enlace de mediafire`,
                    []
                );
                return;
            }
            
            if (!url.includes('mediafire.com')) {
                await replyWithContext(
                    `❌ *Link inválido*\n\n> Debes proporcionar un enlace de Mediafire válido.`,
                    []
                );
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📥', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(`🌟 *Obteniendo información del archivo...*`, []);
            
            const infoResponse = await axios.get(`${API_URL}?url=${encodeURIComponent(url)}`, {
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (!infoResponse.data?.status || !infoResponse.data?.result) {
                throw new Error('No se pudo obtener información del archivo');
            }
            
            const result = infoResponse.data.result;
            const filename = result.filename || result.name || 'archivo';
            const fileType = result.type || '';
            const filesize = result.size || 'Desconocido';
            const downloadUrl = result.download;
            
            if (!downloadUrl) {
                throw new Error('No se pudo obtener el enlace de descarga');
            }
            
            const fileInfo = getFileTypeInfo(filename, fileType);
            
            await replyWithContext(
                `${fileInfo.emoji} *Archivo encontrado*\n\n` +
                `🍀 *Nombre:* ${filename.replace(/\+/g, ' ')}\n` +
                `🍀 *Tamaño:* ${filesize}\n` +
                `🍀 *Tipo:* ${fileInfo.name}\n\n` +
                `🛒 *Descargando archivo...* Esto puede tomar varios minutos.`,
                []
            );
            
            const fileResponse = await axios.get(downloadUrl, {
                responseType: 'stream',
                timeout: 600000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            const extension = fileType || path.extname(filename) || '.bin';
            const tempPath = getTempFilePath(extension);
            const writer = fs.createWriteStream(tempPath);
            
            await new Promise((resolve, reject) => {
                fileResponse.data.pipe(writer);
                writer.on('finish', resolve);
                writer.on('error', reject);
            });
            
            const fileBuffer = fs.readFileSync(tempPath);
            fs.unlinkSync(tempPath);
            
            const sizeMB = (fileBuffer.length / 1024 / 1024).toFixed(2);
            let cleanFilename = filename.replace(/[^a-zA-Z0-9._-]/g, '_');
            const mimetype = getMimeType(filename, fileType);
            
            await sock.sendMessage(from, {
                document: fileBuffer,
                mimetype: mimetype,
                fileName: cleanFilename,
                caption: `> Solicitado por: ${pushName || 'Usuario'}`,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Archivo descargado: ${filename} (${sizeMB} MB) - Tipo: ${fileInfo.type} por ${pushName || 'Usuario'}`);
            
        } catch (error) {
            console.error('❌ Error en mediafire:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(
                `❌ *Error:* ${error.message}\n\n> Verifica que el enlace sea válido y vuelve a intentarlo.`,
                []
            );
        }
    }
};