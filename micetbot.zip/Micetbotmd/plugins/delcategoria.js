import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const OWNER_NUMBER = "189202503315478";

export default {
    name: 'delcategoria',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, senderNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            // Solo el owner puede usar este comando (por número)
            if (senderNumber !== OWNER_NUMBER) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}delcategoria\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const categoryName = args[0]?.toLowerCase();
            if (!categoryName) {
                await sock.sendMessage(from, {
                    text: '☆ Debes proporcionar una categoría.\n> ✐ Ej : /delcategoria love',
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const categoriesFile = path.join(__dirname, '..', 'databases', 'categories.json');
            let categories = {};
            
            if (fs.existsSync(categoriesFile)) {
                categories = JSON.parse(fs.readFileSync(categoriesFile, 'utf8'));
            }

            if (!categories[categoryName]) {
                await sock.sendMessage(from, {
                    text: '❖ La categoría especificada no existe.',
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const videosDir = path.join(__dirname, '..', 'videos');
            const categoryDir = path.join(videosDir, categoryName);
            
            if (fs.existsSync(categoryDir)) {
                fs.rmSync(categoryDir, { recursive: true, force: true });
            }

            delete categories[categoryName];
            fs.writeFileSync(categoriesFile, JSON.stringify(categories, null, 2));

            const descFile = path.join(__dirname, '..', 'databases', 'gif_descriptions.json');
            if (fs.existsSync(descFile)) {
                let descriptions = JSON.parse(fs.readFileSync(descFile, 'utf8'));
                if (descriptions[categoryName]) {
                    delete descriptions[categoryName];
                    fs.writeFileSync(descFile, JSON.stringify(descriptions, null, 2));
                }
            }

            await sock.sendMessage(from, {
                text: `☆ Se ha eliminado la categoría *${categoryName}* y todos sus archivos.`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });

        } catch (error) {
            console.log('Error en comando delcategoria:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: '❖ Error al eliminar la categoría.',
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};