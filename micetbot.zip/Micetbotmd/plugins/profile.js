import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERS_FILE = path.join(__dirname, '..', 'databases', 'users.json');
const LEVEL_FILE = path.join(__dirname, '..', 'databases', 'level.json');
const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadUsersDB() {
    try {
        if (fs.existsSync(USERS_FILE)) {
            return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando users.json:', error);
        return {};
    }
}

function loadLevelDB() {
    try {
        if (fs.existsSync(LEVEL_FILE)) {
            return JSON.parse(fs.readFileSync(LEVEL_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando level.json:', error);
        return {};
    }
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economy.json:', error);
        return {};
    }
}

function cleanJid(jid) {
    if (!jid) return null;
    return jid.replace(/:\d+@/, '@');
}

function extractNumber(jid) {
    if (!jid) return null;
    let cleaned = cleanJid(jid);
    return cleaned.split('@')[0].replace(/[^0-9]/g, '');
}

async function getProfilePicture(sock, jid) {
    try {
        const ppUrl = await sock.profilePictureUrl(jid, 'image');
        if (ppUrl) {
            const response = await axios.get(ppUrl, { responseType: 'arraybuffer' });
            return Buffer.from(response.data, 'binary');
        }
    } catch (error) {
        console.log('No se pudo obtener foto de perfil:', error.message);
    }
    return null;
}

export default {
    name: 'profile',
    alias: ['perfil'],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, senderJid, pushName, replyWithContext, usersDB } = options;
            const from = msg.key.remoteJid;
            
            if (!senderNumber) {
                return await replyWithContext('❌ No se pudo identificar tu número', [senderJid]);
            }
            
            const users = loadUsersDB();
            const levels = loadLevelDB();
            const economy = loadEconomy();
            
            // Determinar usuario objetivo
            let targetJid = senderJid;
            let targetNumber = senderNumber;
            let targetName = pushName;
            
            const mencionado = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
            
            if (mencionado) {
                targetJid = cleanJid(mencionado);
                targetNumber = extractNumber(targetJid);
                if (users[targetNumber]) {
                    targetName = users[targetNumber]?.pushName || users[targetNumber]?.name || targetNumber;
                } else {
                    targetName = targetNumber;
                }
            } else if (quotedParticipant) {
                targetJid = cleanJid(quotedParticipant);
                targetNumber = extractNumber(targetJid);
                if (users[targetNumber]) {
                    targetName = users[targetNumber]?.pushName || users[targetNumber]?.name || targetNumber;
                } else {
                    targetName = targetNumber;
                }
            }
            
            // Obtener datos del usuario
            const userData = users[targetNumber] || {};
            const levelData = levels[targetNumber] || { exp: 0, level: 1 };
            const ecoData = economy[targetNumber] || { coins: 0, pets: [] };
            
            const description = userData.description || 'Sin descripción';
            const gender = userData.gender || 'No especificado';
            const age = userData.age || 'No especificado';
            const birthday = userData.birthday || 'No especificado';
            const exp = levelData.exp || 0;
            const level = levelData.level || 1;
            const petsCount = ecoData.pets?.length || 0;
            const coins = ecoData.coins || 0;
            const diamonds = ecoData.minerals?.diamantes || 0;
            
            // Obtener foto de perfil
            const profilePic = await getProfilePicture(sock, targetJid);
            
            const infoText = `▬ׅ   ׄ▭ׅ   ׄ▬ׅ   ׄ▭  ׅ ▬ׅ   ׄ▭   ׄ▬ׅ   ׄ▭\n       ത     ׁ      🦈      ׅ       ׁ     ♡    \n★   㺦  *Perfil de*  ⏤͟   ${targetName}\n╭──╮ - ̗̀ °︹︹︹⊹︹︹︹°\n┊🌟┊  ꞌꞋ   ⃝🍌  Descripción 𝇌.\n╰──╯ ⌑  ;: ${description}\n\n*🐋 ᪲⧽⧽ 𝗇ᦅ𝗆bꭇᧉ › ${targetName}*\n*🐋 ᪲⧽⧽ gé𝗇ᧉꭇᦅ › ${gender}*\n*🐋 ᪲⧽⧽ ᧉdαd › ${age} años*\n*🐋 ᪲⧽⧽ bꪱꭇƚһdαᥡ › ${birthday}*\n\n*🐋 ᪲⧽⧽ ᧉx𝗉 › ${exp}*\n*🐋 ᪲⧽⧽ 𝗇ꪱ᥎ᧉ𝗅 › ${level}*\n\n*🐋 ᪲⧽⧽ 𝗉ᧉƚ𝗌 › ${petsCount}*\n*🐋 ᪲⧽⧽ cᦅꪱ𝗇𝗌 › ${coins}*\n*🐋 ᪲⧽⧽ dꪱα𝗆α𝗇ƚᧉ𝗌 › ${diamonds}*`;
            
            if (profilePic) {
                await sock.sendMessage(from, {
                    image: profilePic,
                    caption: infoText,
                    mentions: [targetJid],
                    contextInfo: {
                        mentionedJid: [targetJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await replyWithContext(infoText, [targetJid]);
            }
            
        } catch (error) {
            console.error('❌ Error en profile:', error);
            await replyWithContext(`❌ Error: ${error.message}`, []);
        }
    }
};