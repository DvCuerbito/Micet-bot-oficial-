export default {
    name: 'delwarn',
    alias: ['eliminarwarn', 'quitarwarn'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // Verificar que sea un grupo
            if (!from.includes('@g.us')) {
                return;
            }

            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🌠 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }

            // Obtener info del grupo
            let groupMetadata;
            try {
                groupMetadata = await sock.groupMetadata(from);
            } catch (error) {
                return;
            }
            
            // Verificar si el usuario es admin del grupo
            const isGroupAdmin = groupMetadata.participants.find(p => {
                if (p.id === senderJid) return true;
                if (p.id.includes(senderNumber || '')) return true;
                if (senderJid && senderJid.includes('@lid')) {
                    const senderNum = senderJid.split('@')[0];
                    if (p.id.includes(senderNum)) return true;
                }
                return false;
            })?.admin;
            
            // Verificar si es owner del bot
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            // Verificar si tiene rango en el bot
            const userData = usersDB[senderNumber];
            const userRank = userData?.rank;
            const hasBotRank = isOwner || (userRank && ['owner', 'c-owner', 'srmod', 'mod'].includes(userRank));
            
            // Verificar permisos
            if (!isGroupAdmin && !hasBotRank) {
                await sock.sendMessage(from, { 
                    text: `🌠 Solo administradores del grupo pueden usar este comando`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }

            // Verificar si se proporcionó número de warn
            if (args.length === 0 || isNaN(args[0])) {
                await sock.sendMessage(from, { 
                    text: `🌠 Debes proporcionar el número del warn\n> Ej » ${config.prefix}delwarn 1 @usuario`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }

            const warnId = parseInt(args[0]);
            
            // 🔥 FUNCIÓN PARA OBTENER EL NÚMERO REAL 🔥
            const getRealPhoneNumber = (jid) => {
                if (!jid) return null;
                const identificador = jid.split('@')[0];
                
                for (const [num, data] of Object.entries(usersDB)) {
                    if (data.lid === jid || data.lid === identificador) return num;
                    if (data.jid === jid || data.jid === identificador) return num;
                }
                
                if (/^[\d]+$/.test(identificador) && identificador.length > 8) return identificador;
                return null;
            };
            
            let targetUserJid = null;
            let targetUserNumber = null;

            // 1. Verificar mención
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
                targetUserNumber = getRealPhoneNumber(targetUserJid);
            }
            // 2. Verificar respuesta
            else if (msg.message?.extendedTextMessage?.contextInfo?.participant) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.participant;
                targetUserNumber = getRealPhoneNumber(targetUserJid);
            }
            // 3. Verificar si hay número en args
            else if (args.length > 1) {
                const possibleNumber = args[1].replace(/[^0-9]/g, '');
                if (possibleNumber && possibleNumber.length > 8) {
                    targetUserNumber = possibleNumber;
                    const found = groupMetadata.participants.find(p => 
                        p.id.includes(possibleNumber) || 
                        p.id.split('@')[0] === possibleNumber
                    );
                    if (found) targetUserJid = found.id;
                }
            }

            if (!targetUserJid || !targetUserNumber) {
                await sock.sendMessage(from, { 
                    text: `🍥 Debes proporcionar a un usuario\n> Responde a un mensaje o menciona con @\n> Ejemplo: ${config.prefix}delwarn 1 @usuario`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }

            // Obtener warns y eliminar
            const { getWarns, removeWarn } = await import('../handler.js');
            const userWarns = getWarns(targetUserNumber, from);
            const warnToDelete = userWarns.find(w => w.id === warnId);
            
            if (!warnToDelete) {
                await sock.sendMessage(from, { 
                    text: `🦋 No se encontró el warn #${warnId} para este usuario.`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }

            const success = removeWarn(targetUserNumber, from, warnId);
            
            if (success) {
                await sock.sendMessage(from, { 
                    text: `🦋 Warn eliminado\n\n🧸 Warn #${warnId} eliminado de @${targetUserNumber}`,
                    mentions: [targetUserJid],
                    contextInfo: {
                        mentionedJid: [targetUserJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });

                console.log(`✅ Warn #${warnId} eliminado de ${targetUserNumber} por ${senderNumber}`);
            } else {
                throw new Error('No se pudo eliminar el warn');
            }

        } catch (error) {
            console.error('❌ Error en delwarn:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { 
                    text: `🦋 Error al eliminar warn: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};