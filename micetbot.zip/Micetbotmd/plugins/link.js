import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'link',
    alias: ['enlace', 'grouplink', 'invite'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            console.log(`\n🔗 ===== LINK COMANDO =====`);
            console.log(`🔗 Usuario: ${pushName || senderNumber}`);
            
            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, {
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Solo para grupos
            if (!from.includes('@g.us')) {
                await sock.sendMessage(from, {
                    text: `🌠 Este comando solo funciona en grupos.`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);
            
            // Obtener metadata del grupo
            const groupMetadata = await sock.groupMetadata(from);
            const groupName = groupMetadata.subject || "Grupo";
            const groupDesc = groupMetadata.desc || "Sin descripción";
            
            // Verificar si el usuario es admin del grupo
            const isGroupAdmin = groupMetadata.participants.find(p => {
                if (p.id === senderJid) return true;
                if (p.id.includes(senderNumber || '')) return true;
                if (senderJid && senderJid.includes('@lid')) {
                    const senderNum = senderJid.split('@')[0];
                    if (p.id.includes(senderNum)) return true;
                }
                return false;
            })?.admin;
            
            // Verificar si es owner del bot
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            // Intentar obtener el enlace del grupo
            console.log('🔄 Obteniendo enlace del grupo...');
            
            let inviteCode;
            try {
                inviteCode = await sock.groupInviteCode(from);
                console.log(`✅ Código obtenido: ${inviteCode}`);
                
            } catch (error) {
                console.log(`❌ Error: ${error.message}`);
                
                // Si falla, el bot no es admin
                await sock.sendMessage(from, {
                    text: `> 🌠 ${config.name} debe ser administrador del grupo.`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Construir enlace completo
            const fullLink = `https://chat.whatsapp.com/${inviteCode}`;
            console.log(`🔗 Enlace: ${fullLink}`);
            
            // Obtener imagen del grupo
            let groupImageBuffer = null;
            
            try {
                console.log('🖼️ Obteniendo imagen del grupo...');
                
                const groupImageUrl = await sock.profilePictureUrl(from, 'image');
                
                if (groupImageUrl) {
                    const response = await axios({
                        method: 'GET',
                        url: groupImageUrl,
                        responseType: 'arraybuffer',
                        timeout: 10000
                    });
                    
                    groupImageBuffer = Buffer.from(response.data);
                    console.log(`✅ Imagen obtenida: ${groupImageBuffer.length} bytes`);
                }
            } catch (error) {
                console.log('⚠️ No se pudo obtener la imagen del grupo:', error.message);
                
                const defaultImagePath = path.join(__dirname, '..', 'img', 'banner.jpg');
                if (fs.existsSync(defaultImagePath)) {
                    groupImageBuffer = fs.readFileSync(defaultImagePath);
                    console.log(`✅ Usando imagen por defecto: ${groupImageBuffer.length} bytes`);
                }
            }
            
            // Preparar contexto del mensaje
            const contextInfo = {
                mentionedJid: [senderJid],
                forwardingScore: 9999999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.canalId || '',
                    serverMessageId: 0,
                    newsletterName: config.canalNombre || ''
                }
            };
            
            // Si tenemos imagen, enviar con imagen
            if (groupImageBuffer) {
                const caption = `✧ *𝐋𝐈𝐍𝐊 𝐃𝐄𝐋 𝐆𝐑𝐔𝐏𝐎* ✧\n\n` +
                              `✦ *Grupo:* ${groupName}\n` +
                              `✦ *Enlace:* ${fullLink}\n` +
                              `✦ *Miembros:* ${groupMetadata.participants.length}\n` +
                              `✦ *Descripción:* ${groupDesc.substring(0, 50)}${groupDesc.length > 50 ? '...' : ''}\n` +
                              `> Solicitado por: ${pushName || senderNumber}`;
                
                await sock.sendMessage(from, {
                    image: groupImageBuffer,
                    caption: caption,
                    contextInfo: contextInfo
                }, { quoted: msg });
                
                console.log(`✅ Enlace con imagen enviado exitosamente`);
            } else {
                const textMessage = `> ✧ 𝙇𝙞𝙣𝙠 𝙙𝙚 *${groupName}* \n` +
                                   `> ✿ 𝙇𝙞𝙣𝙠 » *${fullLink}* \n` +
                                   `> ✦ 𝙈𝙞𝙚𝙢𝙗𝙧𝙤𝙨 » *${groupMetadata.participants.length}*\n\n` +
                                   `> Solicitado por: ${pushName || senderNumber}`;
                
                await sock.sendMessage(from, {
                    text: textMessage,
                    contextInfo: contextInfo
                }, { quoted: msg });
                
                console.log(`✅ Enlace sin imagen enviado exitosamente`);
            }
            
        } catch (error) {
            console.error('❌ Error general en link:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `🐞 Error al obtener el enlace.\n> ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
};