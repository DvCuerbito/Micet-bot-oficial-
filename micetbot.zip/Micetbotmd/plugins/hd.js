import crypto from 'crypto';
import { promises as fsp } from 'fs';
import os from 'os';
import path from 'path';
import { spawn } from 'child_process';
import { fileTypeFromBuffer } from 'file-type';

const fetchFn = fetch;

function extFromMime(mime) {
    if (/png/i.test(mime)) return 'png';
    if (/webp/i.test(mime)) return 'webp';
    return 'jpg';
}

function runFfmpeg(args, timeoutMs = 60000) {
    return new Promise((resolve, reject) => {
        const p = spawn('ffmpeg', args, { stdio: ['ignore', 'ignore', 'pipe'] });
        let err = '';
        const t = setTimeout(() => {
            try {
                p.kill('SIGKILL');
            } catch {}
            reject(new Error('ffmpeg timeout'));
        }, timeoutMs);

        p.stderr.on('data', (d) => (err += d.toString()));
        p.on('error', (e) => {
            clearTimeout(t);
            reject(e);
        });
        p.on('close', (code) => {
            clearTimeout(t);
            if (code === 0) return resolve(true);
            reject(new Error(err || `ffmpeg failed (${code})`));
        });
    });
}

async function webpToPngWithFfmpeg(webpBuf, tmpDir) {
    const inPath = path.join(tmpDir, `vi_${Date.now()}_${Math.random().toString(16).slice(2)}.webp`);
    const outPath = path.join(tmpDir, `vi_${Date.now()}_${Math.random().toString(16).slice(2)}.png`);

    await fsp.writeFile(inPath, webpBuf);

    try {
        await runFfmpeg(['-y', '-i', inPath, '-frames:v', '1', outPath], 60000);
        const png = await fsp.readFile(outPath);
        return { ok: true, png };
    } catch (e) {
        return { ok: false, error: e?.message || String(e) };
    } finally {
        try { await fsp.unlink(inPath); } catch {}
        try { await fsp.unlink(outPath); } catch {}
    }
}

async function vectorinkEnhanceFromBuffer(inputBuf, inputMime) {
    const API = 'https://us-central1-vector-ink.cloudfunctions.net/upscaleImage';
    const ORIGIN = 'https://vectorink.io';
    const TIMEOUT_MS = 120000;
    const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (Chrome)';

    const out = {
        ok: false,
        provider: 'vectorink.io',
        meta: { request_id: crypto.randomUUID?.() || crypto.randomBytes(16).toString('hex') }
    };

    const tmpDir = path.join(os.tmpdir(), 'vectorink');
    const tmpPath = path.join(tmpDir, `img_${Date.now()}_${Math.random().toString(16).slice(2)}.${extFromMime(inputMime)}`);

    try {
        await fsp.mkdir(tmpDir, { recursive: true });
        await fsp.writeFile(tmpPath, inputBuf);

        const b64 = (await fsp.readFile(tmpPath)).toString('base64');

        const r = await fetchFn(API, {
            method: 'POST',
            headers: {
                'content-type': 'application/json',
                accept: '*/*',
                origin: ORIGIN,
                referer: `${ORIGIN}/`,
                'user-agent': UA
            },
            body: JSON.stringify({ data: { image: b64 } }),
            signal: AbortSignal.timeout ? AbortSignal.timeout(TIMEOUT_MS) : undefined
        });

        const j = await r.json().catch(() => ({}));
        
        if (!r.ok) {
            out.error = { step: 'request', status: r.status, body: j };
            return out;
        }

        const innerText = j?.result;
        if (typeof innerText !== 'string' || innerText.length < 10) {
            out.error = { step: 'parse', code: 'no_result', body: j };
            return out;
        }

        let inner;
        try {
            inner = JSON.parse(innerText);
        } catch {
            out.error = { step: 'parse', code: 'bad_result_json', body: j };
            return out;
        }

        const webpB64 = inner?.image?.b64_json;
        if (!webpB64) {
            out.error = { step: 'parse', code: 'no_b64', body: inner };
            return out;
        }

        const webpBuf = Buffer.from(webpB64, 'base64');

        const conv = await webpToPngWithFfmpeg(webpBuf, tmpDir);
        if (!conv.ok) {
            out.error = { step: 'convert', code: 'ffmpeg_failed', message: conv.error };
            return out;
        }

        out.ok = true;
        out.buffer = conv.png;
        out.contentType = 'image/png';
        out.result = { image_id: inner?.image?.image_id, created: inner?.created, credits: inner?.credits };
        return out;
    } catch (e) {
        out.error = { step: 'exception', message: e?.message || String(e) };
        return out;
    } finally {
        try { await fsp.unlink(tmpPath); } catch {}
    }
}

async function safeFileType(buf) {
    try {
        return await fileTypeFromBuffer(buf);
    } catch {
        return null;
    }
}

export default {
    name: 'hd',
    alias: ['enhance', 'remini', 'mejorar'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            // Obtener el mensaje citado
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            const quotedMessage = quotedMsg?.quotedMessage;
            
            if (!quotedMessage) {
                await replyWithContext(
                    `⭐ Responde a una *imagen* para mejorar su calidad\n> Ejemplo: Responde a una imagen con ${config.prefix}hd`,
                    []
                );
                return;
            }
            
            // Obtener la imagen del mensaje citado
            let imageBuffer = null;
            let imageMime = '';
            
            if (quotedMessage.imageMessage) {
                const imageMsg = quotedMessage.imageMessage;
                imageMime = imageMsg.mimetype || 'image/jpeg';
                
                const quotedMsgObj = {
                    key: {
                        remoteJid: from,
                        id: quotedMsg.stanzaId,
                        participant: quotedMsg.participant || from,
                        fromMe: false
                    },
                    message: {
                        imageMessage: imageMsg
                    }
                };
                
                const { downloadMediaMessage } = await import('@whiskeysockets/baileys');
                imageBuffer = await downloadMediaMessage(
                    quotedMsgObj,
                    'buffer',
                    {},
                    {
                        logger: console,
                        reuploadRequest: sock.updateMediaMessage
                    }
                );
            } else if (quotedMessage.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage) {
                const deepQuoted = quotedMessage.extendedTextMessage.contextInfo.quotedMessage.imageMessage;
                imageMime = deepQuoted.mimetype || 'image/jpeg';
                
                const quotedMsgObj = {
                    key: {
                        remoteJid: from,
                        id: quotedMsg.stanzaId,
                        participant: quotedMsg.participant || from,
                        fromMe: false
                    },
                    message: {
                        imageMessage: deepQuoted
                    }
                };
                
                const { downloadMediaMessage } = await import('@whiskeysockets/baileys');
                imageBuffer = await downloadMediaMessage(
                    quotedMsgObj,
                    'buffer',
                    {},
                    {
                        logger: console,
                        reuploadRequest: sock.updateMediaMessage
                    }
                );
            } else {
                await replyWithContext(
                    `⭐ Responde a una *imagen* para mejorar su calidad`,
                    []
                );
                return;
            }
            
            if (!imageBuffer || imageBuffer.length < 10) {
                await replyWithContext(
                    `⭐ No se pudo descargar la imagen`,
                    []
                );
                return;
            }
            
            const ft = await safeFileType(imageBuffer);
            const inputMime = ft?.mime || imageMime || 'image/jpeg';
            
            if (!/^image\/(jpe?g|png|webp)$/i.test(inputMime)) {
                await replyWithContext(
                    `⭐ El formato *${inputMime}* no es compatible\n> Formatos soportados: JPG, PNG, WEBP`,
                    []
                );
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔄', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(
                `🖼️ *Mejorando imagen...*\n> Esto puede tomar unos segundos`,
                []
            );
            
            const result = await vectorinkEnhanceFromBuffer(imageBuffer, inputMime);
            
            if (!result?.ok || !result?.buffer) {
                const errorMsg = result?.error?.code || result?.error?.step || result?.error?.message || 'Error desconocido';
                await replyWithContext(
                    `⭐ No se pudo mejorar la imagen (${errorMsg})`,
                    []
                );
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            await sock.sendMessage(from, {
                image: result.buffer,
                caption: `🖼️ *Imagen mejorada*\n> Por: ${pushName || 'Usuario'}`,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            console.log(`✅ Imagen mejorada por ${pushName || 'Usuario'}`);
            
        } catch (error) {
            console.error('❌ Error en hd:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(
                `❌ Error: ${error.message}`,
                []
            );
        }
    }
};