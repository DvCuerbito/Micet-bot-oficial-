
export default {
    name: 'ship',
    alias: ['love', 'calcularamor'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // Verificar registro (usando senderNumber)
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🌸 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            // Verificar que sea un grupo
            if (!from.includes('@g.us')) {
                await sock.sendMessage(from, {
                    text: `🌸 Este comando solo funciona en grupos.`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Obtener el usuario mencionado
            let targetUserJid = null;
            let targetUserNumber = null;
            
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
                targetUserNumber = targetUserJid.split('@')[0];
            }

            if (!targetUserJid) {
                await sock.sendMessage(from, {
                    text: `🌸 Debes mencionar a un usuario con @ para calcular el amor.\n\nEjemplo: ${config.prefix}ship @usuario`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Obtener nombres
            const user1Name = pushName || senderNumber;
            const user2Name = usersDB[targetUserNumber]?.pushName || 
                             usersDB[targetUserNumber]?.name || 
                             targetUserNumber;

            // Calcular porcentaje de amor (aleatorio)
            const lovePercentage = Math.floor(Math.random() * 101);

            // Determinar mensaje según el porcentaje
            let mensajeAmor = "";
            if (lovePercentage <= 10) {
                mensajeAmor = "💔 Mejor ni lo intenten...";
            } else if (lovePercentage <= 20) {
                mensajeAmor = "💔 Son como agua y aceite";
            } else if (lovePercentage <= 30) {
                mensajeAmor = "💔 Muy difícil que funcione";
            } else if (lovePercentage <= 40) {
                mensajeAmor = "💗 Hay una pequeña posibilidad";
            } else if (lovePercentage <= 50) {
                mensajeAmor = "💗 Podrían intentarlo";
            } else if (lovePercentage <= 60) {
                mensajeAmor = "💖 Tienen potencial";
            } else if (lovePercentage <= 70) {
                mensajeAmor = "💖 Se llevan bastante bien";
            } else if (lovePercentage <= 80) {
                mensajeAmor = "💕 Son una linda pareja";
            } else if (lovePercentage <= 90) {
                mensajeAmor = "💕 Casi el amor perfecto";
            } else {
                mensajeAmor = "💞 ¡Almas gemelas! 💞";
            }

            // Construir mensaje
            const loveMessage = `💖 *${user1Name}* tu oportunidad de enamorarte de *${user2Name}* es de *${lovePercentage}%* 💖\n\n> ${mensajeAmor}`;

            // Enviar resultado
            await sock.sendMessage(from, {
                text: loveMessage,
                mentions: [senderJid, targetUserJid],
                contextInfo: {
                    mentionedJid: [senderJid, targetUserJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            console.log(`💖 Ship calculado por ${pushName || senderNumber}: ${user1Name} y ${user2Name} = ${lovePercentage}%`);

        } catch (error) {
            console.error('❌ Error en comando ship:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `🌸 Error al calcular el amor: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};