import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function formatSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function getFolderSize(folderPath) {
    let totalSize = 0;
    try {
        if (fs.existsSync(folderPath)) {
            const files = fs.readdirSync(folderPath);
            for (const file of files) {
                const filePath = path.join(folderPath, file);
                const stats = fs.statSync(filePath);
                if (stats.isFile()) {
                    totalSize += stats.size;
                } else if (stats.isDirectory()) {
                    totalSize += getFolderSize(filePath);
                }
            }
        }
    } catch (error) {}
    return totalSize;
}

export default {
    name: 'disk',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, replyWithContext } = options;
            
            const OWNER_ID = '5219992042946';
            const cleanNumber = senderNumber ? senderNumber.replace(/[^0-9]/g, '') : '';
            
            if (cleanNumber !== OWNER_ID) {
                await replyWithContext(`๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}disk\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.`, []);
                return;
            }
            
            // Calcular tamaños
            const tempSize = getFolderSize(path.join(process.cwd(), 'temp'));
            const sessionsSize = getFolderSize(path.join(process.cwd(), 'Sessions'));
            const databasesSize = getFolderSize(path.join(process.cwd(), 'databases'));
            const pluginsSize = getFolderSize(path.join(process.cwd(), 'plugins'));
            const totalSize = tempSize + sessionsSize + databasesSize + pluginsSize;
            
            // Obtener espacio en disco
            let diskInfo = '';
            try {
                const { stdout } = await execAsync('df -h /');
                diskInfo = stdout;
            } catch (e) {}
            
            const message = `💾 *ALMACENAMIENTO*\n\n` +
                `📁 *Temp*: ${formatSize(tempSize)}\n` +
                `📁 *Sessions*: ${formatSize(sessionsSize)}\n` +
                `📁 *Databases*: ${formatSize(databasesSize)}\n` +
                `📁 *Plugins*: ${formatSize(pluginsSize)}\n` +
                `━━━━━━━━━━━━━━━━\n` +
                `💿 *Total usado*: ${formatSize(totalSize)}\n\n` +
                `🖥️ *Espacio en disco*:\n` +
                `\`\`\`${diskInfo}\`\`\``;
            
            await replyWithContext(message, []);
            
        } catch (error) {
            console.error('Error en disk:', error);
            await replyWithContext(`❌ Error: ${error.message}`, []);
        }
    }
};