import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Lista de rangos permitidos (mods y owners)
const ALLOWED_RANKS = ['owner', 'c-owner', 'srmod', 'mod', 'trialmod', 'trial', 'helper', 'applicant'];

// Función para limpiar JID (eliminar :0, :1, etc.)
function cleanJid(jid) {
    if (!jid) return jid;
    // Eliminar :0, :1, :2, etc. antes del @
    return jid.replace(/(:\d+)@/, '@');
}

// Función para cargar nivelDB
function loadLevelDB() {
    try {
        const levelFile = path.join(__dirname, '..', 'databases', 'level.json');
        if (fs.existsSync(levelFile)) {
            const data = fs.readFileSync(levelFile, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando level.json:', error);
    }
    return {};
}

// Función para obtener número de un LID
function getNumberFromLid(usersDB, lidOrJid) {
    if (!lidOrJid) return null;
    
    // Limpiar el identificador primero
    const cleanIdentifier = cleanJid(lidOrJid);
    
    // Extraer número del LID/JID limpio
    const searchNumber = cleanIdentifier.split('@')[0].replace(/\D/g, '');
    
    // Buscar por número directamente
    if (usersDB[searchNumber]) {
        return searchNumber;
    }
    
    // Buscar por LID en la base de datos
    for (const [number, userData] of Object.entries(usersDB)) {
        if (userData.lid === cleanIdentifier || userData.jid === cleanIdentifier) {
            return number;
        }
    }
    
    return searchNumber;
}

// Función para obtener JID para mención desde número
function getUserJidForMention(usersDB, userNumber) {
    if (!userNumber || !usersDB || !usersDB[userNumber]) return `${userNumber}@s.whatsapp.net`;
    return usersDB[userNumber].jid || usersDB[userNumber].lid || `${userNumber}@s.whatsapp.net`;
}

// Función para formatear fecha
function formatDate(dateString) {
    if (!dateString) return 'Desconocido';
    try {
        const date = new Date(dateString);
        return date.toLocaleString('es-ES', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    } catch (error) {
        return dateString;
    }
}

export default {
    name: 'userinfo',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // Verificar si el usuario tiene permisos (mod o owner)
            const userData = usersDB[senderNumber];
            const userRank = userData?.rank;
            const isAllowed = userRank && ALLOWED_RANKS.includes(userRank);
            
            // Verificar si es owner según config.js
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isOwner && !isAllowed) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}userinfo\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);
            
            // Variables para el usuario objetivo
            let targetIdentifier = null;
            let targetUserJid = null;
            let targetUserNumber = null;
            
            // Verificar si hay mención con @
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetIdentifier = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
                targetIdentifier = cleanJid(targetIdentifier); // Limpiar JID
                console.log(`📌 Input por mención (limpio): ${targetIdentifier}`);
            }
            // Verificar si es respuesta a un mensaje
            else if (msg.message?.extendedTextMessage?.contextInfo?.participant) {
                targetIdentifier = msg.message.extendedTextMessage.contextInfo.participant;
                targetIdentifier = cleanJid(targetIdentifier); // Limpiar JID
                console.log(`📌 Input por respuesta (limpio): ${targetIdentifier}`);
            }
            // Verificar si se proporcionó un número o LID como argumento
            else if (args && args.length > 0) {
                targetIdentifier = args[0].trim();
                targetIdentifier = cleanJid(targetIdentifier); // Limpiar JID
                console.log(`📌 Input por argumento (limpio): ${targetIdentifier}`);
            }
            
            // Si no se encontró usuario, usar al que ejecuta el comando
            if (!targetIdentifier) {
                targetIdentifier = cleanJid(senderJid);
                console.log(`📌 Usando usuario propio: ${targetIdentifier}`);
            }
            
            // OBTENER EL NÚMERO DEL USUARIO
            targetUserNumber = getNumberFromLid(usersDB, targetIdentifier);
            
            // Obtener el JID para la mención
            if (targetUserNumber) {
                targetUserJid = getUserJidForMention(usersDB, targetUserNumber);
            } else {
                // Si no se pudo obtener número, usar el identificador original como JID
                targetUserJid = targetIdentifier;
                targetUserNumber = targetIdentifier.split('@')[0].replace(/\D/g, '');
            }
            
            console.log(`🎯 Target final - Número: ${targetUserNumber}, JID: ${targetUserJid}`);
            
            // Verificar que tenemos un número válido
            if (!targetUserNumber) {
                await sock.sendMessage(from, {
                    text: `❌ No se pudo determinar el usuario objetivo.`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Obtener información del usuario de usersDB
            const userInfo = usersDB[targetUserNumber] || {};
            
            // Obtener información de nivel
            const levelDB = loadLevelDB();
            const levelInfo = levelDB[targetUserNumber] || { exp: 0, commands: 0, level: 1 };
            
            // Calcular nivel actual si no existe
            let userLevel = levelInfo.level || 1;
            let userExp = levelInfo.exp || 0;
            let userCommands = levelInfo.commands || 0;
            
            // Determinar si es sub-bot
            let isSubBot = 'No';
            if (global.conns && Array.isArray(global.conns)) {
                isSubBot = global.conns.some(conn => {
                    if (conn.userId) {
                        return conn.userId.includes(targetUserNumber);
                    }
                    return false;
                }) ? 'Sí' : 'No';
            }
            
            // Determinar si es owner por config.js
            const isTargetOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (targetUserNumber || '').replace(/\D/g, '')
            );
            
            // Determinar si es mod y su rango
            let userRank2 = userInfo.rank || 'usuario';
            
            // Si es owner por config, mostrar "owner" como rango
            if (isTargetOwner) {
                userRank2 = 'owner';
            }
            
            const isMod = userRank2 && ALLOWED_RANKS.includes(userRank2) ? 'Sí' : 'No';
            
            // Verificar si está baneado
            const isBanned = userInfo.banned?.isBanned ? 'Sí' : 'No';
            
            // Obtener último comando
            const lastCommand = levelInfo.lastCommand 
                ? `${levelInfo.lastCommand.name} (${formatDate(levelInfo.lastCommand.timestamp)})`
                : 'Ninguno';
            
            // Obtener fecha de registro
            const registeredDate = userInfo.registered ? formatDate(userInfo.registered) : 'Desconocido';
            
            // Obtener pushName
            const targetPushName = userInfo.pushName || targetUserNumber;
            
            // Obtener LID (limpio)
            const targetLid = userInfo.lid ? cleanJid(userInfo.lid) : cleanJid(targetUserJid);
            
            // Construir mensaje con el formato solicitado
            const infoMessage = `★ 》Nombre » ${targetPushName}
★ 》Nivel » ${userLevel}
★ 》Exp » ${userExp}
★ 》Cmds » ${userCommands}
★ 》Sub-Bot » ${isSubBot}
𝃡▬̸̷⵿▬݊݁݀۫ࣳ▬▭▭ַ▬▬۟݀݁▬▭֧ۣ▬̸̷⵿▬݊݁݀۫ࣳ▬▭▭ַ▬▬۟݀݁
★ 》Tiempo » ${registeredDate}
★ 》Número » ${targetUserNumber}
★ 》Lid » ${targetLid}
★ 》Último comando » ${lastCommand}
★ 》Mod » ${isMod}
★ 》Rango » ${userRank2}
★ 》Baneado » ${isBanned}`;
            
            // Intentar obtener la foto de perfil del usuario
            let profilePictureBuffer = null;
            try {
                const profilePicUrl = await sock.profilePictureUrl(targetUserJid, 'image').catch(() => null);
                if (profilePicUrl) {
                    const response = await axios.get(profilePicUrl, {
                        responseType: 'arraybuffer',
                        timeout: 10000
                    });
                    profilePictureBuffer = Buffer.from(response.data);
                    console.log(`✅ Foto de perfil obtenida para ${targetUserNumber}`);
                }
            } catch (error) {
                console.log(`⚠️ No se pudo obtener foto de perfil: ${error.message}`);
                
                // Intentar con imagen por defecto
                const defaultImagePath = path.join(__dirname, '..', 'img', 'icon.jpg');
                if (fs.existsSync(defaultImagePath)) {
                    profilePictureBuffer = fs.readFileSync(defaultImagePath);
                    console.log(`✅ Usando imagen por defecto`);
                }
            }
            
            // Preparar contexto del mensaje
            const contextInfo = {
                mentionedJid: [senderJid],
                forwardingScore: 9999999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.canalId || '',
                    serverMessageId: 0,
                    newsletterName: config.canalNombre || ''
                }
            };
            
            // Enviar mensaje con imagen si tenemos foto
            if (profilePictureBuffer) {
                await sock.sendMessage(from, {
                    image: profilePictureBuffer,
                    caption: infoMessage,
                    contextInfo: contextInfo
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, {
                    text: infoMessage,
                    contextInfo: contextInfo
                }, { quoted: msg });
            }
            
            console.log(`✅ Userinfo consultado por ${pushName || senderNumber} para usuario ${targetUserNumber}`);
            
        } catch (error) {
            console.error('❌ Error en comando userinfo:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ Error al obtener información del usuario: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
};