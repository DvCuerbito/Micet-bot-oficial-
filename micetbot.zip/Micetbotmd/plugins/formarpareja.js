function toM(a) {
    return '@' + a.split('@')[0];
}

export default {
    name: 'formarpareja',
    alias: ['formarparejas', 'shippear'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🌸 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            // Verificar que sea un grupo
            if (!from.includes('@g.us')) {
                await sock.sendMessage(from, {
                    text: `🌸 Este comando solo funciona en grupos.`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            try {
                // Obtener metadata del grupo
                const groupMetadata = await sock.groupMetadata(from);
                const participants = groupMetadata.participants.map(v => v.id);
                
                // Verificar que haya al menos 2 participantes
                if (participants.length < 2) {
                    await sock.sendMessage(from, {
                        text: `🌸 Se necesitan al menos 2 participantes en el grupo para formar una pareja.`,
                        contextInfo: {
                            mentionedJid: [senderJid],
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            },
                            forwardingScore: 9999999,
                            isForwarded: true
                        }
                    }, { quoted: msg });
                    return;
                }

                // Seleccionar primer participante aleatorio
                const a = participants[Math.floor(Math.random() * participants.length)];
                
                // Seleccionar segundo participante aleatorio (diferente del primero)
                let b;
                do {
                    b = participants[Math.floor(Math.random() * participants.length)];
                } while (b === a);

                // Obtener nombres de los participantes (opcional, para logs)
                const aNumber = a.split('@')[0];
                const bNumber = b.split('@')[0];
                const nameA = usersDB[aNumber]?.pushName || usersDB[aNumber]?.name || aNumber;
                const nameB = usersDB[bNumber]?.pushName || usersDB[bNumber]?.name || bNumber;

                // Construir mensaje con el formato original pero letras normales
                const mensaje = `🌸 *${toM(a)}*, deberías casarte con 💍 *${toM(b)}*\n\n¡Felicitaciones! Hacen una hermosa pareja 🌷`;

                // Enviar mensaje
                await sock.sendMessage(from, {
                    text: mensaje,
                    mentions: [a, b],
                    contextInfo: {
                        mentionedJid: [a, b, senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });

                console.log(`🌸 Pareja formada por ${pushName || senderNumber}: ${nameA} 💍 ${nameB}`);

            } catch (error) {
                console.error('❌ Error obteniendo metadata del grupo:', error);
                
                await sock.sendMessage(from, {
                    text: `🌸 Error al obtener los participantes del grupo.`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            }

        } catch (error) {
            console.error('❌ Error en comando formarpareja:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `🌸 Error: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};
