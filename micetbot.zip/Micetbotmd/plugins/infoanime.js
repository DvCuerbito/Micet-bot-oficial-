import https from 'https';

export default {
    name: 'infoanime',
    alias: ['animeinfo'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: ` Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg TuNombre`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Verificar si se proporcionó texto
            if (!args || args.length === 0) {
                await sock.sendMessage(from, { 
                    text: `❀ Por favor, ingrese el nombre de algún anime.\nEjemplo: ${config.prefix}infoanime Naruto`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const searchText = args.join(' ');

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            // Función para hacer petición HTTPS
            const fetchAnimeData = (query) => {
                return new Promise((resolve, reject) => {
                    const encodedQuery = encodeURIComponent(query);
                    const options = {
                        hostname: 'api.jikan.moe',
                        port: 443,
                        path: `/v4/manga?q=${encodedQuery}&limit=1`,
                        method: 'GET',
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                            'Accept': 'application/json'
                        }
                    };
                    
                    const req = https.request(options, (res) => {
                        let data = '';
                        
                        res.on('data', (chunk) => {
                            data += chunk;
                        });
                        
                        res.on('end', () => {
                            if (res.statusCode >= 200 && res.statusCode < 300) {
                                try {
                                    const jsonData = JSON.parse(data);
                                    resolve(jsonData);
                                } catch (parseError) {
                                    reject(new Error(`Error al parsear JSON: ${parseError.message}`));
                                }
                            } else {
                                reject(new Error(`Error HTTP ${res.statusCode}: ${res.statusMessage}`));
                            }
                        });
                    });
                    
                    req.on('error', (error) => {
                        reject(new Error(`Error de conexión: ${error.message}`));
                    });
                    
                    req.setTimeout(15000, () => {
                        req.destroy();
                        reject(new Error('Tiempo de espera agotado (15 segundos)'));
                    });
                    
                    req.end();
                });
            };
            
            const json = await fetchAnimeData(searchText);
            
            if (!json.data || json.data.length === 0) {
                await sock.sendMessage(from, { 
                    text: `🍃 No se encontró ningún anime con el nombre: "${searchText}"`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Tomar el primer resultado
            const anime = json.data[0];
            
            // Extraer información con valores por defecto
            const chapters = anime.chapters ?? 'Desconocido';
            const titleJapanese = anime.title_japanese || anime.title || 'Sin título';
            const titleEnglish = anime.title_english || anime.title || 'Sin título';
            const url = anime.url || 'No disponible';
            const type = anime.type || 'Desconocido';
            const score = anime.score ? `✰ ${anime.score}/10` : 'No puntuado';
            const members = anime.members ? anime.members.toLocaleString() : 'Desconocido';
            const background = anime.background || null;
            const status = anime.status || 'Desconocido';
            const volumes = anime.volumes || 'Desconocido';
            const favorites = anime.favorites ? anime.favorites.toLocaleString() : 'Desconocido';
            
            // Obtener autor(es)
            let authors = 'Desconocido';
            if (anime.authors && anime.authors.length > 0) {
                authors = anime.authors.map(a => a.name).join(', ');
            }
            
            // Procesar sinopsis
            let synopsis = 'Sin sinopsis disponible';
            if (anime.synopsis) {
                synopsis = anime.synopsis.replace(/\n/g, ' ');
                if (synopsis.length > 400) {
                    synopsis = synopsis.substring(0, 400) + '...';
                }
            }
            
            // URL de la imagen
            const imageUrl = anime.images?.jpg?.image_url || anime.images?.jpg?.large_image_url;
            
            // Construir mensaje
            const animeInfo = `⏤͟͟͞͞𖤐 *INFORMACIÓN DEL ANIME* ⏤͟͟͞͞𖤐

❒ *Título Japonés*: ${titleJapanese}
❒ *Título Inglés*: ${titleEnglish}

❖ *Información*:
├─ ❒ *Tipo*: ${type}
├─ ❒ *Estado*: ${status}
├─ ❒ *Capítulos*: ${chapters}
├─ ❒ *Volúmenes*: ${volumes}
├─ ❒ *Puntuación*: ${score}
├─ ❒ *Miembros*: ${members}
├─ ❒ *Favoritos*: ${favorites}
└─ ❒ *Autor(es)*: ${authors}

❀ *Sinopsis*:
${synopsis}

${background ? `\n❖ *Contexto*:\n${background.substring(0, 200)}${background.length > 200 ? '...' : ''}` : ''}

♡ *Más información*: ${url}`;

            // Preparar contexto del mensaje
            const contextInfo = {
                mentionedJid: [senderJid],
                forwardingScore: 9999999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.canalId || '',
                    serverMessageId: 0,
                    newsletterName: config.canalNombre || ''
                }
            };

            // Enviar respuesta
            if (imageUrl) {
                // Intentar enviar con imagen
                try {
                    await sock.sendMessage(from, {
                        image: { url: imageUrl },
                        caption: animeInfo,
                        contextInfo: contextInfo
                    }, { quoted: msg });
                } catch (imageError) {
                    // Si falla la imagen, enviar solo texto
                    console.error('Error al cargar imagen:', imageError.message);
                    await sock.sendMessage(from, {
                        text: animeInfo,
                        contextInfo: contextInfo
                    }, { quoted: msg });
                }
            } else {
                // Enviar solo texto si no hay imagen
                await sock.sendMessage(from, {
                    text: animeInfo,
                    contextInfo: contextInfo
                }, { quoted: msg });
            }

            console.log(`✅ Infoanime buscado: "${searchText}" por ${pushName || senderNumber}`);

        } catch (error) {
            console.error('❌ Error en infoanime:', error);
            
            let errorMessage = `⚠ Se ha producido un problema al buscar el anime.`;
            
            if (error.message.includes('Tiempo de espera')) {
                errorMessage = `♡ La búsqueda tardó demasiado. Intenta nuevamente.`;
            } else if (error.message.includes('Error HTTP')) {
                errorMessage = `♡ Error al conectar con la API de anime.`;
            }
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { 
                    text: `${errorMessage}\n\nError: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
};
