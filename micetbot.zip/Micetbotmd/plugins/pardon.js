// Lista de rangos permitidos (owners y mods)
const ALLOWED_RANKS = ['owner', 'c-owner', 'srmod', 'mod'];

export default {
    name: 'pardon',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, args, pushName, saveUsersDB } = options;
            const from = msg.key.remoteJid;
            
            console.log(`🔓 Comando delban ejecutado por: ${senderNumber}`);

            // Verificar si el usuario tiene permisos (owner de config o mods)
            const userData = usersDB[senderNumber];
            const userRank = userData?.rank;
            const isAllowed = userRank && ALLOWED_RANKS.includes(userRank);
            
            // Verificar si es owner según config.js
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isOwner && !isAllowed) {
                return await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}pardon\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            let targetUserJid = null;
            let targetUserNumber = null;

            // 🔥 FUNCIÓN PARA OBTENER EL NÚMERO REAL (sea LID o JID) 🔥
            const getRealPhoneNumber = (jid) => {
                if (!jid) return null;
                
                // Extraer el identificador (lo que está antes del @)
                const identificador = jid.split('@')[0];
                
                // CASO 1: Buscar en usersDB por LID
                for (const [num, data] of Object.entries(usersDB)) {
                    if (data.lid === jid || data.lid === identificador) {
                        console.log(`✅ LID encontrado! Número real: ${num}`);
                        return num;
                    }
                }
                
                // CASO 2: Buscar en usersDB por JID
                for (const [num, data] of Object.entries(usersDB)) {
                    if (data.jid === jid || data.jid === identificador) {
                        console.log(`✅ JID encontrado! Número real: ${num}`);
                        return num;
                    }
                }
                
                // CASO 3: Si ya es un número de teléfono (solo dígitos)
                if (/^[\d]+$/.test(identificador) && identificador.length > 8) {
                    // Verificar si existe en usersDB
                    if (usersDB[identificador]) {
                        return identificador;
                    }
                    return identificador; // Asumir que es el número
                }
                
                // Si no se encuentra, devolver null
                return null;
            };

            // Verificar si hay mención
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
                
                // Obtener el número real
                targetUserNumber = getRealPhoneNumber(targetUserJid);
                
                if (!targetUserNumber) {
                    return await sock.sendMessage(from, {
                        text: `❌ No se pudo obtener el número del usuario mencionado.`,
                        contextInfo: {
                            mentionedJid: [],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
                
                console.log(`✅ Usuario mencionado: ${targetUserJid} -> Número: ${targetUserNumber}`);
            }
            // Verificar si es respuesta
            else if (msg.message?.extendedTextMessage?.contextInfo?.stanzaId) {
                const quotedMsg = msg.message.extendedTextMessage.contextInfo;
                if (quotedMsg.participant) {
                    targetUserJid = quotedMsg.participant;
                    
                    // Obtener el número real
                    targetUserNumber = getRealPhoneNumber(targetUserJid);
                    
                    if (!targetUserNumber) {
                        return await sock.sendMessage(from, {
                            text: `❌ No se pudo obtener el número del usuario citado.`,
                            contextInfo: {
                                mentionedJid: [],
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                    }
                    
                    console.log(`✅ Usuario por respuesta: ${targetUserJid} -> Número: ${targetUserNumber}`);
                }
            }

            // Si no se encontró usuario
            if (!targetUserJid || !targetUserNumber) {
                return await sock.sendMessage(from, {
                    text: `🌠 Debes mencionar o responder a un usuario para desbanear`,
                    contextInfo: {
                        mentionedJid: [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }

            // Obtener pushName del usuario a desbanear
            const targetName = usersDB[targetUserNumber]?.pushName || 
                               usersDB[targetUserNumber]?.name || 
                               targetUserNumber;

            // Obtener pushName del usuario que desbanea
            const unbannerName = pushName || senderNumber;

            // Verificar si el usuario está baneado
            if (!usersDB[targetUserNumber]?.banned?.isBanned) {
                return await sock.sendMessage(from, {
                    text: `🦋 *${targetName}* no está baneado`,
                    contextInfo: {
                        mentionedJid: [targetUserJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }

            // Fecha actual
            const fecha = new Date().toLocaleString('es-ES', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });

            // Guardar info del ban antes de eliminarlo
            const banInfo = { ...usersDB[targetUserNumber].banned };

            // Eliminar el ban
            delete usersDB[targetUserNumber].banned;

            // Guardar cambios en users.json usando la función del handler
            if (saveUsersDB) {
                saveUsersDB(usersDB);
            }

            // Mensaje de éxito
            const mensajeExito = `🦋 *${targetName}* fue desbaneado

🌠 Fecha del ban » *${banInfo.date || 'Desconocida'}*
🌠 Razón del ban » *${banInfo.reason || 'No especificada'}*
🌠 Desbaneado por » *${unbannerName}*
🌠 Fecha de desbaneo » *${fecha}*`;

            await sock.sendMessage(from, {
                text: mensajeExito,
                contextInfo: {
                    mentionedJid: [targetUserJid, senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            console.log(`✅ Usuario desbaneado: ${targetName} (${targetUserNumber}) por ${unbannerName}`);

        } catch (error) {
            console.error('❌ Error en delban:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `🌸 Error al ejecutar el comando: ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};
