import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 0,
            bank: 0
        };
    }
    if (economy[userNumber].bank === undefined) economy[userNumber].bank = 0;
    return economy[userNumber];
}

export default {
    name: 'withdraw',
    alias: ['with', 'retirar'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderNumber, pushName, replyWithContext, senderJid } = options;
            
            if (!senderNumber) {
                return await replyWithContext('❌ No se pudo identificar tu número', [senderJid]);
            }
            
            let economy = loadEconomy();
            const user = initUserEconomy(economy, senderNumber, pushName);
            
            const amount = args[0]?.toLowerCase();
            
            if (!amount) {
                return await replyWithContext(
                    `🍭 Debes proporcionar una cantidad\n` +
                    `> ${config.prefix}retirar +cantidad\n` +
                    `> ${config.prefix}retirar all`,
                    [senderJid]
                );
            }
            
            let withdrawAmount = 0;
            
            if (amount === 'all') {
                if (!user.bank || user.bank === 0) {
                    return await replyWithContext(`❌ No tienes coins en el banco para retirar`, [senderJid]);
                }
                withdrawAmount = user.bank;
            } else {
                withdrawAmount = parseInt(amount);
                if (isNaN(withdrawAmount) || withdrawAmount <= 0) {
                    return await replyWithContext(`❌ Cantidad inválida. Usa un número positivo o "all"`, [senderJid]);
                }
            }
            
            if (!user.bank || user.bank < withdrawAmount) {
                return await replyWithContext(
                    `❌ No tienes suficientes coins en el banco\n\n` +
                    `🏦 *En banco:* ${user.bank || 0} coins\n` +
                    `💰 *Necesitas:* ${withdrawAmount} coins`,
                    [senderJid]
                );
            }
            
            user.bank -= withdrawAmount;
            user.coins += withdrawAmount;
            saveEconomy(economy);
            
            await replyWithContext(
                `🏦 *Retiro completado*\n\n` +
                `> 📤 *Cantidad:* ${withdrawAmount.toLocaleString()} coins\n` +
                `> 💰 *Coins actuales:* ${user.coins} coins\n` +
                `> 🏦 *Total en banco:* ${user.bank.toLocaleString()} coins`,
                [senderJid]
            );
            
        } catch (error) {
            console.error('❌ Error en withdraw:', error);
            await options.replyWithContext(`❌ Error: ${error.message}`, [options.senderJid]);
        }
    }
};
