import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 0,
            minerals: {
                piedras: 0,
                diamantes: 0,
                esmeraldas: 0,
                oro: 0,
                rubies: 0,
                zafiros: 0,
                fosiles: 0,
                arcilla: 0,
                carbon: 0,
                hierro: 0,
                platino: 0,
                cobre: 0
            },
            health: 100,
            level: 1,
            exp: 0,
            lastMine: 0,
            lastWork: 0,
            lastCrime: 0,
            lastAdventure: 0,
            lastClaim: 0,
            lastChest: 0,
            lastHunt: 0,
            lastFish: 0,
            lastExcavar: 0,
            lastTesoro: 0,
            lastReciclar: 0,
            lastMina2: 0,
            lastMina3: 0,
            items: {
                agua: 0,
                vendas: 0,
                pastillas: 0,
                pico: 1,
                mapa: 0,
                pala: 1
            }
        };
    }
    return economy[userNumber];
}

function getRemainingTime(lastUsed, cooldownMs = 240000) { // 4 minutos
    const now = Date.now();
    const timePassed = now - lastUsed;
    
    if (timePassed >= cooldownMs) return 0;
    
    const remaining = cooldownMs - timePassed;
    const seconds = Math.floor(remaining / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    
    if (minutes > 0) {
        return `${minutes}m ${remainingSeconds}s`;
    }
    return `${remainingSeconds}s`;
}

// Minerales de mina profunda
const deepMineOres = [
    // Minerales comunes (50%)
    {
        name: "🪨 Piedra de profundidad",
        rarity: "común",
        probability: 0.50,
        minerals: { piedras: [15, 30], carbon: [3, 8] },
        healthCost: [8, 15],
        exp: 10
    },
    {
        name: "⛓️ Hierro reforzado",
        rarity: "común",
        probability: 0.50,
        minerals: { hierro: [5, 12], cobre: [2, 5] },
        healthCost: [10, 18],
        exp: 12
    },
    
    // Minerales raros (30%)
    {
        name: "🪙 Oro profundo",
        rarity: "raro",
        probability: 0.30,
        minerals: { oro: [4, 10], platino: [1, 3] },
        healthCost: [12, 20],
        exp: 20
    },
    {
        name: "🔵 Zafiros",
        rarity: "raro",
        probability: 0.30,
        minerals: { zafiros: [2, 5], diamantes: [1, 3] },
        healthCost: [15, 22],
        exp: 25
    },
    
    // Minerales épicos (15%)
    {
        name: "💎 Diamantes negros",
        rarity: "épico",
        probability: 0.15,
        minerals: { diamantes: [3, 8], rubies: [2, 4] },
        healthCost: [18, 25],
        exp: 35
    },
    {
        name: "🔴 Rubíes de magma",
        rarity: "épico",
        probability: 0.15,
        minerals: { rubies: [3, 6], esmeraldas: [4, 7] },
        healthCost: [20, 28],
        exp: 40
    },
    
    // Minerales legendarios (5%)
    {
        name: "💎💎 Geoda de gemas",
        rarity: "legendario",
        probability: 0.05,
        minerals: { diamantes: [5, 12], rubies: [4, 8], zafiros: [4, 8], platino: [3, 6] },
        healthCost: [25, 35],
        exp: 80,
        special: true
    }
];

export default {
    name: 'mina2',
    alias: ['minaprofund', 'deepmine'],
    
    async execute(sock, msg, options) {
        try {
            const { 
                config, 
                senderNumber, 
                pushName,
                replyWithContext,
                senderJid 
            } = options;
            
            if (!senderNumber) {
                return await replyWithContext(
                    '❌ No se pudo identificar tu número',
                    [senderJid]
                );
            }
            
            let economy = loadEconomy();
            const user = initUserEconomy(economy, senderNumber, pushName);
            
            // Verificar nivel mínimo
            if (user.level < 5) {
                return await replyWithContext(
                    '⚠️ *Necesitas nivel 5 para entrar a la Mina Profunda*\n' +
                    `> Tu nivel: ${user.level}\n` +
                    '> Usa comandos para ganar EXP',
                    [senderJid]
                );
            }
            
            // Verificar salud
            if (user.health < 30) {
                return await replyWithContext(
                    '⚠️ *La Mina Profunda es muy peligrosa*\n' +
                    '> Necesitas al menos 30 de salud',
                    [senderJid]
                );
            }
            
            // Verificar cooldown
            const cooldownTime = 240000; // 4 minutos
            const now = Date.now();
            
            if (user.lastMina2 && (now - user.lastMina2) < cooldownTime) {
                const remaining = getRemainingTime(user.lastMina2, cooldownTime);
                return await replyWithContext(
                    `⏳ *Debes esperar ${remaining}* para volver a la Mina Profunda`,
                    [senderJid]
                );
            }
            
            user.lastMina2 = now;
            
            // Seleccionar mineral
            const rand = Math.random();
            let selectedOre;
            let cumulative = 0;
            
            for (const ore of deepMineOres) {
                cumulative += ore.probability;
                if (rand < cumulative) {
                    selectedOre = ore;
                    break;
                }
            }
            
            if (!selectedOre) selectedOre = deepMineOres[0];
            
            // Calcular salud perdida
            const saludPerdida = Math.floor(Math.random() * (selectedOre.healthCost[1] - selectedOre.healthCost[0] + 1)) + selectedOre.healthCost[0];
            user.health = Math.max(0, user.health - saludPerdida);
            
            // Generar minerales
            let mineralsText = '';
            let totalValue = 0;
            
            for (const [mineral, range] of Object.entries(selectedOre.minerals)) {
                const cantidad = Math.floor(Math.random() * (range[1] - range[0] + 1)) + range[0];
                
                if (!user.minerals[mineral]) user.minerals[mineral] = 0;
                user.minerals[mineral] += cantidad;
                
                const emoji = mineral === 'piedras' ? '🪨' :
                             mineral === 'carbon' ? '🪨' :
                             mineral === 'hierro' ? '⛓️' :
                             mineral === 'cobre' ? '🥉' :
                             mineral === 'oro' ? '🪙' :
                             mineral === 'platino' ? '🥈' :
                             mineral === 'diamantes' ? '💎' :
                             mineral === 'rubies' ? '🔴' :
                             mineral === 'zafiros' ? '🔵' :
                             mineral === 'esmeraldas' ? '💚' : '📦';
                
                mineralsText += `${emoji} *${mineral}:* +${cantidad}\n`;
                
                // Valor para bonus
                if (mineral === 'diamantes') totalValue += cantidad * 20;
                else if (mineral === 'rubies') totalValue += cantidad * 18;
                else if (mineral === 'zafiros') totalValue += cantidad * 15;
                else if (mineral === 'platino') totalValue += cantidad * 12;
                else if (mineral === 'oro') totalValue += cantidad * 8;
                else totalValue += cantidad * 2;
            }
            
            // Bonus por pico
            if (user.items.pico > 1) {
                const bonus = Math.floor(totalValue * 0.15 * user.items.pico);
                user.coins += bonus;
                mineralsText += `\n⛏️ *Bonus pico nivel ${user.items.pico}:* +${bonus} coins`;
            }
            
            // Bonus especial legendario
            if (selectedOre.special) {
                user.coins += 100;
                mineralsText += `\n✨ *¡Veta legendaria!* +100 coins extra`;
            }
            
            // Ganar EXP
            user.exp += selectedOre.exp;
            
            // Verificar subida de nivel
            if (user.exp >= user.level * 100) {
                user.level += 1;
                user.exp = 0;
                mineralsText += `\n\n⭐ *¡Subiste a nivel ${user.level}!*`;
            }
            
            saveEconomy(economy);
            
            // Determinar color según rareza
            let rarityColor = '';
            switch(selectedOre.rarity) {
                case 'común': rarityColor = '🟢'; break;
                case 'raro': rarityColor = '🔵'; break;
                case 'épico': rarityColor = '🟣'; break;
                case 'legendario': rarityColor = '🟡'; break;
            }
            
            const mina2Text = `⛏️ *MINA PROFUNDA (NIVEL 2)*\n\n` +
                `${selectedOre.name}\n` +
                `${rarityColor} *Rareza:* ${selectedOre.rarity.toUpperCase()}\n\n` +
                `🎑 *MINERALES OBTENIDOS*\n\n` +
                mineralsText +
                `\n\n❤️ *Salud perdida:* -${saludPerdida}\n` +
                `📊 *EXP ganada:* +${selectedOre.exp}`;
            
            await replyWithContext(mina2Text, [senderJid]);
            
        } catch (error) {
            console.error('❌ Error en comando mina2:', error);
        }
    }
};
