import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 0,
            minerals: {
                piedras: 0,
                diamantes: 0,
                esmeraldas: 0,
                oro: 0
            },
            health: 100,
            lastMine: 0,
            lastWork: 0,
            lastCrime: 0,
            lastAdventure: 0,
            lastClaim: 0,
            lastChest: 0,
            lastHunt: 0,
            lastFish: 0,
            items: {
                agua: 0,
                vendas: 0,
                pastillas: 0
            }
        };
    }
    return economy[userNumber];
}

function getRemainingTime(lastUsed, cooldownMs = 180000) { // 3 minutos
    const now = Date.now();
    const timePassed = now - lastUsed;
    
    if (timePassed >= cooldownMs) return 0;
    
    const remaining = cooldownMs - timePassed;
    const seconds = Math.floor(remaining / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    
    if (minutes > 0) {
        return `${minutes}m ${remainingSeconds}s`;
    }
    return `${remainingSeconds}s`;
}

// Animales para cazar
const animals = [
    // Animales comunes (60% probabilidad)
    {
        name: "🐇 Conejo",
        rarity: "común",
        probability: 0.60,
        coins: [15, 25],
        healthCost: [2, 5],
        exp: 5
    },
    {
        name: "🦊 Zorro",
        rarity: "común",
        probability: 0.60,
        coins: [20, 35],
        healthCost: [3, 6],
        exp: 8
    },
    {
        name: "🦌 Venado",
        rarity: "común",
        probability: 0.60,
        coins: [25, 40],
        healthCost: [4, 7],
        exp: 10
    },
    
    // Animales raros (30% probabilidad)
    {
        name: "🐗 Jabalí",
        rarity: "raro",
        probability: 0.30,
        coins: [40, 70],
        healthCost: [8, 15],
        exp: 15
    },
    {
        name: "🐺 Lobo",
        rarity: "raro",
        probability: 0.30,
        coins: [50, 85],
        healthCost: [10, 18],
        exp: 18
    },
    {
        name: "🐆 Jaguar",
        rarity: "raro",
        probability: 0.30,
        coins: [60, 100],
        healthCost: [12, 20],
        exp: 20
    },
    
    // Animales épicos (8% probabilidad)
    {
        name: "🐻 Oso",
        rarity: "épico",
        probability: 0.08,
        coins: [100, 180],
        healthCost: [15, 25],
        exp: 30
    },
    {
        name: "🦅 Águila Real",
        rarity: "épico",
        probability: 0.08,
        coins: [120, 200],
        healthCost: [10, 20],
        exp: 35
    },
    
    // Animales legendarios (2% probabilidad)
    {
        name: "🐉 Dragón",
        rarity: "legendario",
        probability: 0.02,
        coins: [300, 600],
        healthCost: [25, 40],
        exp: 100,
        special: true
    },
    {
        name: "🦄 Unicornio",
        rarity: "legendario",
        probability: 0.02,
        coins: [250, 500],
        healthCost: [15, 25],
        exp: 80,
        special: "✨ ¡Cuerno mágico! +50 coins extra"
    }
];

export default {
    name: 'cazar',
    alias: ['hunt', 'caza'],
    
    async execute(sock, msg, options) {
        try {
            const { 
                config, 
                senderNumber, 
                pushName,
                replyWithContext,
                senderJid 
            } = options;
            
            if (!senderNumber) {
                return await replyWithContext(
                    '❌ No se pudo identificar tu número',
                    [senderJid]
                );
            }
            
            let economy = loadEconomy();
            const user = initUserEconomy(economy, senderNumber, pushName);
            
            // Verificar salud mínima
            if (user.health < 15) {
                return await replyWithContext(
                    '⚠️ *Estás muy débil para cazar*\n' +
                    '> Necesitas al menos 15 de salud\n' +
                    '> Usa *heal* para recuperarte',
                    [senderJid]
                );
            }
            
            // Verificar cooldown de 3 minutos
            const cooldownTime = 180000; // 3 minutos
            const now = Date.now();
            
            if (user.lastHunt && (now - user.lastHunt) < cooldownTime) {
                const remaining = getRemainingTime(user.lastHunt, cooldownTime);
                return await replyWithContext(
                    `⏳ *Debes esperar ${remaining}* para volver a cazar`,
                    [senderJid]
                );
            }
            
            // Actualizar tiempo
            user.lastHunt = now;
            
            // Seleccionar animal basado en probabilidades
            const rand = Math.random();
            let animal;
            
            // Primero filtrar por rareza
            if (rand < 0.6) { // 60% común
                const comunes = animals.filter(a => a.rarity === 'común');
                animal = comunes[Math.floor(Math.random() * comunes.length)];
            } else if (rand < 0.9) { // 30% raro
                const raros = animals.filter(a => a.rarity === 'raro');
                animal = raros[Math.floor(Math.random() * raros.length)];
            } else if (rand < 0.98) { // 8% épico
                const épicos = animals.filter(a => a.rarity === 'épico');
                animal = épicos[Math.floor(Math.random() * épicos.length)];
            } else { // 2% legendario
                const legendarios = animals.filter(a => a.rarity === 'legendario');
                animal = legendarios[Math.floor(Math.random() * legendarios.length)];
            }
            
            // Calcular ganancias y pérdidas
            const coinsGanados = Math.floor(Math.random() * (animal.coins[1] - animal.coins[0] + 1)) + animal.coins[0];
            const saludPerdida = Math.floor(Math.random() * (animal.healthCost[1] - animal.healthCost[0] + 1)) + animal.healthCost[0];
            
            // Aplicar cambios
            user.coins += coinsGanados;
            user.health = Math.max(0, user.health - saludPerdida);
            
            // Bonus especial para legendarios
            let specialText = '';
            if (animal.special) {
                if (animal.name === "🐉 Dragón") {
                    user.coins += 100;
                    specialText = '\n🐉 *¡Escamas de dragón!* +100 coins extra';
                } else if (animal.name === "🦄 Unicornio") {
                    user.coins += 50;
                    user.health = Math.min(100, user.health + 20);
                    specialText = '\n🦄 *¡Cuerno mágico!* +50 coins y +20 salud';
                }
            }
            
            saveEconomy(economy);
            
            // Determinar emoji según rareza
            let rarityEmoji = '';
            switch(animal.rarity) {
                case 'común': rarityEmoji = '🟢'; break;
                case 'raro': rarityEmoji = '🔵'; break;
                case 'épico': rarityEmoji = '🟣'; break;
                case 'legendario': rarityEmoji = '🟡'; break;
            }
            
            const huntText = `🏹 *CAZA EXITOSA*\n\n` +
                `${animal.name}\n` +
                `${rarityEmoji} *Rareza:* ${animal.rarity.toUpperCase()}\n\n` +
                `🎑 *RECOMPENSAS*\n\n` +
                `💰 Coins obtenidos » *+${coinsGanados}*\n` +
                `❤️ Salud perdida » *-${saludPerdida}*${specialText}\n\n` +
                `📊 *Total:* ${user.coins} coins | ${user.health} salud`;
            
            await replyWithContext(huntText, [senderJid]);
            
        } catch (error) {
            console.error('❌ Error en comando cazar:', error);
            await options.replyWithContext(
                `❌ Error: ${error.message}`,
                [options.senderJid]
            );
        }
    }
};
