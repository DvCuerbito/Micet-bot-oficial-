import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'listgif',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, sender } = options;
            const from = msg.key.remoteJid;
            const user = msg.key.participant || from;
            
            // Solo el owner puede usar este comando
            const OWNER_ID = '189202503315478@lid';
            
            if (user !== OWNER_ID) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}listgif\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const descFile = path.join(__dirname, '..', 'databases', 'gif_descriptions.json');
            let descriptions = {};
            
            if (fs.existsSync(descFile)) {
                descriptions = JSON.parse(fs.readFileSync(descFile, 'utf8'));
            }

            const categories = Object.keys(descriptions);
            
            if (categories.length === 0) {
                await sock.sendMessage(from, {
                    text: '❖ No hay descripciones guardadas.',
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            let message = `⌢͡  "‿⌣ ⌢͜‿🍒⌢͡ ͡ ͙͜ ‿⌢͡‿ި͝   ‿ި͝\n\n`;

            categories.forEach(categoryName => {
                const categoryDescriptions = descriptions[categoryName];
                
                message += `╭─⊷ *${categoryName.toUpperCase()}*\n`;
                
                categoryDescriptions.forEach((desc, index) => {
                    message += `│\n`;
                    message += `│⃝⋆ー★. *𐔌ׅ⃨࣪֩֠࣪N𖹭mbreᦡ* : ${categoryName}\n`;
                    message += `│⃝⋆ー★. *𐔌ׅ⃨࣪֩֠࣪Descᦡ* : ${desc.text}\n`;
                    message += `│⃝⋆ー★. *𐔌ׅ⃨࣪֩֠࣪Agregadaᦡ* : ${desc.addedAt}\n`;
                    
                    if (index < categoryDescriptions.length - 1) {
                        message += `│═══════════════════════════\n`;
                    }
                });
                
                message += `│\n`;
                message += `╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n\n`;
            });

            message += `͙＿＿＿＿＿＿͙＿＿＿＿＿\n\n`;
            message += `📊 Total de categorías: *${categories.length}*`;

            await sock.sendMessage(from, { 
                text: message,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });

        } catch (error) {
            console.log('Error en comando listgif:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: '❖ Error al obtener la lista de descripciones.',
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};