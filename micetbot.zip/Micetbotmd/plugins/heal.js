import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 0,
            minerals: {
                piedras: 0,
                diamantes: 0,
                esmeraldas: 0,
                oro: 0
            },
            health: 100,
            lastMine: null,
            lastWork: null,
            items: {
                agua: 0,
                vendas: 0,
                pastillas: 0
            }
        };
    }
    return economy[userNumber];
}

export default {
    name: 'heal',
    alias: ['curar', 'cure', 'recuperar'],
    
    async execute(sock, msg, options) {
        try {
            const { 
                config, 
                senderNumber, 
                pushName,
                replyWithContext,
                senderJid,
                args 
            } = options;
            
            const from = msg.key.remoteJid;
            
            if (!senderNumber) {
                return await replyWithContext(
                    '❌ No se pudo identificar tu número',
                    [senderJid]
                );
            }
            
            let economy = loadEconomy();
            const user = initUserEconomy(economy, senderNumber, pushName);
            
            // Verificar si tiene recursos
            if (user.items.agua < 1 && user.items.vendas < 1 && user.items.pastillas < 1) {
                return await replyWithContext(
                    '⭐ No tienes suficientes recursos para curarte\n' +
                    '> Compra items con *buy*',
                    [senderJid]
                );
            }
            
            // Si ya tiene salud completa
            if (user.health >= 100) {
                return await replyWithContext(
                    '❤️ Ya tienes la salud al máximo',
                    [senderJid]
                );
            }
            
            // Calcular cuánto se puede curar
            const healthNeeded = 100 - user.health;
            let healthHealed = 0;
            let itemsUsed = [];
            
            // Usar pastillas (curan 30)
            if (user.items.pastillas > 0 && healthHealed < healthNeeded) {
                const pastillasToUse = Math.min(
                    user.items.pastillas,
                    Math.ceil((healthNeeded - healthHealed) / 30)
                );
                if (pastillasToUse > 0) {
                    healthHealed += pastillasToUse * 30;
                    user.items.pastillas -= pastillasToUse;
                    itemsUsed.push(`${pastillasToUse}💊`);
                }
            }
            
            // Usar vendas (curan 20)
            if (user.items.vendas > 0 && healthHealed < healthNeeded) {
                const vendasToUse = Math.min(
                    user.items.vendas,
                    Math.ceil((healthNeeded - healthHealed) / 20)
                );
                if (vendasToUse > 0) {
                    healthHealed += vendasToUse * 20;
                    user.items.vendas -= vendasToUse;
                    itemsUsed.push(`${vendasToUse}🩹`);
                }
            }
            
            // Usar agua (cura 10)
            if (user.items.agua > 0 && healthHealed < healthNeeded) {
                const aguaToUse = Math.min(
                    user.items.agua,
                    Math.ceil((healthNeeded - healthHealed) / 10)
                );
                if (aguaToUse > 0) {
                    healthHealed += aguaToUse * 10;
                    user.items.agua -= aguaToUse;
                    itemsUsed.push(`${aguaToUse}🍶`);
                }
            }
            
            // Aplicar curación (sin pasar de 100)
            const finalHealth = Math.min(100, user.health + healthHealed);
            user.health = finalHealth;
            
            saveEconomy(economy);
            
            const itemsUsedText = itemsUsed.length > 0 
                ? `> Usaste: ${itemsUsed.join(' • ')}` 
                : '';
            
            await replyWithContext(
                `💉 *Te has curado*\n` +
                `> Salud » *${finalHealth}*/100\n\n` +
                itemsUsedText,
                [senderJid]
            );
            
        } catch (error) {
            console.error('❌ Error en comando heal:', error);
            await options.replyWithContext(
                `❌ Error: ${error.message}`,
                [options.senderJid]
            );
        }
    }
};
