import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'delbot',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderNumber } = options;
            const from = msg.key.remoteJid;
            
            // Verificar si el usuario es owner (desde config.js)
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isOwner) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}delbot\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar si se proporcionó un número
            if (!args || args.length === 0) {
                await sock.sendMessage(from, {
                    text: `🍀 Debes proporcionar el nombre de la carpeta\n> Ejemplo » ${config.prefix}delbot 521XXXXXXXXX`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Obtener el número a buscar (solo dígitos)
            const folderName = args[0].replace(/\D/g, '');
            
            if (!folderName || folderName.length < 8) {
                await sock.sendMessage(from, {
                    text: `🍀 Número inválido. Debe tener al menos 8 dígitos.`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Rutas a verificar
            const sessionsPath = path.join(process.cwd(), 'Sessions');
            const subsPath = path.join(sessionsPath, 'Subs');
            const mainPath = path.join(sessionsPath, 'Main');
            
            let folderFound = false;
            let deletedPath = '';
            let folderType = '';
            
            // Buscar en Sessions/Subs
            if (fs.existsSync(subsPath)) {
                const subFolders = fs.readdirSync(subsPath, { withFileTypes: true })
                    .filter(d => d.isDirectory());
                
                for (const folder of subFolders) {
                    // Limpiar el nombre de la carpeta (eliminar cualquier cosa que no sea dígitos)
                    const cleanFolderName = folder.name.replace(/\D/g, '');
                    
                    if (cleanFolderName === folderName) {
                        const fullPath = path.join(subsPath, folder.name);
                        try {
                            fs.rmSync(fullPath, { recursive: true, force: true });
                            folderFound = true;
                            deletedPath = fullPath;
                            folderType = 'Sub-Bot';
                            console.log(`🗑️ Carpeta de Sub-Bot eliminada: ${fullPath}`);
                        } catch (deleteError) {
                            console.error(`Error eliminando carpeta ${fullPath}:`, deleteError);
                        }
                        break;
                    }
                }
            }
            
            // Si no se encontró en Subs, buscar en Sessions/Main
            if (!folderFound && fs.existsSync(mainPath)) {
                const mainFolders = fs.readdirSync(mainPath, { withFileTypes: true })
                    .filter(d => d.isDirectory());
                
                for (const folder of mainFolders) {
                    const cleanFolderName = folder.name.replace(/\D/g, '');
                    
                    if (cleanFolderName === folderName) {
                        const fullPath = path.join(mainPath, folder.name);
                        try {
                            fs.rmSync(fullPath, { recursive: true, force: true });
                            folderFound = true;
                            deletedPath = fullPath;
                            folderType = 'Main-Bot';
                            console.log(`🗑️ Carpeta de Main-Bot eliminada: ${fullPath}`);
                        } catch (deleteError) {
                            console.error(`Error eliminando carpeta ${fullPath}:`, deleteError);
                        }
                        break;
                    }
                }
            }
            
            // Responder según el resultado
            if (folderFound) {
                await sock.sendMessage(from, {
                    text: `⭐ Carpeta Eliminada\n\n> Tipo: ${folderType}\n> Número: ${folderName}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, {
                    text: `🧭 No se ha encontrado la carpeta para el número *${folderName}*`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            }
            
        } catch (error) {
            console.error('❌ Error en comando delbot:', error);
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ Error al eliminar la carpeta: ${error.message}`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};
