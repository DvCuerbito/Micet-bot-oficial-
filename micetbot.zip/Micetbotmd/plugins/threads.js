import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const API_STARLIGHT = 'https://apis-starlights-team.koyeb.app/starlight/threads-DL';
const API_NEJI = 'https://neji-api.vercel.app/api/downloader/threads';

const tempFolder = path.join(__dirname, '..', 'tmp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `threads_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

export default {
    name: 'threads',
    alias: ['th'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const url = args.join(' ').trim();
            
            if (!url) {
                await replyWithContext(
                    `🍬 Deberes proporcionar un link\n> Ejemplo: ${config.prefix}threads https://www.threads.net/...`,
                    []
                );
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📥', key: msg.key } });
            } catch (e) {}
            
            let mediaUrls = [];
            let videos = [];
            let apiUsed = '';
            
            // Intentar primero con API Starlight
            try {
                const response = await axios.get(`${API_STARLIGHT}?url=${encodeURIComponent(url)}`, {
                    timeout: 30000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    }
                });
                
                if (response.data) {
                    if (response.data.images && Array.isArray(response.data.images)) {
                        mediaUrls = response.data.images;
                        apiUsed = 'Starlight';
                    }
                    if (response.data.videos && Array.isArray(response.data.videos)) {
                        videos = response.data.videos;
                        apiUsed = 'Starlight';
                    }
                }
            } catch (error) {
                console.log('❌ API Starlight falló:', error.message);
            }
            
            // Si Starlight falló, intentar con Neji
            if (mediaUrls.length === 0 && videos.length === 0) {
                try {
                    const response = await axios.get(`${API_NEJI}?url=${encodeURIComponent(url)}`, {
                        timeout: 30000,
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    
                    if (response.data?.success) {
                        if (response.data.media_urls && Array.isArray(response.data.media_urls)) {
                            mediaUrls = response.data.media_urls;
                        } else if (response.data.download_url) {
                            mediaUrls = [response.data.download_url];
                        }
                        apiUsed = 'Neji';
                    }
                } catch (error) {
                    console.log('❌ API Neji falló:', error.message);
                }
            }
            
            // Combinar todo el contenido
            const allMedia = [...mediaUrls, ...videos];
            
            if (allMedia.length === 0) {
                throw new Error('No se encontró contenido para descargar');
            }
            
            // Descargar todos los archivos
            const mediaBuffers = [];
            for (let i = 0; i < allMedia.length; i++) {
                try {
                    const fileResponse = await axios.get(allMedia[i], {
                        responseType: 'arraybuffer',
                        timeout: 30000
                    });
                    mediaBuffers.push(Buffer.from(fileResponse.data));
                } catch (err) {
                    console.error(`Error descargando archivo ${i + 1}:`, err.message);
                }
            }
            
            if (mediaBuffers.length === 0) {
                throw new Error('No se pudo descargar ningún archivo');
            }
            
            // Determinar si es video o imágenes
            const isVideo = videos.length > 0 || allMedia[0].includes('.mp4');
            
            if (isVideo) {
                // Enviar video directamente
                await sock.sendMessage(from, {
                    video: mediaBuffers[0],
                    caption: `> Solicitado por: ${pushName || 'Usuario'}`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                // Enviar imágenes como cards (carrusel)
                const cards = [];
                const defaultImage = mediaBuffers[0];
                
                for (let i = 0; i < mediaBuffers.length; i++) {
                    cards.push({
                        image: mediaBuffers[i],
                        title: `🍬 Imagen ${i + 1}/${mediaBuffers.length}`,
                        body: `> Solicitado por: ${pushName || 'Usuario'}`,
                        footer: `✨ Threads | Imagen ${i + 1}/${mediaBuffers.length}`
                    });
                }
                
                await sock.sendMessage(from, {
                    text: `*Threads - Carrusel de Imágenes*\n\n *Total:* ${cards.length} imágenes\n *Solicitado por:* ${pushName || 'Usuario'}`,
                    title: '🌺 THREADS CARRUSEL',
                    subtile: `${cards.length} imágenes disponibles`,
                    footer: '✨ Moonlight Bot ✨',
                    cards: cards
                }, { quoted: msg });
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Threads descargado por ${pushName || 'Usuario'} - ${mediaBuffers.length} archivos (${apiUsed})`);
            
        } catch (error) {
            console.error('❌ Error en threads:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(
                `❌ *Error:* ${error.message}`,
                []
            );
        }
    }
};