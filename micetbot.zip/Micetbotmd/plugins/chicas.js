import axios from 'axios';

export default {
    name: 'chicas',
    alias: ['girls'],

    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, usersDB } = options;
            const from = msg.key.remoteJid;

            // Reacción de proceso
            try {
                await sock.sendMessage(from, { react: { text: '🍑', key: msg.key } });
            } catch (e) {}

            // URL de la API que devuelve la imagen directamente
            const apiUrl = `https://api.delirius.store/nsfw/girls`;

            // Enviamos la imagen con la estructura que solicitaste
            await sock.sendMessage(from, {
                image: { url: apiUrl },
                caption: 'Girls nsfw',
                footer: 'Made By StarLyn',
                headerType: 4, // Tipo 4 para mensajes con imagen y footer
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            // Reacción de éxito
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}

        } catch (error) {
            console.error('❌ Error en comando chicas:', error);
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `🔞 Ocurrió un error al obtener la imagen.`,
                contextInfo: { isForwarded: true }
            }, { quoted: msg });
        }
    }
};