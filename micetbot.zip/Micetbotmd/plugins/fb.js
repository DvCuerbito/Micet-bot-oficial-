import fetch from 'node-fetch';

async function getFacebookMedia(url) {
    const apis = [
        { endpoint: `https://api.stellar-api.my.id/dl/facebook?url=${encodeURIComponent(url)}&key=stellar`, extractor: res => {
            if (!res.status || !Array.isArray(res.resultados)) return null;
            const hd = res.resultados.find(x => x.quality?.includes('720p'));
            const sd = res.resultados.find(x => x.quality?.includes('360p'));
            const media = hd || sd;
            if (!media?.url) return null;
            return { type: 'video', title: null, resolution: media.quality || null, format: 'mp4', url: media.url };
        }},
        { endpoint: `https://api.ootaizumi.my.id/downloader/facebook?url=${encodeURIComponent(url)}`, extractor: res => {
            if (!res.status || !res.result?.downloads?.length) return null;
            const hd = res.result.downloads.find(x => x.quality?.includes('720p'));
            const sd = res.result.downloads.find(x => x.quality?.includes('360p'));
            const media = hd || sd;
            if (!media?.url) return null;
            return { type: media.url.includes('.jpg') ? 'image' : 'video', title: null, resolution: media.quality || null, format: media.url.includes('.jpg') ? 'jpg' : 'mp4', url: media.url, thumbnail: res.result.thumbnail || null };
        }},
        { endpoint: `https://api.vreden.my.id/api/v1/download/facebook?url=${encodeURIComponent(url)}`, extractor: res => {
            if (!res.status || !res.result?.download) return null;
            const hd = res.result.download.hd;
            const sd = res.result.download.sd;
            const urlVideo = hd || sd;
            if (!urlVideo) return null;
            return { type: 'video', title: res.result.title || null, resolution: hd ? 'HD' : 'SD', format: 'mp4', url: urlVideo, thumbnail: res.result.thumbnail || null, duration: res.result.durasi || null };
        }},
        { endpoint: `https://api.delirius.com/download/facebook?url=${encodeURIComponent(url)}`, extractor: res => {
            if (!res.urls || !Array.isArray(res.urls)) return null;
            const hd = res.urls.find(x => x.hd)?.hd;
            const sd = res.urls.find(x => x.sd)?.sd;
            const urlVideo = hd || sd;
            if (!urlVideo) return null;
            return { type: 'video', title: res.title || null, resolution: hd ? 'HD' : 'SD', format: 'mp4', url: urlVideo };
        }}
    ];

    for (const { endpoint, extractor } of apis) {
        try {
            const res = await fetch(endpoint).then(r => r.json());
            const result = extractor(res);
            if (result) return result;
        } catch {}
        await new Promise(r => setTimeout(r, 500));
    }
    return null;
}

export default {
    name: 'fb',
    alias: ['facebook', 'fbdl'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (!args || !args.length) {
                return await sock.sendMessage(from, {
                    text: `🌸 *Debes proporcionar un enlace de Facebook*\n> Ejemplo: ${config.prefix}fb https://facebook.com/...`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            const url = args[0].trim();
            
            if (!url.match(/facebook\.com|fb\.watch|video\.fb\.com/)) {
                return await sock.sendMessage(from, {
                    text: `⭐ *Enlace inválido*\n\n> Envía un enlace de Facebook válido`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            const data = await getFacebookMedia(url);
            
            if (!data) {
                return await sock.sendMessage(from, {
                    text: `🌽 No se pudo obtener el contenido del enlace`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            const caption = `╭ִׄ─ֺ࡙─ᰮ̥━̼╸╼ֺ࡙🍒╾ׄ╺ֺ━ִ─ֺ̥─꥓̼╮ֺ\n         *Facebook*\n⏝ּ̥〫⌣꥓ּ︶̥✿ֺ꤫❀꥓ּ︶ִ̥⌣𝅼⏝ּ̥〫\n\nㅤׅ̥݀֯𐔌ּ࡙݀͡🍭 *Título* » ${data.title || 'Sin título'}\nㅤׅ̥݀֯𐔌ּ࡙݀͡🍭 *Resolución* » ${data.resolution || 'SD'}\nㅤׅ̥݀֯𐔌ּ࡙݀͡🍭 *Formato* » ${data.format || 'mp4'}\nㅤׅ̥݀֯𐔌ּ࡙݀͡🍭 *Duración* » ${data.duration || 'Desconocida'}`;
            
            try {
                await sock.sendMessage(from, { react: { text: '📥', key: msg.key } });
            } catch (e) {}
            
            if (data.type === 'video') {
                await sock.sendMessage(from, {
                    video: { url: data.url },
                    caption: caption,
                    mimetype: 'video/mp4',
                    fileName: 'facebook_video.mp4',
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else if (data.type === 'image') {
                await sock.sendMessage(from, {
                    image: { url: data.url },
                    caption: caption,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                throw new Error('Contenido no soportado');
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Facebook video descargado por ${pushName || 'Usuario'}: ${url}`);
            
        } catch (error) {
            console.error('❌ Error en fb:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ Error: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};