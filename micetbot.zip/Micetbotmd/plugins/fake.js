function copy(obj) {
    return JSON.parse(JSON.stringify(obj));
}

export default {
    name: 'fake',
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const OWNER_ID = '5219992042946';
            const cleanSenderNumber = senderNumber ? senderNumber.replace(/[^0-9]/g, '') : '';
            
            // Solo el owner puede usar este comando
            if (cleanSenderNumber !== OWNER_ID) {
                await replyWithContext(
                    `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}fake\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help`,
                    []
                );
                return;
            }
            
            const txt = `🚩 Ejemplos de uso.\n\n${config.prefix}fake ¿quién soy? *@user* eres mi putita`;
            
            if (!args || args.length === 0) {
                await replyWithContext(txt, []);
                return;
            }
            
            const fullText = args.join(' ');
            let who = null;
            
            // Buscar mención en el texto
            const mentionMatch = fullText.match(/@([0-9]+)/);
            
            if (mentionMatch) {
                who = `${mentionMatch[1]}@s.whatsapp.net`;
            }
            
            // Si no hay mención, usar el chat actual
            if (!who) {
                who = from;
            }
            
            // Extraer el texto real (sin la mención)
            const sp = '@' + who.split('@')[0];
            const spIndex = fullText.indexOf(sp);
            
            let fakeText = '';
            let realText = '';
            
            if (spIndex !== -1) {
                fakeText = fullText.substring(0, spIndex).trim();
                realText = fullText.substring(spIndex + sp.length).trim();
            } else {
                // Si no hay formato con mención, usar todo como real
                realText = fullText;
                fakeText = 'Mensaje falso';
            }
            
            if (!realText) {
                await replyWithContext(txt, []);
                return;
            }
            
            // Crear mensaje falso
            const fakeMessage = {
                key: {
                    remoteJid: from,
                    fromMe: false,
                    id: msg.key.id,
                    participant: who
                },
                message: {
                    conversation: fakeText
                }
            };
            
            // Enviar respuesta como si fuera del usuario mencionado
            await sock.sendMessage(from, {
                text: realText,
                mentions: [who]
            }, { quoted: fakeMessage });
            
            console.log(`✅ Fake message enviado por OWNER ${senderNumber} como ${who}`);
            
        } catch (error) {
            console.error('❌ Error en fake:', error);
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ Error: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};