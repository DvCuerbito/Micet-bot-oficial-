import fs from 'fs';
import path from 'path';

export default {
  name: 'setusername',
  alias: ['setbotname'],
  
  async execute(sock, msg, options) {
    try {
      const { config, senderNumber, args } = options;
      const from = msg.key.remoteJid;
      
      // ==========================================
      // OBTENER NÚMERO DEL BOT
      // ==========================================
      let botNumber = '';
      if (sock.phoneNumber) {
        botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
      } else if (sock.user?.id) {
        botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
      }
      
      // ==========================================
      // VERIFICAR SI EL USUARIO ES EL BOTOWNER
      // ==========================================
      const isBotOwner = config.botowner && 
                        config.botowner.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '');

      if (!isBotOwner) {
        return await sock.sendMessage(from, { 
          text: '❀ *Solo el dueño del bot puede cambiar el nombre de usuario*',
          contextInfo: {
            forwardingScore: 9999999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: config.canalId || '',
              serverMessageId: 0,
              newsletterName: config.canalNombre || ''
            }
          }
        }, { quoted: msg });
      }

      if (!args[0]) {
        return await sock.sendMessage(from, { 
          text: '《✧》 *Ingresa el nuevo nombre del bot*\n\n' + 'Ejemplo: *' + config.prefix + 'setusername Mi Nuevo Nombre*',
          contextInfo: {
            forwardingScore: 9999999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: config.canalId || '',
              serverMessageId: 0,
              newsletterName: config.canalNombre || ''
            }
          }
        }, { quoted: msg });
      }

      const newName = args.join(' ');
      if (newName.length > 25) {
        return await sock.sendMessage(from, { 
          text: '《✧》 *El nombre del bot no debe pasar los 25 caracteres*',
          contextInfo: {
            forwardingScore: 9999999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: config.canalId || '',
              serverMessageId: 0,
              newsletterName: config.canalNombre || ''
            }
          }
        }, { quoted: msg });
      }

      try {
        await sock.updateProfileName(newName);
        await sock.sendMessage(from, { 
          text: '《✧》 *El nombre del bot se ha cambiado a "' + newName + '"*\n> Por el dueño del bot',
          contextInfo: {
            forwardingScore: 9999999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: config.canalId || '',
              serverMessageId: 0,
              newsletterName: config.canalNombre || ''
            }
          }
        }, { quoted: msg });
      } catch (error) {
        console.error('[SETUSERNAME] Error:', error);
        await sock.sendMessage(from, { 
          text: '《✧》 *No se pudo cambiar el nombre del bot*',
          contextInfo: {
            forwardingScore: 9999999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: config.canalId || '',
              serverMessageId: 0,
              newsletterName: config.canalNombre || ''
            }
          }
        }, { quoted: msg });
      }
      
    } catch (error) {
      console.error('Error en setusername:', error);
    }
  }
};
