import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ruta del archivo de configuración de privado
const PRIVADO_CONFIG_FILE = path.join(__dirname, '..', 'databases', 'privado.json');

// Función para cargar configuración de privado
function loadPrivadoConfig() {
    try {
        if (fs.existsSync(PRIVADO_CONFIG_FILE)) {
            const data = fs.readFileSync(PRIVADO_CONFIG_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando privado.json:', error);
    }
    // Por defecto, el bot responde en privado (activado)
    return { enabled: true };
}

// Función para guardar configuración de privado
function savePrivadoConfig(config) {
    try {
        const dir = path.dirname(PRIVADO_CONFIG_FILE);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(PRIVADO_CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando privado.json:', error);
        return false;
    }
}

export default {
    name: 'privado',
    alias: ['private', 'privatemode'],
    
    async execute(sock, msg, options) {
        try {
            const { args, config, senderNumber, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            // Verificar si el usuario es el owner (desde config.js)
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isOwner) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}privado\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar argumentos
            if (!args || args.length === 0) {
                const privadoConfig = loadPrivadoConfig();
                const estado = privadoConfig.enabled ? '✅ ACTIVADO' : '❌ DESACTIVADO';
                
                await sock.sendMessage(from, {
                    text: `🌺 *Comando Privado*\n\n` +
                          `Estado actual: *${estado}*\n\n` +
                          `*Uso:*\n` +
                          `> ${config.prefix}privado on - Activar respuestas en privado\n` +
                          `> ${config.prefix}privado off - Desactivar respuestas en privado\n\n` +
                          `*Nota:* Cuando está desactivado, el bot NO responde a NINGÚN comando en chat privado, solo responde con "comando no existe" cuando se usa un comando que no existe.`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            const action = args[0].toLowerCase();
            
            if (action !== 'on' && action !== 'off') {
                await sock.sendMessage(from, {
                    text: `🌺 Debes especificar *on* u *off*\n\nEjemplo: ${config.prefix}privado off`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Cargar configuración actual
            const privadoConfig = loadPrivadoConfig();
            const newState = action === 'on';
            
            // Verificar si ya está en ese estado
            if (privadoConfig.enabled === newState) {
                const estadoTexto = newState ? 'activado' : 'desactivado';
                await sock.sendMessage(from, {
                    text: `🌺 El modo privado ya estaba *${estadoTexto}*.`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Actualizar configuración
            privadoConfig.enabled = newState;
            privadoConfig.updatedAt = new Date().toISOString();
            privadoConfig.updatedBy = senderNumber;
            
            const saved = savePrivadoConfig(privadoConfig);
            
            if (saved) {
                const estadoTexto = newState ? '✅ ACTIVADO' : '❌ DESACTIVADO';
                const mensaje = newState 
                    ? `🌺 *Modo privado activado*\n\nEl bot ahora responderá normalmente a todos los comandos en chat privado.`
                    : `🌺 *Modo privado desactivado*\n\nEl bot ahora NO responderá a NINGÚN comando en chat privado, excepto cuando se use un comando que no existe.\n\n> Para activarlo de nuevo, usa ${config.prefix}privado on`;
                
                await sock.sendMessage(from, {
                    text: mensaje,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                
                console.log(`🔒 Modo privado ${newState ? 'activado' : 'desactivado'} por OWNER: ${pushName || senderNumber}`);
            } else {
                await sock.sendMessage(from, {
                    text: `❌ Error al guardar la configuración.`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            }
            
        } catch (error) {
            console.error('❌ Error en comando privado:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ Error: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};
