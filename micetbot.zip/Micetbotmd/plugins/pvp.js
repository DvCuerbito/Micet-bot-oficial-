import fs from 'fs';
import path from 'path';

export default {
    name: 'pvp',
    alias: ['fight'],
    
    async execute(sock, msg, options) {
        try {
            const { config, sender, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // Determinar el usuario mencionado
            const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
            
            let opponent;
            
            if (mentionedJid) {
                opponent = mentionedJid;
            } else if (quotedParticipant) {
                opponent = quotedParticipant;
            } else {
                await sock.sendMessage(from, {
                    text: `🌿 Debes mencionar a alguien para pelear\n> Ejemplo: ${config.prefix}pvp @usuario`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // No puede pelearse a sí mismo
            if (opponent === sender) {
                await sock.sendMessage(from, {
                    text: `🌿 No puedes pelearte a ti mismo`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Mensaje de inicio de pelea
            await sock.sendMessage(from, {
                text: `\`P E L E A\`\n\n${pushName ? '@' + sender.split('@')[0] : 'Alguien'} vs @${opponent.split('@')[0]}`,
                mentions: [sender, opponent],
                contextInfo: {
                    mentionedJid: [sender, opponent],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            // Esperar un momento para el resultado
            setTimeout(async () => {
                // Determinar ganador aleatorio
                const winner = Math.random() < 0.5 ? sender : opponent;
                const loser = winner === sender ? opponent : sender;
                
                // Duración aleatoria entre 1 y 5 segundos
                const duration = (Math.random() * 4 + 1).toFixed(1);
                
                // Textos dinámicos de pelea
                const fightTexts = [
                    "no puso pared y murió",
                    "recibió un golpe crítico",
                    "se tropezó y perdió",
                    "fue vencido por su rival",
                    "se quedó sin energía",
                    "recibió un combo letal",
                    "fue noqueado",
                    "se rindió",
                    "cometió un error fatal",
                    "fue demasiado lento"
                ];
                
                const randomText = fightTexts[Math.floor(Math.random() * fightTexts.length)];
                
                await sock.sendMessage(from, {
                    text: `🍰 \`F I N - P V P\`\n\n🌠 Ganador » @${winner.split('@')[0]}\n🌠 Perdedor » @${loser.split('@')[0]}\n🌠 Duración » ${duration} segundos\n🌠 @${loser.split('@')[0]} ${randomText} a ${winner === sender ? pushName || 'El ganador' : '@' + winner.split('@')[0]}`,
                    mentions: [winner, loser],
                    contextInfo: {
                        mentionedJid: [winner, loser],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                });
                
            }, 3000); // Esperar 3 segundos para el resultado
            
        } catch (error) {
            console.error('Error en pvp:', error);
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `🌿 Error en la pelea: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};
