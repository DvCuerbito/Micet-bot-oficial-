import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Función para cargar users.json
function loadUsersDB() {
    try {
        const usersFile = path.join(__dirname, '..', 'databases', 'users.json');
        if (fs.existsSync(usersFile)) {
            const data = fs.readFileSync(usersFile, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando users.json:', error);
    }
    return {};
}

// Extraer número de cualquier JID
function extractNumberFromJid(jid) {
    if (!jid) return null;
    return jid.split('@')[0].replace(/\D/g, '');
}

// Obtener nombre para mostrar de un usuario
function getDisplayName(usersDB, userIdentifier, defaultName = 'Usuario') {
    try {
        if (!userIdentifier) return defaultName;
        
        // Extraer número
        const userNumber = extractNumberFromJid(userIdentifier);
        
        // Buscar en usersDB por número
        if (userNumber && usersDB[userNumber]) {
            return usersDB[userNumber].pushName || usersDB[userNumber].name || userNumber;
        }
        
        // Buscar por LID
        for (const [num, userData] of Object.entries(usersDB)) {
            if (userData.lid === userIdentifier || userData.jid === userIdentifier) {
                return userData.pushName || userData.name || num;
            }
        }
        
        // Si no se encuentra, devolver el número
        return userNumber || userIdentifier.split('@')[0] || defaultName;
        
    } catch (error) {
        console.error('Error obteniendo nombre para mostrar:', error);
        return defaultName;
    }
}

export default {
    name: 'slap',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, senderNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            // Cargar base de datos de usuarios
            const usersDB = loadUsersDB();
            
            // Usuario que ejecuta el comando
            const user1Jid = senderJid;
            const userName1 = pushName || senderNumber || 'Usuario';
            
            console.log('🔍 Debug - Datos del mensaje:');
            console.log('  Sender JID:', senderJid);
            console.log('  Sender number:', senderNumber);
            console.log('  PushName:', pushName);
            
            // Variables para el usuario objetivo
            let user2Jid = null;
            let userName2 = null;
            
            // Verificar si hay mensaje citado
            const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
            
            // Verificar si hay menciones en el texto
            let mentionedJids = [];
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
                mentionedJids = msg.message.extendedTextMessage.contextInfo.mentionedJid;
            }
            
            console.log('  Quoted participant:', quotedParticipant);
            console.log('  Mentioned JIDs:', mentionedJids);
            
            // Prioridad 1: Hay mención con @
            if (mentionedJids && mentionedJids.length > 0) {
                user2Jid = mentionedJids[0];
                userName2 = getDisplayName(usersDB, user2Jid, 'Usuario mencionado');
                console.log(`  ✅ Usando mención: ${user2Jid} -> Nombre: ${userName2}`);
            }
            // Prioridad 2: Hay mensaje citado
            else if (quotedParticipant) {
                user2Jid = quotedParticipant;
                userName2 = getDisplayName(usersDB, user2Jid, 'Usuario citado');
                console.log(`  ✅ Usando citado: ${user2Jid} -> Nombre: ${userName2}`);
            }
            
            // Si no hay usuario 2, usar el mismo usuario 1
            if (!userName2) {
                userName2 = userName1;
                console.log('  ℹ️ No hay usuario objetivo, usando el mismo:', userName2);
            }
            
            console.log('📝 Nombres finales:', { userName1, userName2, user2Jid });

            // Cargar categorías
            const categoriesFile = path.join(__dirname, '..', 'databases', 'categories.json');
            let categories = {};
            
            if (fs.existsSync(categoriesFile)) {
                try {
                    categories = JSON.parse(fs.readFileSync(categoriesFile, 'utf8'));
                } catch (e) {
                    console.log('Error parsing categories.json:', e);
                }
            }

            const categoryName = 'slap';
            if (!categories[categoryName] || !categories[categoryName].videos?.length) {
                await sock.sendMessage(from, {
                    text: '❖ No hay GIFs disponibles en la categoría *slap*',
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const category = categories[categoryName];
            const randomIndex = Math.floor(Math.random() * category.videos.length);
            const videoInfo = category.videos[randomIndex];
            
            // Cargar descripciones
            const descFile = path.join(__dirname, '..', 'databases', 'gif_descriptions.json');
            let descriptions = {};
            let descriptionText = `${userName1} abofetea a ${userName2}`;
            
            if (fs.existsSync(descFile)) {
                try {
                    descriptions = JSON.parse(fs.readFileSync(descFile, 'utf8'));
                    
                    if (descriptions[categoryName]?.length > 0) {
                        const randomDescIndex = Math.floor(Math.random() * descriptions[categoryName].length);
                        const selectedDesc = descriptions[categoryName][randomDescIndex].text;
                        
                        descriptionText = selectedDesc
                            .replace(/\{user\}/g, userName1)
                            .replace(/\{user1\}/g, userName1)
                            .replace(/\{user2\}/g, userName2);
                    }
                } catch (e) {
                    console.log('Error parsing descriptions:', e);
                }
            }

            const videosDir = path.join(__dirname, '..', 'videos');
            const gifPath = path.join(videosDir, categoryName, videoInfo.filename);

            if (!fs.existsSync(gifPath)) {
                await sock.sendMessage(from, {
                    text: '❖ Error: El archivo GIF no existe.',
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const gifBuffer = fs.readFileSync(gifPath);

            // Preparar lista de menciones
            const mentions = [];
            if (senderJid) mentions.push(senderJid);
            if (user2Jid && user2Jid !== senderJid) mentions.push(user2Jid);

            console.log('📤 Enviando mensaje:');
            console.log('  Descripción:', descriptionText);
            console.log('  Menciones:', mentions);

            try {
                await sock.sendMessage(from, {
                    video: gifBuffer,
                    caption: descriptionText,
                    gifPlayback: true,
                    mimetype: 'video/mp4',
                    fileName: `${categoryName}.mp4`,
                    mentions: mentions,
                    contextInfo: {
                        mentionedJid: mentions,
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
                console.log(`✅ Comando slap ejecutado: ${userName1} -> ${userName2}`);
                
            } catch (error1) {
                console.log('❌ Error enviando como video:', error1);
                try {
                    await sock.sendMessage(from, {
                        image: gifBuffer,
                        caption: descriptionText,
                        mimetype: 'image/gif',
                        mentions: mentions,
                        contextInfo: {
                            mentionedJid: mentions,
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                } catch (error2) {
                    console.log('❌ Error enviando como imagen:', error2);
                    await sock.sendMessage(from, {
                        text: descriptionText,
                        mentions: mentions,
                        contextInfo: {
                            mentionedJid: mentions,
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
            }

        } catch (error) {
            console.log(`❌ Error en comando slap:`, error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❖ Error al ejecutar el comando: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};
