import fetch from 'node-fetch';
import axios from 'axios';

export default {
    name: 'playdoc',
    alias: ['mp4doc', 'ytdoc'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            const text = args.join(' ').trim();
            
            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso: ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            if (!text) {
                await sock.sendMessage(from, {
                    text: `ꕤ Por favor, ingresa la URL del vídeo de YouTube.\n\n*Ejemplo:*\n${config.prefix}playdoc https://youtu.be/ejemplo`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Validar URL de YouTube
            const youtubeRegex = /^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/;
            
            if (!youtubeRegex.test(text)) {
                await sock.sendMessage(from, {
                    text: `🌠 *Enlace inválido*\n\nPor favor, ingresa un enlace válido de YouTube.\nEjemplo: https://youtu.be/ejemplo`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // React de espera
            await sock.sendMessage(from, {
                react: {
                    text: "🕒",
                    key: msg.key
                }
            });

            // Obtener información del video
            const videoInfo = await ytdl(text);
            
            if (!videoInfo || !videoInfo.url) {
                throw new Error('No se pudo obtener el video');
            }

            // Obtener tamaño del archivo
            const size = await getSize(videoInfo.url);
            const sizeStr = size ? await formatSize(size) : 'Desconocido';

            // Preparar caption con formato Kana
            const caption = `🌠 *YouTube Video*\n\n` +
                           `✧ *Título:* ${videoInfo.title || 'Sin título'}\n` +
                           `✧ *Duración:* ${videoInfo.duration || 'N/A'}\n` +
                           `✧ *Calidad:* ${videoInfo.quality || 'HD'}\n` +
                           `✧ *Peso:* ${sizeStr}\n` +
                           `✧ *Solicitado por:* ${pushName || 'Usuario'}\n\n` +
                           `🌠 Bot » *${config.name}*`;

            // Enviar video como documento
            await sock.sendMessage(from, {
                document: { 
                    url: videoInfo.url 
                },
                fileName: `${videoInfo.title.replace(/[^\w\s]/gi, '')}.mp4`,
                mimetype: 'video/mp4',
                caption: caption,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });

            // React de éxito
            await sock.sendMessage(from, {
                react: {
                    text: "✅",
                    key: msg.key
                }
            });

        } catch (error) {
            console.error('❌ Error en comando playdoc:', error);
            
            // React de error
            await sock.sendMessage(msg.key.remoteJid, {
                react: {
                    text: "❌",
                    key: msg.key
                }
            });
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `ꕤ Se ha producido un problema al descargar el video.\n\n*Error:* ${error.message || 'Desconocido'}\n\n> » Usa *${options.config.prefix}report* para informarlo.`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};

// Función para obtener información y URL del video
async function ytdl(url) {
    const headers = {
        "accept": "*/*",
        "accept-language": "es-ES,es;q=0.9,en;q=0.8",
        "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "cross-site",
        "Referer": "https://ytmp3.mobi/",
        "Referrer-Policy": "strict-origin-when-cross-origin",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    };

    try {
        // Inicializar API
        const initial = await fetch(`https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Date.now()}`, { headers });
        const init = await initial.json();
        
        if (!init.convertURL) {
            throw new Error('API no disponible');
        }

        // Extraer ID del video
        const videoId = url.match(/(?:youtu\.be\/|youtube\.com\/(?:.*v=|.*\/|.*embed\/))([^&?/]+)/)?.[1];
        
        if (!videoId) {
            throw new Error('ID de video no válido');
        }

        // URL de conversión
        const convertURL = `${init.convertURL}&v=${videoId}&f=mp4&_=${Date.now()}`;
        
        const converts = await fetch(convertURL, { headers });
        const convert = await converts.json();

        if (!convert.downloadURL || !convert.progressURL) {
            throw new Error('Error en la conversión del video');
        }

        // Esperar procesamiento
        let info = {};
        let attempts = 0;
        const maxAttempts = 10; // Más intentos para videos largos
        
        while (attempts < maxAttempts) {
            const progressResponse = await fetch(convert.progressURL, { headers });
            info = await progressResponse.json();
            
            if (info.progress === 3) { // Completado
                break;
            }
            
            if (info.error) {
                throw new Error(info.error);
            }
            
            attempts++;
            await new Promise(resolve => setTimeout(resolve, 2000)); // Esperar 2 segundos
        }

        if (!info.title) {
            info.title = `YouTube Video ${videoId}`;
        }

        return {
            url: convert.downloadURL,
            title: info.title,
            duration: info.duration || 'N/A',
            quality: info.quality || 'HD'
        };

    } catch (error) {
        console.error('Error en ytdl:', error);
        throw error;
    }
}

// Función para formatear tamaño
async function formatSize(bytes) {
    if (!bytes || isNaN(bytes)) return 'Desconocido';
    
    const units = ['B', 'KB', 'MB', 'GB'];
    let i = 0;
    
    while (bytes >= 1024 && i < units.length - 1) {
        bytes /= 1024;
        i++;
    }
    
    return `${bytes.toFixed(2)} ${units[i]}`;
}

// Función para obtener tamaño del archivo
async function getSize(url) {
    try {
        const response = await axios.head(url, {
            timeout: 5000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        const contentLength = response.headers['content-length'];
        return contentLength ? parseInt(contentLength, 10) : null;
        
    } catch (error) {
        console.error("Error al obtener tamaño:", error.message);
        return null;
    }
}
