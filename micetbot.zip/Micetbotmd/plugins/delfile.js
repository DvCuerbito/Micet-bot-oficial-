import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'delfile',
    alias: [],

    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;

            // Verificar registro
            if (usersDB && senderNumber &&!usersDB[senderNumber]) {
                await sock.sendMessage(from, {
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Solo owner
            const isOwner = config.owner && config.owner.some(num =>
                num.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            if (!isOwner) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}delfile\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Verificar nombre de archivo
            if (!args || args.length === 0) {
                await sock.sendMessage(from, {
                    text: `💐 *Debes dar el nombre del archivo a borrar*\n> Ejemplo: ${config.prefix}delfile plugins/ping.js`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const fileName = args[0];
            if (fileName.includes('..')) {
                await sock.sendMessage(from, {
                    text: `💐 *Nombre no válido*`,
                    contextInfo: { forwardedNewsletterMessageInfo: { newsletterJid: config.canalId || '', serverMessageId: 0, newsletterName: config.canalNombre || '' }, forwardingScore: 9999999, isForwarded: true }
                }, { quoted: msg });
                return;
            }

            const baseDir = path.join(__dirname, '..');
            const filePath = path.join(baseDir, fileName);

            if (!fs.existsSync(filePath)) {
                await sock.sendMessage(from, {
                    text: `💐 *El archivo no existe*`,
                    contextInfo: { forwardedNewsletterMessageInfo: { newsletterJid: config.canalId || '', serverMessageId: 0, newsletterName: config.canalNombre || '' }, forwardingScore: 9999999, isForwarded: true }
                }, { quoted: msg });
                return;
            }

            fs.unlinkSync(filePath);
            await sock.sendMessage(from, {
                text: `🗑️ *Archivo Borrado*\n\n🍃 *Nombre:* ${fileName}\n🍃 *Borrado:* ${new Date().toLocaleTimeString()}`,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });

        } catch (error) {
            await sock.sendMessage(msg.key.remoteJid, {
                text: `💐 *Error al borrar*\n> ${error.message.substring(0, 100)}`,
                contextInfo: { forwardedNewsletterMessageInfo: { newsletterJid: options.config.canalId || '', serverMessageId: 0, newsletterName: options.config.canalNombre || '' }, forwardingScore: 9999999, isForwarded: true }
            }, { quoted: msg });
        }
    }
};