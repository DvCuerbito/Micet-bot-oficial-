import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

export default {
    name: 'alimentar',
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderNumber, pushName, replyWithContext, senderJid } = options;
            
            if (!senderNumber) {
                return await replyWithContext('❌ No se pudo identificar tu número', [senderJid]);
            }
            
            const petName = args.join(' ').trim().toLowerCase();
            
            if (!petName) {
                return await replyWithContext(
                    `🍖 *Alimentar mascota*\n\n> Uso: ${config.prefix}alimentar <nombre de la mascota>\n> Ejemplo: ${config.prefix}alimentar perro`,
                    [senderJid]
                );
            }
            
            let economy = loadEconomy();
            
            if (!economy[senderNumber]) {
                return await replyWithContext(`❌ No tienes mascotas\n\n> Compra una con ${config.prefix}storepets`, [senderJid]);
            }
            
            const user = economy[senderNumber];
            
            if (!user.pets || user.pets.length === 0) {
                return await replyWithContext(`❌ No tienes mascotas\n\n> Compra una con ${config.prefix}storepets`, [senderJid]);
            }
            
            // Buscar mascota por nombre
            const pet = user.pets.find(p => p.name.toLowerCase().includes(petName));
            
            if (!pet) {
                const petList = user.pets.map(p => `• ${p.emoji} ${p.name}`).join('\n');
                return await replyWithContext(
                    `❌ No encontré la mascota *${petName}*\n\n🐾 *Tus mascotas:*\n${petList}`,
                    [senderJid]
                );
            }
            
            if (!user.foods || user.foods.length === 0) {
                return await replyWithContext(
                    `🛒 *No tienes suficientes comida para tu mascota*\n> Compra más comida para alimentar`,
                    [senderJid]
                );
            }
            
            // Usar la primera comida disponible
            const food = user.foods.shift();
            
            pet.health = Math.min(pet.health + food.health, 100);
            
            saveEconomy(economy);
            
            await replyWithContext(
                `❤️ *Mascota alimentada con éxito*\n\n` +
                `> 🐾 *Mascota:* ${pet.emoji} ${pet.name}\n` +
                `> 🍽️ *Comida usada:* ${food.emoji} ${food.name}\n` +
                `> ❤️ *Salud actual:* ${pet.health}%\n\n` +
                `> 📦 *Te quedan:* ${user.foods.length} comida(s)`,
                [senderJid]
            );
            
        } catch (error) {
            console.error('❌ Error en alimentar:', error);
            await replyWithContext(`❌ Error: ${error.message}`, [senderJid]);
        }
    }
};