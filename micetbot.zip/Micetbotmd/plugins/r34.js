import fetch from 'node-fetch';

export default {
    name: 'r34',
    alias: ['rule34'],

    execute: async (sock, msg, options) => {
        const { 
            replyWithContext, 
            sender, 
            args, 
            config, 
            pushName 
        } = options;

        const from = msg.key.remoteJid;

        try {
            // Validar si hay tags para buscar
            if (!args[0]) {
                return replyWithContext(
                    `⭐ Debes especificar etiquetas para buscar.\n> Ejemplo: *${config.prefix || '.'}r34 neko*`, 
                    [sender]
                );
            }

            // Reacción de espera
            try { await sock.sendMessage(from, { react: { text: '🕒', key: msg.key } }); } catch {}

            // Unir argumentos con guiones bajos para la API
            const tag = args.join('_');
            const url = `https://api.rule34.xxx/index.php?page=dapi&s=post&q=index&json=1&tags=${tag}&api_key=a4e807dd6d4c9e55768772996946e4074030ec02c49049d291e5edb8808a97b004190660b4b36c3d21699144c823ad93491d066e73682a632a38f9b6c3cf951b&user_id=5753302`;

            const res = await fetch(url, { 
                headers: { 
                    'User-Agent': 'Mozilla/5.0', 
                    'Accept': 'application/json' 
                } 
            });

            if (!res.ok) throw new Error('Error en la respuesta de la API');

            const json = await res.json();
            
            // Extraer y filtrar los resultados (imágenes, gifs o videos)
            const data = Array.isArray(json) ? json : (json?.post || []);
            const validMedia = data
                .map(i => i?.file_url || i?.sample_url)
                .filter(u => typeof u === 'string' && /\.(jpe?g|png|gif|mp4)$/i.test(u));

            if (!validMedia.length) {
                try { await sock.sendMessage(from, { react: { text: '❌', key: msg.key } }); } catch {}
                return replyWithContext(`《✧》 No se encontraron resultados para: *${tag}*`, [sender]);
            }

            // Seleccionar uno al azar de la lista
            const selected = validMedia[Math.floor(Math.random() * validMedia.length)];
            const caption = `🔞 *Rule34 Results* 🔞\n> Tag: ${tag}\n> Pedido por: ${pushName}`;

            // Enviar video o imagen según la extensión
            const isVideo = selected.toLowerCase().endsWith('.mp4');
            
            await sock.sendMessage(from, { 
                [isVideo ? 'video' : 'image']: { url: selected }, 
                caption: caption,
                mentions: [sender]
            }, { quoted: msg });

            // Reacción de éxito
            try { await sock.sendMessage(from, { react: { text: '✔️', key: msg.key } }); } catch {}

        } catch (error) {
            console.error('Error en r34:', error);
            try { await sock.sendMessage(from, { react: { text: '✖️', key: msg.key } }); } catch {}
            replyWithContext(`❌ Error al buscar: ${error.message}`, [sender]);
        }
    }
}