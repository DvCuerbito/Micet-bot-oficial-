import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { downloadMediaMessage } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'setbanner',
    alias: ['cambiarbanner'],
    
    execute: async (sock, msg, options) => {
        try {
            const { config, senderNumber } = options;
            const from = msg.key.remoteJid;
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            
            // OBTENER NÚMERO DEL BOT
            let botNumber = '';
            if (sock.phoneNumber) {
                botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            if (!botNumber) {
                throw new Error('No se pudo identificar el número del bot');
            }
            
            // VERIFICAR SI EL USUARIO ES EL BOTOWNER
            const isBotOwner = config.botowner && 
                              config.botowner.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '');
            
            if (!isBotOwner) {
                await sock.sendMessage(from, {
                    text: `❀ *Solo el dueño del bot puede cambiar su banner*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            if (!quotedMsg) {
                await sock.sendMessage(from, {
                    text: `♡ Debes responder a una imagen para establecer como banner`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            const imageMessage = quotedMsg.imageMessage;
            if (!imageMessage) {
                await sock.sendMessage(from, {
                    text: `♡ Debes responder a una imagen para establecer como banner`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            try {
                console.log(`🖼️ Botowner ${senderNumber} está cambiando el banner...`);
                
                const infoDir = path.join(process.cwd(), 'info', botNumber);
                if (!fs.existsSync(infoDir)) {
                    fs.mkdirSync(infoDir, { recursive: true });
                }
                
                const quotedMsgObj = {
                    key: {
                        remoteJid: from,
                        id: msg.message.extendedTextMessage.contextInfo.stanzaId,
                        participant: msg.message.extendedTextMessage.contextInfo.participant,
                        fromMe: false
                    },
                    message: {
                        imageMessage: imageMessage
                    }
                };
                
                const mediaBuffer = await downloadMediaMessage(
                    quotedMsgObj,
                    'buffer',
                    {},
                    {
                        logger: console,
                        reuploadRequest: sock.updateMediaMessage
                    }
                );
                
                if (!mediaBuffer || mediaBuffer.length === 0) {
                    throw new Error('Buffer de imagen vacío');
                }
                
                // Verificar tamaño
                if (mediaBuffer.length > 5 * 1024 * 1024) {
                    throw new Error('La imagen es demasiado grande (máx 5MB)');
                }
                
                const bannerPath = path.join(infoDir, 'banner.jpg');
                fs.writeFileSync(bannerPath, mediaBuffer);
                
                console.log(`✅ Banner guardado: ${bannerPath} (${mediaBuffer.length} bytes)`);
                
                await sock.sendMessage(from, {
                    text: `❀ *Banner actualizado*`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                
            } catch (error) {
                console.error('Error:', error);
                await sock.sendMessage(from, {
                    text: `🌼 Error: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            }
            
        } catch (error) {
            console.error('Error general:', error);
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ Error: ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};