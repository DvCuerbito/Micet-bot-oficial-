import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

export default {
    name: 'mascotas',
    alias: ['pets', 'mispets', 'petlist'],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, pushName, replyWithContext, senderJid } = options;
            
            if (!senderNumber) {
                return await replyWithContext('❌ No se pudo identificar tu número', [senderJid]);
            }
            
            const economy = loadEconomy();
            
            if (!economy[senderNumber]) {
                return await replyWithContext(`❌ No tienes mascotas\n\n> Compra una con ${config.prefix}storepets`, [senderJid]);
            }
            
            const user = economy[senderNumber];
            
            if (!user.pets || user.pets.length === 0) {
                return await replyWithContext(`❌ No tienes mascotas\n\n> Compra una con ${config.prefix}storepets`, [senderJid]);
            }
            
            let message = `🐾 *TUS MASCOTAS*\n\n`;
            
            for (const pet of user.pets) {
                const healthBar = '❤️'.repeat(Math.floor(pet.health / 10)) + '🖤'.repeat(10 - Math.floor(pet.health / 10));
                message += `${pet.emoji} *${pet.name}*\n`;
                message += `❤️ *Salud:* ${pet.health}% ${healthBar}\n\n`;
            }
            
            message += `🍖 *Comidas disponibles:* ${user.foods?.length || 0}\n`;
            message += `> Usa ${config.prefix}alimentar <nombre> para alimentar`;
            
            await replyWithContext(message, [senderJid]);
            
        } catch (error) {
            console.error('❌ Error en mascotas:', error);
            await replyWithContext(`❌ Error: ${error.message}`, [senderJid]);
        }
    }
};