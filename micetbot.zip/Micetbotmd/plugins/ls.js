import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Lista de rangos permitidos
const ALLOWED_RANKS = ['owner', 'c-owner', 'srmod', 'mod', 'trialmod', 'trial', 'helper', 'applicant'];

export default {
    name: 'ls',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, senderJid, pushName, usersDB, args } = options;
            const from = msg.key.remoteJid;
            
            // Verificar permisos
            const userData = usersDB[senderNumber];
            const userRank = userData?.rank;
            const isAllowed = userRank && ALLOWED_RANKS.includes(userRank);
            
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isOwner && !isAllowed) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}ls\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            await sock.sendMessage(from, {
                react: {
                    text: '📁',
                    key: msg.key
                }
            });

            // Determinar la ruta a listar
            let targetPath = __dirname; // Por defecto, la carpeta del comando actual
            
            if (args.length > 0) {
                // Si se proporciona un argumento, construir la ruta
                const requestedPath = args.join(' ').replace(/\.\./g, ''); // Prevenir path traversal
                targetPath = path.join(process.cwd(), requestedPath);
            }

            // Verificar si la ruta existe
            if (!fs.existsSync(targetPath)) {
                await sock.sendMessage(from, {
                    text: `❖ La ruta especificada no existe: ${args.join(' ') || 'directorio actual'}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Leer el directorio
            const items = fs.readdirSync(targetPath);
            
            // Separar carpetas y archivos
            const folders = [];
            const files = [];

            items.forEach(item => {
                const itemPath = path.join(targetPath, item);
                try {
                    const stat = fs.statSync(itemPath);
                    if (stat.isDirectory()) {
                        folders.push(item);
                    } else {
                        files.push(item);
                    }
                } catch (error) {
                    // Si hay error al acceder al archivo, lo ignoramos
                    console.log(`Error al acceder a ${item}:`, error.message);
                }
            });

            // Ordenar alfabéticamente
            folders.sort((a, b) => a.localeCompare(b));
            files.sort((a, b) => a.localeCompare(b));

            // Construir el mensaje
            let message = `📁 *LISTADO DE DIRECTORIO*\n\n`;
            message += `📍 *Ruta:* \`${targetPath.replace(process.cwd(), '') || '/'}\`\n`;
            message += `📊 *Total:* ${folders.length} carpetas, ${files.length} archivos\n\n`;

            if (folders.length > 0) {
                message += `📂 *CARPETAS:*\n`;
                folders.forEach((folder, index) => {
                    message += `${index + 1}. 📁 ${folder}\n`;
                });
                message += `\n`;
            }

            if (files.length > 0) {
                message += `📄 *ARCHIVOS:*\n`;
                files.forEach((file, index) => {
                    // Obtener extensión para icono
                    const ext = path.extname(file).toLowerCase();
                    let icon = '📄';
                    
                    if (ext === '.js') icon = '🟨';
                    else if (ext === '.json') icon = '📋';
                    else if (ext === '.txt') icon = '📝';
                    else if (ext === '.md') icon = '📘';
                    else if (ext === '.jpg' || ext === '.png' || ext === '.gif') icon = '🖼️';
                    else if (ext === '.mp4' || ext === '.mov') icon = '🎥';
                    else if (ext === '.mp3') icon = '🎵';
                    else if (ext === '.zip' || ext === '.rar') icon = '🗜️';
                    
                    message += `${index + 1}. ${icon} ${file}\n`;
                });
            }

            if (folders.length === 0 && files.length === 0) {
                message += `✨ *El directorio está vacío*`;
            }

            // Agregar información de navegación
            message += `\n\n✎ *Navegación:*\n`;
            message += `> Usa \`${config.prefix}ls <ruta>\` para ver otras carpetas\n`;
            message += `> Ej: \`${config.prefix}ls plugins\` o \`${config.prefix}ls ../\``;

            await sock.sendMessage(from, {
                text: message,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });

        } catch (error) {
            console.error('Error en comando ls:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❖ Error al listar el directorio: ${error.message}`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};
