import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const OWNER_NUMBER = "5219992042946";

export default {
    name: 'setcmd',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { args, config, senderNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            // Verificar si es el owner (por número)
            if (senderNumber !== OWNER_NUMBER) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}setcmd\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Obtener argumentos
            const input = args.join(' ');
            const parts = input.split('=').map(part => part.trim());
            
            if (parts.length < 2 || !parts[0] || !parts[1]) {
                await sock.sendMessage(from, {
                    text: `♡ Uso: ${config.prefix}setcmd nombre categoría = nombre comando\n> Ejemplo: ${config.prefix}setcmd Información = ping`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            const categoryName = parts[0];
            const commandName = parts[1];
            
            // Cargar menú actual
            const menuPath = path.join(__dirname, '..', 'databases', 'menu.json');
            let menuData = { categories: [], banner: 'img/banner.jpg' };
            
            try {
                if (fs.existsSync(menuPath)) {
                    const data = fs.readFileSync(menuPath, 'utf8');
                    menuData = JSON.parse(data);
                }
            } catch (error) {
                console.error('Error cargando menú:', error);
            }
            
            // Buscar categoría
            const categoryIndex = menuData.categories.findIndex(cat => 
                cat.name.toLowerCase() === categoryName.toLowerCase()
            );
            
            if (categoryIndex === -1) {
                await sock.sendMessage(from, {
                    text: `♡ La categoría "${categoryName}" no existe.\nUsa ${config.prefix}setcat primero para crearla.`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar si el comando ya existe en la categoría
            const existingCommand = menuData.categories[categoryIndex].commands.find(cmd => 
                cmd.toLowerCase() === commandName.toLowerCase()
            );
            
            if (existingCommand) {
                await sock.sendMessage(from, {
                    text: `♡ El comando "${commandName}" ya existe en la categoría "${categoryName}".`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Agregar comando a la categoría
            menuData.categories[categoryIndex].commands.push(commandName);
            
            // Guardar menú
            try {
                fs.writeFileSync(menuPath, JSON.stringify(menuData, null, 2));
                
                await sock.sendMessage(from, {
                    text: `♡ Se ha agregado el comando "${commandName}" a la categoría "${categoryName}"`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (error) {
                console.error('Error guardando menú:', error);
                
                await sock.sendMessage(from, {
                    text: `🌼 Error al agregar comando: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            }
        } catch (error) {
            console.error('Error en setcmd:', error);
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ Error: ${error.message}`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};
