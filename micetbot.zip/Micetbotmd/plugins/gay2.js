import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import FormData from 'form-data';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const API_URL = 'https://api.siputzx.my.id/api/canvas/gay';
const DEFAULT_AVATAR = 'https://d.uguu.se/rVVfkyEM.jpeg';

const tempFolder = path.join(__dirname, '..', 'tmp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `gay2_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

function cleanJid(jid) {
    if (!jid) return null;
    return jid.replace(/:\d+@/, '@');
}

function extractNumber(jid) {
    if (!jid) return null;
    let cleaned = cleanJid(jid);
    return cleaned.split('@')[0].replace(/[^0-9]/g, '');
}

function generateUniqueFilename(mime) {
    const ext = mime.split('/')[1] || 'bin';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let id = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    return `${id}.${ext}`;
}

async function uploadCatbox(buffer, mime) {
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, { filename: generateUniqueFilename(mime) });

    const res = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: form.getHeaders(),
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        timeout: 30000
    });

    if (typeof res.data !== 'string' || !res.data.startsWith('https://')) {
        throw new Error('Respuesta inválida de Catbox');
    }
    return res.data;
}

async function uploadUguu(buffer) {
    const form = new FormData();
    form.append('files[]', buffer, generateUniqueFilename('image/jpeg'));

    const res = await axios.post('https://uguu.se/upload.php', form, {
        headers: form.getHeaders(),
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        timeout: 30000
    });

    const url = res.data?.files?.[0]?.url;
    if (!url) throw new Error('Respuesta inválida de Uguu');
    return url;
}

async function uploadQuax(buffer, mime) {
    const form = new FormData();
    form.append('file', buffer, { filename: generateUniqueFilename(mime), contentType: mime });

    const res = await axios.post('https://qu.ax/upload.php', form, {
        headers: form.getHeaders(),
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        timeout: 30000
    });

    const url = res.data?.files?.[0]?.url;
    if (!url) throw new Error('Respuesta inválida de Quax');
    return url;
}

async function uploadAuto(buffer, mime) {
    try {
        return { link: await uploadCatbox(buffer, mime), server: 'catbox' };
    } catch {
        try {
            return { link: await uploadUguu(buffer), server: 'uguu' };
        } catch {
            return { link: await uploadQuax(buffer, mime), server: 'quax' };
        }
    }
}

async function getProfilePicture(sock, jid) {
    try {
        const clean = cleanJid(jid);
        const ppUrl = await sock.profilePictureUrl(clean, 'image');
        if (ppUrl) {
            const response = await axios.get(ppUrl, { responseType: 'arraybuffer' });
            return Buffer.from(response.data, 'binary');
        }
    } catch (error) {
        console.log('No se pudo obtener foto de perfil:', error.message);
    }
    return null;
}

export default {
    name: 'gay2',
    alias: ['gaytest', 'nivelgay'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName, replyWithContext, usersDB } = options;
            const from = msg.key.remoteJid;
            
            // Obtener usuario objetivo (mención o respuesta)
            let targetJid = null;
            let targetNumber = null;
            let targetName = null;
            
            const mencionado = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
            
            if (mencionado) {
                targetJid = cleanJid(mencionado);
                targetNumber = extractNumber(targetJid);
                targetName = usersDB?.[targetNumber]?.pushName || targetNumber;
                console.log(`📌 Usuario por mención: ${targetName} (${targetNumber})`);
            } else if (quotedParticipant) {
                targetJid = cleanJid(quotedParticipant);
                targetNumber = extractNumber(targetJid);
                targetName = usersDB?.[targetNumber]?.pushName || targetNumber;
                console.log(`📌 Usuario por respuesta: ${targetName} (${targetNumber})`);
            } else {
                return await replyWithContext(
                    `🍀 Debes mencionar o responder a un usuario para obtener su nivel de gay`,
                    []
                );
            }
            
            if (!targetName) {
                targetName = targetNumber || 'Usuario';
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🌈', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(`🌈 *Analizando nivel de gay de ${targetName}...*`, []);
            
            // Obtener foto de perfil
            let profilePic = await getProfilePicture(sock, targetJid);
            let imageUrl;
            
            if (profilePic) {
                const upload = await uploadAuto(profilePic, 'image/jpeg');
                imageUrl = upload.link;
                console.log(`✅ Imagen subida a ${upload.server}: ${imageUrl}`);
            } else {
                imageUrl = DEFAULT_AVATAR;
                console.log(`⚠️ Usando imagen por defecto: ${imageUrl}`);
            }
            
            // Número aleatorio del 1% al 100%
            const randomNum = Math.floor(Math.random() * 100) + 1;
            
            // Llamar a la API
            const response = await axios.get(`${API_URL}?nama=${encodeURIComponent(targetName)}&avatar=${encodeURIComponent(imageUrl)}&num=${randomNum}`, {
                responseType: 'arraybuffer',
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (!response.data || response.data.length === 0) {
                throw new Error('No se pudo generar la imagen');
            }
            
            const imageBuffer = Buffer.from(response.data);
            
            await sock.sendMessage(from, {
                image: imageBuffer,
                caption: `> ${targetName} es ${randomNum}% gay 🏳️‍🌈`,
                contextInfo: {
                    mentionedJid: [targetJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Nivel de gay calculado: ${targetName} - ${randomNum}%`);
            
        } catch (error) {
            console.error('❌ Error en gay2:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(
                `❌ *Error:* ${error.message}`,
                []
            );
        }
    }
};