export default {
    name: 'therian',
    alias: ['therianmeter'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            console.log(`🐾 Comando therian ejecutado por: ${senderNumber}`);

            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            let targetUserJid = senderJid;
            let targetUserNumber = senderNumber;

            // Verificar si hay mención
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
                targetUserNumber = targetUserJid.split('@')[0];
                console.log(`✅ Usuario mencionado: ${targetUserNumber}`);
            }
            // Verificar si es respuesta
            else if (msg.message?.extendedTextMessage?.contextInfo?.stanzaId) {
                const quotedMsg = msg.message.extendedTextMessage.contextInfo;
                if (quotedMsg.participant) {
                    targetUserJid = quotedMsg.participant;
                    targetUserNumber = targetUserJid.split('@')[0];
                }
                console.log(`✅ Usuario por respuesta: ${targetUserNumber}`);
            }

            // Obtener nombre del usuario objetivo
            const targetName = usersDB[targetUserNumber]?.pushName || 
                              usersDB[targetUserNumber]?.name || 
                              targetUserNumber;

            // Calcular porcentaje basado en el número del usuario
            let hash = 0;
            for (let i = 0; i < targetUserNumber.length; i++) {
                hash = ((hash << 4) - hash) + targetUserNumber.charCodeAt(i);
                hash = hash & hash;
            }
            const porcentaje = Math.abs(hash) % 101;

            // Determinar animal espiritual según el porcentaje
            let animalEspiritual = "";
            if (porcentaje <= 10) {
                animalEspiritual = "🐭 Ratón - Sigiloso y pequeño";
            } else if (porcentaje <= 20) {
                animalEspiritual = "🐱 Gato - Independiente y curioso";
            } else if (porcentaje <= 30) {
                animalEspiritual = "🐶 Perro - Leal y protector";
            } else if (porcentaje <= 40) {
                animalEspiritual = "🦊 Zorro - Astuto y adaptable";
            } else if (porcentaje <= 50) {
                animalEspiritual = "🐺 Lobo - Social y territorial";
            } else if (porcentaje <= 60) {
                animalEspiritual = "🐻 Oso - Fuerte y tranquilo";
            } else if (porcentaje <= 70) {
                animalEspiritual = "🦅 Águila - Visionario y libre";
            } else if (porcentaje <= 80) {
                animalEspiritual = "🐉 Dragón - Poderoso y místico";
            } else if (porcentaje <= 90) {
                animalEspiritual = "🐺🐆 Licántropo - Transformación total";
            } else {
                animalEspiritual = "🌿 Espíritu primordial - Conectado con todos los animales";
            }

            // Textos dinámicos según el porcentaje
            let textoDinamico = "";
            if (porcentaje <= 10) {
                textoDinamico = "🍃 Apenas sientes conexión con lo animal";
            } else if (porcentaje <= 20) {
                textoDinamico = "🐾 A veces te identificas con mascotas";
            } else if (porcentaje <= 30) {
                textoDinamico = "🌙 Sientes curiosidad por lo salvaje";
            } else if (porcentaje <= 40) {
                textoDinamico = "🍂 Tu lado animal está despertando";
            } else if (porcentaje <= 50) {
                textoDinamico = "🐕 Te sientes cómodo con tu lado animal";
            } else if (porcentaje <= 60) {
                textoDinamico = "🐺 Tu espíritu animal se manifiesta";
            } else if (porcentaje <= 70) {
                textoDinamico = "🌕 Experimentas cambios de comportamiento";
            } else if (porcentaje <= 80) {
                textoDinamico = "🐾 Tu esencia therian es fuerte";
            } else if (porcentaje <= 90) {
                textoDinamico = "🐺🐆 Casi siempre te sientes animal";
            } else {
                textoDinamico = "🌿 Eres pura esencia therian, conectado con la naturaleza";
            }

            // Enviar mensaje de cálculo con las 5 ediciones
            const progressMessages = [
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 20%`,
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 40%`,
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 60%`,
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 80%`,
                `*ׄ─ׄ𖤐─ׄ* 100%`
            ];

            console.log(`🔄 Iniciando cálculo therian para: ${targetName}`);

            // Enviar primer mensaje de progreso
            const progressMsg = await sock.sendMessage(from, { 
                text: `🐾 *Conectando con tu espíritu animal...*\n\n${progressMessages[0]}`,
                contextInfo: {
                    mentionedJid: [targetUserJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            });

            // Editar el mensaje 4 veces más con delay
            for (let i = 1; i < progressMessages.length; i++) {
                await new Promise(resolve => setTimeout(resolve, 1000));
                await sock.sendMessage(from, { 
                    text: `🐾 *Conectando con tu espíritu animal...*\n\n${progressMessages[i]}`,
                    edit: progressMsg.key,
                    contextInfo: {
                        mentionedJid: [targetUserJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                });
                console.log(`📝 Editando mensaje ${i + 1}/5`);
            }

            // Esperar un poco antes del resultado final
            await new Promise(resolve => setTimeout(resolve, 1500));

            // Eliminar mensaje de progreso
            await sock.sendMessage(from, { 
                delete: progressMsg.key 
            });

            // Enviar resultado final
            const resultadoFinal = `🐾 *Conexión Therian completada* de @${targetUserNumber}

🌙 *Porcentaje Therian:* ${porcentaje}%
🐺 *Animal espiritual:* ${animalEspiritual}

> ${textoDinamico}`;

            await sock.sendMessage(from, {
                text: resultadoFinal,
                contextInfo: {
                    mentionedJid: [targetUserJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            console.log(`🎉 Cálculo therian completado: ${targetName} = ${porcentaje}%`);

        } catch (error) {
            console.error(`❌ Error en comando therian:`, error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { 
                    text: `🐾 Error al calcular tu nivel therian: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};