import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const OWNER_NUMBER = "189202503315478";

export default {
    name: 'delcat',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, senderNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            // Solo el owner puede usar este comando (por número)
            if (senderNumber !== OWNER_NUMBER) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}delcat\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const categoria = args.join(' ').trim();
            
            if (!categoria) {
                await sock.sendMessage(from, {
                    text: `🍒 Debes proporcionar el nombre de la categoría.\n\nUso: ${config.prefix}delcat nombre_categoria`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const categoriesFile = path.join(__dirname, '..', 'databases', 'categories.json');
            let categories = {};
            
            if (fs.existsSync(categoriesFile)) {
                categories = JSON.parse(fs.readFileSync(categoriesFile, 'utf8'));
            }
            
            const categoriaKey = Object.keys(categories).find(
                cat => cat.toLowerCase() === categoria.toLowerCase()
            );
            
            if (!categoriaKey) {
                await sock.sendMessage(from, {
                    text: `🍒 La categoría *${categoria}* no existe.`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const categoriaInfo = categories[categoriaKey];
            const totalVideos = categoriaInfo.videos?.length || 0;
            
            const videosDir = path.join(__dirname, '..', 'videos', categoriaKey);
            if (fs.existsSync(videosDir)) {
                fs.rmSync(videosDir, { recursive: true, force: true });
            }
            
            delete categories[categoriaKey];
            fs.writeFileSync(categoriesFile, JSON.stringify(categories, null, 2));

            const descFile = path.join(__dirname, '..', 'databases', 'gif_descriptions.json');
            if (fs.existsSync(descFile)) {
                let descriptions = JSON.parse(fs.readFileSync(descFile, 'utf8'));
                if (descriptions[categoriaKey]) {
                    delete descriptions[categoriaKey];
                    fs.writeFileSync(descFile, JSON.stringify(descriptions, null, 2));
                }
            }

            await sock.sendMessage(from, {
                text: `🍓 Categoría eliminada\n\n` +
                      `> 🍒 Nombre » *${categoriaKey}*\n` +
                      `> 🐞 Videos eliminados » *${totalVideos}*\n` +
                      `> 🌹 Fecha » ${new Date().toLocaleString()}`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });

        } catch (error) {
            console.log('Error en delcat:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `🍒 Error: ${error.message}`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};