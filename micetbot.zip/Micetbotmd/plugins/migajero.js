export default {
    name: 'migajero',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            console.log(`🍞 Comando migajero ejecutado por: ${senderNumber}`);

            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Sumi.18`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            let targetUserJid = senderJid;
            let targetUserNumber = senderNumber;

            // Verificar si hay mención
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
                targetUserNumber = targetUserJid.split('@')[0];
                console.log(`✅ Usuario mencionado: ${targetUserNumber}`);
            }
            // Verificar si es respuesta
            else if (msg.message?.extendedTextMessage?.contextInfo?.stanzaId) {
                const quotedMsg = msg.message.extendedTextMessage.contextInfo;
                if (quotedMsg.participant) {
                    targetUserJid = quotedMsg.participant;
                    targetUserNumber = targetUserJid.split('@')[0];
                }
                console.log(`✅ Usuario por respuesta: ${targetUserNumber}`);
            }

            // Obtener nombre del usuario objetivo
            const targetName = usersDB[targetUserNumber]?.pushName || 
                              usersDB[targetUserNumber]?.name || 
                              targetUserNumber;

            // Calcular porcentaje de "migajero" (qué tan rogón a tu ex eres)
            let hash = 0;
            for (let i = 0; i < targetUserNumber.length; i++) {
                hash = ((hash << 5) - hash) + targetUserNumber.charCodeAt(i);
                hash = hash & hash;
            }
            const porcentaje = Math.abs(hash) % 101;
            console.log(`📊 Porcentaje migajero calculado: ${porcentaje}%`);

            // Textos dinámicos según el porcentaje
            let textoDinamico = "";
            if (porcentaje <= 10) {
                textoDinamico = "🍞 No rogaste ni las migas, tienes dignidad";
            } else if (porcentaje <= 20) {
                textoDinamico = "🍞 Rogaste un poquito, pero con estilo";
            } else if (porcentaje <= 30) {
                textoDinamico = "🍞 Mandaste un mensaje borrado a las 3 AM";
            } else if (porcentaje <= 40) {
                textoDinamico = "🍞 Viste su historia y le diste like sin querer";
            } else if (porcentaje <= 50) {
                textoDinamico = "🍞 Le escribiste feliz cumpleaños aunque ya no hablan";
            } else if (porcentaje <= 60) {
                textoDinamico = "🍞 Revisas su última conexión más de 5 veces al día";
            } else if (porcentaje <= 70) {
                textoDinamico = "🍞 Tienes capturas de pantalla de sus estados";
            } else if (porcentaje <= 80) {
                textoDinamico = "🍞 Rogaste tanto que te dejaron en visto 3 veces seguidas";
            } else if (porcentaje <= 90) {
                textoDinamico = "🍞 Ya hiciste un altar con sus fotos y le prendes velas";
            } else {
                textoDinamico = "🍞 Vro ya deja de rogarle a tu ex, búscate a alguien que te valore. Te mereces más migajas.";
            }

            // Enviar mensaje de cálculo con las 5 ediciones
            const progressMessages = [
                `*─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 20%`,
                `*─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 40%`,
                `*─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 60%`,
                `*─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 80%`,
                `*─ׄ𖤐─ׄ* 100%`
            ];

            console.log(`🔄 Iniciando cálculo migajero para: ${targetName}`);

            // Enviar primer mensaje de progreso
            const progressMsg = await sock.sendMessage(from, { 
                text: `🍞 *Calculando nivel de migajero...*\n\n${progressMessages[0]}`,
                contextInfo: {
                    mentionedJid: [targetUserJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            });

            // Editar el mensaje 4 veces más con delay
            for (let i = 1; i < progressMessages.length; i++) {
                await new Promise(resolve => setTimeout(resolve, 1000));
                await sock.sendMessage(from, { 
                    text: `🍞 *Calculando nivel de migajero...*\n\n${progressMessages[i]}`,
                    edit: progressMsg.key,
                    contextInfo: {
                        mentionedJid: [targetUserJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                });
                console.log(`📝 Editando mensaje ${i + 1}/5`);
            }

            // Esperar un poco antes del resultado final
            await new Promise(resolve => setTimeout(resolve, 1500));

            // Eliminar mensaje de progreso
            await sock.sendMessage(from, { 
                delete: progressMsg.key 
            });

            // Enviar resultado final
            const resultadoFinal = `🍞 *Cálculo migajero completado para* @${targetUserNumber}

> *Porcentaje* : ${porcentaje}% 
> *Diagnóstico* : ${textoDinamico}`;

            await sock.sendMessage(from, {
                text: resultadoFinal,
                contextInfo: {
                    mentionedJid: [targetUserJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            console.log(`🎉 Cálculo migajero completado: ${targetName} = ${porcentaje}%`);

        } catch (error) {
            console.error(`❌ Error en comando migajero:`, error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { 
                    text: `🌸 Error al calcular el nivel migajero: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};