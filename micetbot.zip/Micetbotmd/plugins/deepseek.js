import axios from 'axios';

const API_URL = 'https://www.api-g4nggaa.biz.id/api/ai/deepseek';

export default {
    name: 'deepseek',
    alias: ['ds', 'ia'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const prompt = args.join(' ').trim();
            
            if (!prompt) {
                await replyWithContext(
                    `🌺 Debes proporcionar una pregunta para DeepSeek`,
                    []
                );
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🤔', key: msg.key } });
            } catch (e) {}
            
            const response = await axios.get(`${API_URL}?text=${encodeURIComponent(prompt)}`, {
                timeout: 120000, // 120 segundos de timeout
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'application/json'
                }
            });
            
            let answer = null;
            
            if (response.data?.result) {
                answer = response.data.result;
            } else if (response.data?.response) {
                answer = response.data.response;
            } else if (response.data?.message) {
                answer = response.data.message;
            }
            
            if (!answer) {
                throw new Error('No se pudo obtener respuesta');
            }
            
            // Limpiar [DONE] del final si existe
            answer = answer.replace(/\[DONE\]$/, '').trim();
            
            if (answer.length > 3000) {
                answer = answer.substring(0, 3000) + '\n\n... (respuesta truncada)';
            }
            
            await replyWithContext(
                `✰ *ᗪᗴᗴᑭᔕᗴᗴK :*\n${answer}`,
                []
            );
            
            try {
                await sock.sendMessage(from, { react: { text: '🌟', key: msg.key } });
            } catch (e) {}
            
        } catch (error) {
            console.error('❌ Error en deepseek:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(
                `❌ *Error:* La API está tardando demasiado. Intenta más tarde.`,
                []
            );
        }
    }
};