import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 0,
            minerals: {
                piedras: 0,
                diamantes: 0,
                esmeraldas: 0,
                oro: 0
            },
            health: 100,
            pets: [],
            currentPetIndex: 0,
            lastAdventure: 0,
            items: {
                agua: 0,
                vendas: 0,
                pastillas: 0
            }
        };
    }
    if (!economy[userNumber].pets) economy[userNumber].pets = [];
    if (economy[userNumber].currentPetIndex === undefined) economy[userNumber].currentPetIndex = 0;
    if (economy[userNumber].lastAdventure === undefined) economy[userNumber].lastAdventure = 0;
    return economy[userNumber];
}

function getRemainingTime(lastUsed, cooldownMs = 180000) {
    const now = Date.now();
    const timePassed = now - lastUsed;
    
    if (timePassed >= cooldownMs) return 0;
    
    const remaining = cooldownMs - timePassed;
    const seconds = Math.floor(remaining / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    
    if (minutes > 0) {
        return `${minutes}m ${remainingSeconds}s`;
    }
    return `${remainingSeconds}s`;
}

// Escenarios de aventura
const adventures = [
    {
        name: "🏞️ *EXPLORACIÓN EN LA SELVA*",
        success: {
            text: "Encontraste un tesoro escondido",
            coins: [50, 150],
            petHealth: [-5, -15],
            items: { agua: [1, 3] }
        },
        fail: {
            text: "Tu mascota fue atacada por una serpiente",
            coins: [-20, -50],
            petHealth: [-15, -30],
            items: { vendas: [-1, -2] }
        }
    },
    {
        name: "🏔️ *ESCALADA EN LA MONTAÑA*",
        success: {
            text: "Descubriste una cueva con minerales",
            minerals: { diamantes: [1, 4], oro: [3, 8] },
            petHealth: [-8, -18],
            items: { pastillas: [1, 2] }
        },
        fail: {
            text: "Tu mascota resbaló y cayó por una pendiente",
            petHealth: [-20, -35],
            items: { vendas: [-2, -3] }
        }
    },
    {
        name: "🏜️ *TRAVESÍA EN EL DESIERTO*",
        success: {
            text: "Tu mascota encontró un oasis con recursos",
            coins: [30, 80],
            items: { agua: [2, 4] },
            petHealth: [-3, -8]
        },
        fail: {
            text: "Tu mascota sufrió un golpe de calor",
            petHealth: [-15, -25],
            items: { agua: [-1, -3] }
        }
    },
    {
        name: "🌊 *BUCEO EN EL OCÉANO*",
        success: {
            text: "Tu mascota halló un cofre del tesoro hundido",
            coins: [80, 200],
            minerals: { diamantes: [2, 5], esmeraldas: [3, 7] },
            petHealth: [-5, -12]
        },
        fail: {
            text: "Tu mascota se encontró con un tiburón",
            petHealth: [-25, -40],
            items: { vendas: [-2, -4] }
        }
    },
    {
        name: "🏚️ *RUINAS ANTIGUAS*",
        success: {
            text: "Tu mascota descifró un jeroglífico y obtuviste un tesoro",
            coins: [60, 120],
            minerals: { diamantes: [1, 3], esmeraldas: [2, 5], oro: [4, 9] },
            petHealth: [-4, -10]
        },
        fail: {
            text: "Tu mascota activó una trampa antigua",
            petHealth: [-18, -28],
            coins: [-15, -40]
        }
    }
];

export default {
    name: 'aventura',
    alias: ['adventure', 'explorar'],
    
    async execute(sock, msg, options) {
        try {
            const { 
                config, 
                senderNumber, 
                pushName,
                replyWithContext,
                senderJid,
                args
            } = options;
            
            if (!senderNumber) {
                return await replyWithContext(
                    '❌ No se pudo identificar tu número',
                    [senderJid]
                );
            }
            
            let economy = loadEconomy();
            const user = initUserEconomy(economy, senderNumber, pushName);
            
            // Verificar si tiene mascotas
            if (!user.pets || user.pets.length === 0) {
                return await replyWithContext(
                    '🐾 *No tienes ninguna mascota para llevar a la aventura*\n> Usa *storepets* para comprar una mascota',
                    [senderJid]
                );
            }
            
            // Verificar cooldown
            const cooldownTime = 180000;
            const now = Date.now();
            
            if (user.lastAdventure && (now - user.lastAdventure) < cooldownTime) {
                const remaining = getRemainingTime(user.lastAdventure, cooldownTime);
                return await replyWithContext(
                    `⏳ *Debes esperar ${remaining}* para una nueva aventura`,
                    [senderJid]
                );
            }
            
            // Si hay un argumento numérico (selección directa)
            if (args.length > 0 && !isNaN(parseInt(args[0]))) {
                const petIndex = parseInt(args[0]) - 1;
                
                if (petIndex < 0 || petIndex >= user.pets.length) {
                    return await replyWithContext(
                        `❌ Mascota no encontrada. Tienes ${user.pets.length} mascota(s).`,
                        [senderJid]
                    );
                }
                
                const selectedPet = user.pets[petIndex];
                
                if (selectedPet.health <= 10) {
                    return await replyWithContext(
                        `⚠️ *${selectedPet.emoji || '🐾'} ${selectedPet.name} está muy débil* ⚠️\n> Salud actual: ${selectedPet.health}%\n> Necesita al menos 10% de salud para aventurarse\n> Usa *alimentar ${selectedPet.name}* para recuperarla`,
                        [senderJid]
                    );
                }
                
                user.currentPetIndex = petIndex;
                saveEconomy(economy);
                
                return await this.startAdventure(sock, user, selectedPet, economy, replyWithContext, senderJid, pushName);
            }
            
            // Mostrar lista desplegable de mascotas
            const petRows = [];
            
            for (let i = 0; i < user.pets.length; i++) {
                const pet = user.pets[i];
                const healthStatus = pet.health <= 10 ? '⚠️ DÉBIL' : '❤️ SALUDABLE';
                const healthBar = '❤️'.repeat(Math.floor(pet.health / 10)) + '🖤'.repeat(10 - Math.floor(pet.health / 10));
                
                petRows.push({
                    title: `${pet.name}`,
                    description: `Salud: ${pet.health}% ${healthBar} | ${healthStatus}`,
                    id: `${config.prefix}aventura ${i + 1}`
                });
            }
            
            const sections = [{
                title: "🐾 SELECCIONA TU MASCOTA",
                rows: petRows
            }];
            
            const currentPet = user.pets[user.currentPetIndex];
            const currentPetInfo = currentPet ? `${currentPet.emoji || '🐾'} ${currentPet.name} (${currentPet.health}%)` : 'Ninguna';
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `🗺️ *AVENTURA*\n\n🐾 *Mascota actual:* ${currentPetInfo}\n\n📋 *Selecciona qué mascota quieres llevar a la aventura:*\n> Las mascotas con menos de 10% de salud no pueden aventurarse`,
                footer: "🌙 Moonlight RPG",
                interactiveButtons: [
                    {
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "🐾 Ver mascotas",
                            sections: sections,
                        }),
                    },
                ],
            }, { quoted: msg });
            
        } catch (error) {
            console.error('❌ Error en aventura:', error);
            await replyWithContext(`❌ Error: ${error.message}`, [senderJid]);
        }
    },
    
    async startAdventure(sock, user, pet, economy, replyWithContext, senderJid, pushName) {
        try {
            // Verificar cooldown
            const cooldownTime = 180000;
            const now = Date.now();
            
            if (user.lastAdventure && (now - user.lastAdventure) < cooldownTime) {
                const remaining = getRemainingTime(user.lastAdventure, cooldownTime);
                return await replyWithContext(
                    `⏳ *Debes esperar ${remaining}* para una nueva aventura`,
                    [senderJid]
                );
            }
            
            // Actualizar tiempo de última aventura
            user.lastAdventure = now;
            
            // Seleccionar aventura aleatoria
            const adventure = adventures[Math.floor(Math.random() * adventures.length)];
            
            // Determinar resultado (65% éxito, 35% fracaso)
            const success = Math.random() < 0.65;
            const result = success ? adventure.success : adventure.fail;
            
            // Construir mensaje de resultado
            let resultText = `${adventure.name}\n\n`;
            resultText += `🐾 *Mascota:* ${pet.emoji || '🐾'} ${pet.name}\n`;
            resultText += `🧭 *${result.text}*\n\n`;
            resultText += `🎑 *RESULTADO*\n\n`;
            
            // Aplicar cambios a la mascota
            let petHealthLost = 0;
            if (result.petHealth) {
                petHealthLost = Math.floor(Math.random() * (result.petHealth[1] - result.petHealth[0] + 1)) + result.petHealth[0];
                pet.health = Math.max(0, pet.health + petHealthLost);
                resultText += `🐾 Salud de mascota » *${petHealthLost > 0 ? '-' : ''}${Math.abs(petHealthLost)}* (${pet.health}%)\n`;
            }
            
            // Verificar si la mascota murió
            let petDied = false;
            if (pet.health <= 0) {
                petDied = true;
                resultText += `\n💀 *${pet.emoji || '🐾'} ${pet.name} ha muerto en la aventura*\n`;
                
                // Buscar siguiente mascota viva
                const nextAliveIndex = user.pets.findIndex((p, idx) => idx !== user.currentPetIndex && p.health > 0);
                
                if (nextAliveIndex !== -1) {
                    user.currentPetIndex = nextAliveIndex;
                    const nextPet = user.pets[nextAliveIndex];
                    resultText += `🐾 *Ahora usarás a ${nextPet.emoji || '🐾'} ${nextPet.name}* (Salud: ${nextPet.health}%)\n`;
                } else {
                    resultText += `💔 *No tienes más mascotas vivas. Compra más en storepets o alimenta a las existentes.*\n`;
                }
            }
            
            // Aplicar cambios de coins
            if (result.coins) {
                const coinsChange = Math.floor(Math.random() * (result.coins[1] - result.coins[0] + 1)) + result.coins[0];
                user.coins += coinsChange;
                resultText += `💰 Coins » *${coinsChange > 0 ? '+' : ''}${coinsChange}*\n`;
            }
            
            // Minerales
            if (result.minerals) {
                if (result.minerals.diamantes) {
                    const diamantes = Math.floor(Math.random() * (result.minerals.diamantes[1] - result.minerals.diamantes[0] + 1)) + result.minerals.diamantes[0];
                    user.minerals.diamantes += diamantes;
                    resultText += `💎 Diamantes » *+${diamantes}*\n`;
                }
                if (result.minerals.esmeraldas) {
                    const esmeraldas = Math.floor(Math.random() * (result.minerals.esmeraldas[1] - result.minerals.esmeraldas[0] + 1)) + result.minerals.esmeraldas[0];
                    user.minerals.esmeraldas += esmeraldas;
                    resultText += `💚 Esmeraldas » *+${esmeraldas}*\n`;
                }
                if (result.minerals.oro) {
                    const oro = Math.floor(Math.random() * (result.minerals.oro[1] - result.minerals.oro[0] + 1)) + result.minerals.oro[0];
                    user.minerals.oro += oro;
                    resultText += `🪙 Oro » *+${oro}*\n`;
                }
            }
            
            // Items
            if (result.items) {
                if (result.items.agua) {
                    const cantidad = Math.floor(Math.random() * (result.items.agua[1] - result.items.agua[0] + 1)) + result.items.agua[0];
                    if (result.items.agua[0] < 0) {
                        user.items.agua = Math.max(0, user.items.agua + cantidad);
                        resultText += `🍶 Agua » *${cantidad}*\n`;
                    } else {
                        user.items.agua += cantidad;
                        resultText += `🍶 Agua » *+${cantidad}*\n`;
                    }
                }
                if (result.items.vendas) {
                    const cantidad = Math.floor(Math.random() * (result.items.vendas[1] - result.items.vendas[0] + 1)) + result.items.vendas[0];
                    if (result.items.vendas[0] < 0) {
                        user.items.vendas = Math.max(0, user.items.vendas + cantidad);
                        resultText += `🩹 Vendas » *${cantidad}*\n`;
                    } else {
                        user.items.vendas += cantidad;
                        resultText += `🩹 Vendas » *+${cantidad}*\n`;
                    }
                }
                if (result.items.pastillas) {
                    const cantidad = Math.floor(Math.random() * (result.items.pastillas[1] - result.items.pastillas[0] + 1)) + result.items.pastillas[0];
                    if (result.items.pastillas[0] < 0) {
                        user.items.pastillas = Math.max(0, user.items.pastillas + cantidad);
                        resultText += `💊 Pastillas » *${cantidad}*\n`;
                    } else {
                        user.items.pastillas += cantidad;
                        resultText += `💊 Pastillas » *+${cantidad}*\n`;
                    }
                }
            }
            
            // Si la mascota murió, no dar recompensas
            if (petDied && !resultText.includes("No tienes más mascotas")) {
                resultText += `\n⚠️ *Tu mascota murió en la aventura, no recibiste recompensas* ⚠️`;
                // Revertir cambios si los hubo
                if (result.coins) user.coins -= (result.coins[0] + Math.floor(Math.random() * (result.coins[1] - result.coins[0] + 1)));
            }
            
            saveEconomy(economy);
            
            await replyWithContext(resultText, [senderJid]);
            
        } catch (error) {
            console.error('❌ Error en startAdventure:', error);
            await replyWithContext(`❌ Error: ${error.message}`, [senderJid]);
        }
    }
};
