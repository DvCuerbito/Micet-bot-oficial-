export default {
    name: 'warn',
    alias: ['advertir'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // Verificar que sea un grupo
            if (!from.includes('@g.us')) {
                return;
            }

            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🧸 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Obtener info del grupo
            let groupMetadata;
            try {
                groupMetadata = await sock.groupMetadata(from);
            } catch (error) {
                return;
            }
            
            // Verificar si el usuario es admin del grupo
            const isGroupAdmin = groupMetadata.participants.find(p => {
                if (p.id === senderJid) return true;
                if (p.id.includes(senderNumber || '')) return true;
                if (senderJid && senderJid.includes('@lid')) {
                    const senderNum = senderJid.split('@')[0];
                    if (p.id.includes(senderNum)) return true;
                }
                return false;
            })?.admin;
            
            // Verificar si es owner del bot
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            // Verificar si tiene rango en el bot
            const userData = usersDB[senderNumber];
            const userRank = userData?.rank;
            const hasBotRank = isOwner || (userRank && ['owner', 'c-owner', 'srmod', 'mod'].includes(userRank));
            
            // Verificar permisos
            if (!isGroupAdmin && !hasBotRank) {
                await sock.sendMessage(from, { 
                    text: `🧸 Solo administradores del grupo pueden usar este comando`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }

            // Verificar si hay razón
            if (args.length === 0) {
                await sock.sendMessage(from, { 
                    text: `🍁 Debes proporcionar una razón\n> Ej » ${config.prefix}warn <razon> @usuario`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }

            // 🔥 FUNCIÓN PARA OBTENER EL NÚMERO REAL 🔥
            const getRealPhoneNumber = (jid) => {
                if (!jid) return null;
                const identificador = jid.split('@')[0];
                
                for (const [num, data] of Object.entries(usersDB)) {
                    if (data.lid === jid || data.lid === identificador) return num;
                    if (data.jid === jid || data.jid === identificador) return num;
                }
                
                if (/^[\d]+$/.test(identificador) && identificador.length > 8) return identificador;
                return null;
            };
            
            let targetUserJid = null;
            let targetUserNumber = null;
            let reason = '';

            // 1. Verificar mención
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
                targetUserNumber = getRealPhoneNumber(targetUserJid);
                
                // Filtrar la razón (todo excepto menciones)
                const mentionedJids = msg.message.extendedTextMessage.contextInfo.mentionedJid;
                reason = args.filter(arg => {
                    if (arg.includes('@')) {
                        return !mentionedJids.some(mention => arg.includes(mention.split('@')[0]));
                    }
                    return true;
                }).join(' ').trim();
            }
            // 2. Verificar respuesta
            else if (msg.message?.extendedTextMessage?.contextInfo?.participant) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.participant;
                targetUserNumber = getRealPhoneNumber(targetUserJid);
                reason = args.join(' ').trim();
            }
            // 3. Verificar si hay número en args
            else if (args.length > 0) {
                const possibleNumber = args[0].replace(/[^0-9]/g, '');
                if (possibleNumber && possibleNumber.length > 8) {
                    targetUserNumber = possibleNumber;
                    const found = groupMetadata.participants.find(p => 
                        p.id.includes(possibleNumber) || 
                        p.id.split('@')[0] === possibleNumber
                    );
                    if (found) targetUserJid = found.id;
                    reason = args.slice(1).join(' ').trim();
                }
            }

            if (!targetUserJid || !targetUserNumber) {
                await sock.sendMessage(from, { 
                    text: `🌠 Debes proporcionar a un usuario\n> Responde a un mensaje o menciona con @\n> Ejemplo: ${config.prefix}warn spamear @usuario`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }

            if (!reason) {
                await sock.sendMessage(from, { 
                    text: `🌠 Debes proporcionar una razón\n> Ej » ${config.prefix}warn <razon> @usuario`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar que no se esté advirtiendo al bot
            const botNumber = sock.user.id.split('@')[0].replace(/[^0-9]/g, '');
            if (targetUserNumber === botNumber) {
                await sock.sendMessage(from, { 
                    text: `🌠 No puedes advertir al bot`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }

            // Agregar warn
            const { addWarn, getWarns, clearWarns } = await import('../handler.js');
            const warn = addWarn(targetUserNumber, senderNumber, reason, from);
            
            if (warn) {
                const warnMessage = `🦋 Warn agregado

🌠 Usuario » @${targetUserNumber}
🌠 Razón » *${reason}*
🌠 Fecha » *${warn.date}*
🌠 Administrador » @${senderNumber}`;

                await sock.sendMessage(from, { 
                    text: warnMessage,
                    mentions: [targetUserJid, senderJid],
                    contextInfo: {
                        mentionedJid: [targetUserJid, senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });

                // Verificar si llegó a 3 warns
                const userWarns = getWarns(targetUserNumber, from);
                if (userWarns.length >= 3) {
                    try {
                        await sock.groupParticipantsUpdate(from, [targetUserJid], 'remove');
                        clearWarns(targetUserNumber, from);
                        
                        await sock.sendMessage(from, { 
                            text: `🚫 @${targetUserNumber} *ha sido eliminado del grupo por alcanzar 3 warns*`,
                            mentions: [targetUserJid],
                            contextInfo: {
                                mentionedJid: [targetUserJid],
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                        
                        console.log(`🚫 Usuario ${targetUserNumber} eliminado por 3 warns`);
                    } catch (removeError) {
                        console.log('Error eliminando usuario:', removeError);
                    }
                }

                console.log(`⚠️ Warn agregado a ${targetUserNumber} por ${senderNumber} - Razón: ${reason}`);
            }

        } catch (error) {
            console.error('❌ Error en warn:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { 
                    text: `🌠 Error al agregar warn: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};