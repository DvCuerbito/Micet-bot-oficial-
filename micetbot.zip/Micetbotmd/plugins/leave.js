import fs from 'fs';
import path from 'path';

export default {
  name: 'leave',
  alias: ['salir'],
  
  async execute(sock, msg, options) {
    try {
      const { config, senderNumber } = options;
      const from = msg.key.remoteJid;
      
      // ==========================================
      // OBTENER NÚMERO DEL BOT
      // ==========================================
      let botNumber = '';
      if (sock.phoneNumber) {
        botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
      } else if (sock.user?.id) {
        botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
      }
      
      // ==========================================
      // VERIFICAR SI EL USUARIO ES EL BOTOWNER
      // ==========================================
      const isBotOwner = config.botowner && 
                        config.botowner.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '');

      if (!isBotOwner) {
        return await sock.sendMessage(from, { 
          text: '❀ *Solo el dueño del bot puede usar este comando*',
          contextInfo: {
            forwardingScore: 9999999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: config.canalId || '',
              serverMessageId: 0,
              newsletterName: config.canalNombre || ''
            }
          }
        }, { quoted: msg });
      }

      if (!from.endsWith('@g.us')) {
        return await sock.sendMessage(from, { 
          text: '《✧》 *Este comando solo puede ser usado desde un grupo*',
          contextInfo: {
            forwardingScore: 9999999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: config.canalId || '',
              serverMessageId: 0,
              newsletterName: config.canalNombre || ''
            }
          }
        }, { quoted: msg });
      }

      try {
        let botName = config.name || 'Bot';
        if (sock.user?.name) {
          botName = sock.user.name;
        } else if (sock.userId) {
          const cleanId = sock.userId.split('@')[0];
          botName = cleanId.split(':')[0];
        }

        await sock.sendMessage(from, { 
          text: `《✧》 *${config.name} se está retirando del grupo...*`,
          contextInfo: {
            forwardingScore: 9999999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: config.canalId || '',
              serverMessageId: 0,
              newsletterName: config.canalNombre || ''
            }
          }
        }, { quoted: msg });

        await sock.groupLeave(from);

        console.log(`[LEAVE] Bot ${botName} se retiró del grupo ${from} por su dueño`);
      } catch (error) {
        console.error('[LEAVE] Error:', error);
        await sock.sendMessage(from, { 
          text: '《✧》 *No se pudo retirar al bot del grupo*',
          contextInfo: {
            forwardingScore: 9999999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: config.canalId || '',
              serverMessageId: 0,
              newsletterName: config.canalNombre || ''
            }
          }
        }, { quoted: msg });
      }
      
    } catch (error) {
      console.error('Error en leave:', error);
    }
  }
};
