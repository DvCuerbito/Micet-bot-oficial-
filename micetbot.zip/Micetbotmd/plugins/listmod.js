import fs from 'fs';
import path from 'path';

const ALLOWED_RANKS = ['owner', 'c-owner', 'srmod', 'mod', 'trialmod', 'trial', 'helper', 'applicant'];

export default {
    name: 'listmod',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isOwner) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}listmod\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            const modsList = []
            
            for (const [number, data] of Object.entries(usersDB)) {
                if (data.rank && ALLOWED_RANKS.includes(data.rank)) {
                    modsList.push({
                        number: number,
                        rank: data.rank
                    })
                }
            }
            
            if (modsList.length === 0) {
                await sock.sendMessage(from, {
                    text: `🍃 *No hay moderadores asignados*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            let text = `🪴 *Total mods* » ${modsList.length}\n\n`
            
            modsList.forEach(mod => {
                text += `🌺 *Rango* » ${mod.rank}\n`
                text += `🍬 *Número* » +${mod.number}\n\n`
            })
            
            await sock.sendMessage(from, {
                text: text,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
        } catch (error) {
            console.error('Error en listmod:', error);
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ Error al listar moderadores: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};
