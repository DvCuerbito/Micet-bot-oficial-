import axios from 'axios';

export default {
    name: 'xnxx',
    alias: ['xxx', 'xvideo'],

    async execute(sock, msg, options) {
        try {
            const { args, config } = options;
            const from = msg.key.remoteJid;
            const url = args[0];

            if (!url) {
                return await sock.sendMessage(from, { text: `[ ★ ] Por favor, ingresa un enlace de XNXX` }, { quoted: msg });
            }

            // 1. Reacción de búsqueda
            await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });

            // 2. Consulta a la API de descarga (xnxxdl)
            const apiUrl = `https://api.delirius.store/download/xnxxdl?url=${encodeURIComponent(url)}`;
            const response = await axios.get(apiUrl);
            const res = response.data;

            if (!res.status || !res.data) {
                throw new Error('La API no devolvió datos válidos.');
            }

            const videoData = res.data;
            const downloadUrl = videoData.download.low; // Link directo que entrega la API
            const thumb = videoData.gallery.thumb69;
            const title = videoData.title || 'Video XNXX';

            // 3. Enviar primero la información con la thumb69
            await sock.sendMessage(from, {
                image: { url: thumb },
                caption: `🌼 *XNXX DOWNLOADER*\n\n[ ★ ] *Título:* ${title}\n[ ★ ] *Calidad:* ${videoData.quality}\n\n> ⏳ *Enviando video...*`,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            // 4. ENVÍO DIRECTO: El bot descarga del link de la API y envía a WhatsApp
            // Usamos el link que la API ya generó (low)
            await sock.sendMessage(from, {
                video: { url: downloadUrl }, // Baileys descarga directamente desde este link
                mimetype: 'video/mp4',
                caption: `[ ★ ] 🎬 ${title}`,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true
                }
            }, { quoted: msg });

            await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

        } catch (error) {
            console.error('Error en XNXX API:', error);
            await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            await sock.sendMessage(msg.key.remoteJid, { text: `🔞 Error: ${error.message}` }, { quoted: msg });
        }
    }
};