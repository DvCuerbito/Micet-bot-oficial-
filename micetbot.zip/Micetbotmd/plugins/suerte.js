import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 0,
            minerals: {
                piedras: 0,
                diamantes: 0,
                esmeraldas: 0,
                oro: 0
            },
            health: 100,
            lastMine: 0,
            lastWork: 0,
            lastCrime: 0,
            lastAdventure: 0,
            lastClaim: 0,
            lastChest: 0,
            items: {
                agua: 0,
                vendas: 0,
                pastillas: 0
            }
        };
    }
    return economy[userNumber];
}

export default {
    name: 'suerte',
    alias: ['luck', 'azar'],
    
    async execute(sock, msg, options) {
        try {
            const { 
                config, 
                senderNumber, 
                pushName,
                replyWithContext,
                senderJid,
                args 
            } = options;
            
            if (!senderNumber) {
                return await replyWithContext(
                    '❌ No se pudo identificar tu número',
                    [senderJid]
                );
            }
            
            // Verificar argumentos
            if (!args || args.length < 1) {
                return await replyWithContext(
                    `🍀 *A LA SUERTE*\n\n` +
                    `> Uso: ${config.prefix}suerte [cantidad]\n` +
                    `> Ejemplo: ${config.prefix}suerte 100\n\n` +
                    `> El número aleatorio determina si ganas:\n` +
                    `> • 0-40: ❌ Pierdes\n` +
                    `> • 41-70: ⚖️ Empatas (recuperas)\n` +
                    `> • 71-90: ✅ Ganas 1.5x\n` +
                    `> • 91-100: 🎉 Ganas 2x`,
                    [senderJid]
                );
            }
            
            let apuesta = parseInt(args[0]);
            
            // Validar apuesta
            if (isNaN(apuesta) || apuesta < 1) {
                return await replyWithContext(
                    '❌ La cantidad debe ser un número positivo',
                    [senderJid]
                );
            }
            
            let economy = loadEconomy();
            const user = initUserEconomy(economy, senderNumber, pushName);
            
            // Verificar si tiene suficientes coins
            if (user.coins < apuesta) {
                return await replyWithContext(
                    `❌ No tienes suficientes coins\n` +
                    `> Apostaste: *${apuesta}* coins\n` +
                    `> Tienes: *${user.coins}* coins`,
                    [senderJid]
                );
            }
            
            // Restar la apuesta
            user.coins -= apuesta;
            
            // Generar número de la suerte (0-100)
            const numero = Math.floor(Math.random() * 101);
            
            let resultado = '';
            let ganancia = 0;
            let multiplier = 0;
            let emoji = '';
            
            if (numero <= 40) {
                // Pierde (0-40)
                resultado = '❌ PERDISTE';
                ganancia = 0;
                multiplier = 0;
                emoji = '💔';
            } else if (numero <= 70) {
                // Empate (41-70)
                resultado = '⚖️ EMPATASTE';
                ganancia = apuesta; // Recupera lo apostado
                user.coins += ganancia;
                multiplier = 1;
                emoji = '🤝';
            } else if (numero <= 90) {
                // Gana 1.5x (71-90)
                resultado = '✅ GANASTE';
                ganancia = Math.floor(apuesta * 1.5);
                user.coins += ganancia;
                multiplier = 1.5;
                emoji = '💰';
            } else {
                // Gana 2x (91-100)
                resultado = '🎉 ¡SUPER GANANCIA!';
                ganancia = apuesta * 2;
                user.coins += ganancia;
                multiplier = 2;
                emoji = '🏆';
            }
            
            const coinsFinales = user.coins;
            
            let mensaje = `🍀 *A LA SUERTE*\n\n` +
                `🎲 *Número:* ${numero}\n\n` +
                `${emoji} *${resultado}*\n\n` +
                `💰 Apostaste: *${apuesta}* coins\n`;
            
            if (multiplier > 0) {
                if (multiplier === 1) {
                    mensaje += `💫 Recuperaste: *${apuesta}* coins\n`;
                } else {
                    mensaje += `🎁 Ganaste: *${ganancia - apuesta}* coins (${multiplier}x)\n`;
                }
            } else {
                mensaje += `💔 Perdiste: *${apuesta}* coins\n`;
            }
            
            mensaje += `💎 Total: *${coinsFinales}* coins`;
            
            saveEconomy(economy);
            await replyWithContext(mensaje, [senderJid]);
            
        } catch (error) {
            console.error('❌ Error en comando suerte:', error);
            await options.replyWithContext(
                `❌ Error: ${error.message}`,
                [options.senderJid]
            );
        }
    }
};