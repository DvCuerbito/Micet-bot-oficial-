import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const cleanNumber = (num) => num ? num.toString().replace(/[^0-9]/g, '') : '';
const PRIMARIOS_FILE = path.join(process.cwd(), 'databases', 'primarios.json');

function normalizeMexicanNumber(phone) {
    if (!phone) return phone;
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('52') && cleanPhone.length === 13 && cleanPhone[2] === '1') {
        return cleanPhone.substring(0, 2) + cleanPhone.substring(3);
    }
    return cleanPhone;
}

function compareMexicanNumbers(num1, num2) {
    if (!num1 || !num2) return false;
    return normalizeMexicanNumber(num1) === normalizeMexicanNumber(num2);
}

function extractNumberFromPhoneNumber(phoneNumber) {
    if (!phoneNumber) return null;
    const cleaned = phoneNumber.split('@')[0].split(':')[0];
    return cleanNumber(cleaned);
}

function getBotName(botNumber) {
    try {
        if (!botNumber) return null;
        const cleanNum = cleanNumber(botNumber);
        
        const infoDir = path.join(process.cwd(), 'info');
        if (fs.existsSync(infoDir)) {
            const folders = fs.readdirSync(infoDir, { withFileTypes: true })
                .filter(d => d.isDirectory())
                .map(folder => folder.name);
            
            for (const folder of folders) {
                const folderClean = cleanNumber(folder);
                if (compareMexicanNumbers(folderClean, cleanNum)) {
                    const configPath = path.join(infoDir, folder, 'config.js');
                    if (fs.existsSync(configPath)) {
                        const content = fs.readFileSync(configPath, 'utf8');
                        let match = content.match(/name:\s*['"]([^'"]+)['"]/);
                        if (match && match[1]) return match[1];
                        match = content.match(/"name"\s*:\s*["']([^"']+)["']/);
                        if (match && match[1]) return match[1];
                    }
                }
            }
        }
        return 'Bot';
    } catch (error) {}
    return null;
}

function getAllActiveBots() {
    const bots = {
        principal: null,
        mains: new Set(),
        subs: new Set()
    };
    
    try {
        const credsPath = path.join(process.cwd(), 'sessions', 'creds.json');
        if (fs.existsSync(credsPath)) {
            const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
            if (creds?.me?.id) {
                bots.principal = extractNumberFromPhoneNumber(creds.me.id);
                console.log(`[BOTS] Principal detectado: ${bots.principal}`);
            }
        }
    } catch (error) {
        console.error('[BOTS] Error leyendo creds.json:', error);
    }
    
    // Obtener Main bots desde global.mainBots (los que están conectados)
    if (global.mainBots && Array.isArray(global.mainBots)) {
        for (const bot of global.mainBots) {
            if (bot.userId) {
                const botNumber = extractNumberFromPhoneNumber(bot.userId);
                if (botNumber) {
                    bots.mains.add(botNumber);
                    console.log(`[BOTS] Main bot activo: ${botNumber}`);
                }
            }
        }
    }
    
    // También buscar en Sessions/Main por si hay sesiones guardadas pero no conectadas
    const mainsDir = path.join(process.cwd(), 'Sessions/Main');
    if (fs.existsSync(mainsDir)) {
        const mainFolders = fs.readdirSync(mainsDir, { withFileTypes: true })
            .filter(d => d.isDirectory())
            .map(folder => folder.name);
        
        for (const mainNumber of mainFolders) {
            const cleanMain = cleanNumber(mainNumber);
            bots.mains.add(cleanMain);
            console.log(`[BOTS] Main bot sesión: ${cleanMain}`);
        }
    }
    
    // Obtener Sub bots desde global.conns (los que están conectados)
    if (global.conns && Array.isArray(global.conns)) {
        for (const bot of global.conns) {
            if (bot.userId) {
                const botNumber = extractNumberFromPhoneNumber(bot.userId);
                if (botNumber) {
                    bots.subs.add(botNumber);
                    console.log(`[BOTS] Sub bot activo: ${botNumber}`);
                }
            }
        }
    }
    
    // También buscar en Sessions/Subs
    const subsDir = path.join(process.cwd(), 'Sessions/Subs');
    if (fs.existsSync(subsDir)) {
        const subFolders = fs.readdirSync(subsDir, { withFileTypes: true })
            .filter(d => d.isDirectory())
            .map(folder => folder.name);
        
        for (const subNumber of subFolders) {
            const cleanSub = cleanNumber(subNumber);
            bots.subs.add(cleanSub);
            console.log(`[BOTS] Sub bot sesión: ${cleanSub}`);
        }
    }
    
    return bots;
}

export default {
    name: 'setprimary',
    alias: ['setprimario'],

    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, senderJid, args, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;

            if (!from.endsWith('@g.us')) {
                return replyWithContext(`🌸 Este comando solo funciona en grupos.`);
            }

            const groupMetadata = await sock.groupMetadata(from);
            const participant = groupMetadata.participants.find(p => p.id === senderJid);
            const isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
            const isOwner = config.owner?.some(num => cleanNumber(num) === cleanNumber(senderNumber));

            if (!isAdmin && !isOwner) {
                return replyWithContext(`🏮 Solo administradores pueden usar este comando.`);
            }

            const activeBots = getAllActiveBots();
            const allBotNumbers = new Set();
            
            if (activeBots.principal) allBotNumbers.add(activeBots.principal);
            activeBots.mains.forEach(num => allBotNumbers.add(num));
            activeBots.subs.forEach(num => allBotNumbers.add(num));
            
            console.log(`[SETPRIMARY] Todos los bots activos:`, [...allBotNumbers]);

            const botsInGroup = [];
            const currentBotNumber = extractNumberFromPhoneNumber(sock.user?.id || '') || sock.phoneNumber || '';
            
            for (const participant of groupMetadata.participants) {
                const participantNumber = extractNumberFromPhoneNumber(participant.id);
                if (participantNumber && allBotNumbers.has(participantNumber)) {
                    let botType = '';
                    let botName = getBotName(participantNumber);
                    
                    if (activeBots.principal && compareMexicanNumbers(participantNumber, activeBots.principal)) {
                        botType = 'PRINCIPAL';
                        botName = botName || config.name || 'Principal';
                    } else if (Array.from(activeBots.mains).some(main => compareMexicanNumbers(participantNumber, main))) {
                        botType = 'MAIN';
                        botName = botName || 'Main Bot';
                    } else if (Array.from(activeBots.subs).some(sub => compareMexicanNumbers(participantNumber, sub))) {
                        botType = 'SUB';
                        botName = botName || 'Sub Bot';
                    } else {
                        continue;
                    }
                    
                    botsInGroup.push({
                        number: participantNumber,
                        jid: participant.id,
                        name: botName,
                        type: botType,
                        isCurrent: compareMexicanNumbers(participantNumber, currentBotNumber)
                    });
                }
            }

            if (botsInGroup.length === 0) {
                return replyWithContext(`🌸 No hay bots disponibles en este grupo.`);
            }

            console.log(`[SETPRIMARY] Bots en el grupo:`, botsInGroup.map(b => `${b.number} (${b.type})`));

            let targetJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || 
                            msg.message?.extendedTextMessage?.contextInfo?.participant || 
                            (args[0] ? cleanNumber(args[0]) + '@s.whatsapp.net' : null);

            if (targetJid) {
                const targetNumber = cleanNumber(targetJid);
                const targetBot = botsInGroup.find(b => b.number === targetNumber);
                if (!targetBot) {
                    return replyWithContext(`🌸 El bot ${targetNumber} no está en este grupo.`);
                }
                return await this.setBot(sock, from, targetBot, senderNumber, pushName, config, msg);
            }

            const rows = botsInGroup.map(bot => ({
                title: `${bot.name} (${bot.number})`,
                description: bot.isCurrent ? `✅ Actual - ${bot.type}` : `🔄 Cambiar - ${bot.type}`,
                id: `${config.prefix}setprimary ${bot.number}`
            }));

            const sections = [{
                title: "🌈 BOTS EN ESTE GRUPO",
                rows: rows
            }];

            await sock.sendMessage(from, {
                text: "🏮 *Panel de Selección de Bot*\n\nSelecciona el bot que deseas establecer como primario para este grupo.",
                footer: config.name,
                interactiveButtons: [
                    {
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "Ver bots disponibles",
                            sections,
                        }),
                    },
                ],
            }, { quoted: msg });

        } catch (error) {
            console.error('❌ Error en setprimary:', error);
            await sock.sendMessage(msg.key.remoteJid, { text: `❌ Error: ${error.message}` }, { quoted: msg });
        }
    },

    async setBot(sock, from, targetBot, senderNumber, pushName, config, msg) {
        const primariosDB = fs.existsSync(PRIMARIOS_FILE) ? JSON.parse(fs.readFileSync(PRIMARIOS_FILE, 'utf8')) : {};
        
        primariosDB[from] = {
            botPhone: targetBot.number,
            botNombre: targetBot.name,
            botJid: targetBot.jid,
            botType: targetBot.type,
            setBy: senderNumber,
            setByPushName: pushName,
            setAt: new Date().toLocaleString('es-ES'),
            timestamp: Date.now()
        };

        fs.writeFileSync(PRIMARIOS_FILE, JSON.stringify(primariosDB, null, 2));

        const successMsg = `🏮 *Bot Primario Configurado*\n\n` +
                           `> 🍀 *Bot:* @${targetBot.number}\n` +
                           `> 🍀 *Tipo:* ${targetBot.type}\n` +
                           `> 🍀 *Admin:* ${pushName}\n\n` +
                           `*A partir de ahora, solo este bot responderá aquí.*`;

        await sock.sendMessage(from, { 
            text: successMsg, 
            mentions: [targetBot.jid],
            contextInfo: { 
                mentionedJid: [targetBot.jid],
                isForwarded: true, 
                forwardingScore: 9999999,
                forwardedNewsletterMessageInfo: { 
                    newsletterJid: config.canalId || '', 
                    serverMessageId: 0,
                    newsletterName: config.canalNombre || '' 
                } 
            } 
        }, { quoted: msg });
        
        console.log(`✅ Bot primario cambiado a ${targetBot.number} (${targetBot.type}) por ${pushName} en grupo ${from}`);
    }
};