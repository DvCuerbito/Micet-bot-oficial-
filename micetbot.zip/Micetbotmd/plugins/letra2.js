const letterMap = {
    'a': 'α', 'A': 'α',
    'b': 'b', 'B': 'b',
    'c': 'c', 'C': 'c',
    'd': 'd', 'D': 'd',
    'e': 'ᧉ', 'E': 'ᧉ',
    'f': '𝖿', 'F': '𝖿',
    'g': 'g', 'G': 'g',
    'h': 'һ', 'H': 'һ',
    'i': 'ꪱ', 'I': 'ꪱ',
    'j': 'ȷ', 'J': 'ȷ',
    'k': 'k', 'K': 'k',
    'l': '𝗅', 'L': '𝗅',
    'm': '𝗆', 'M': '𝗆',
    'n': '𝗇', 'N': '𝗇',
    'ñ': 'ᥒ̃', 'Ñ': 'ᥒ̃',
    'o': 'ᦅ', 'O': 'ᦅ',
    'p': '𝗉', 'P': '𝗉',
    'q': '𝗊', 'Q': '𝗊',
    'r': 'ꭇ', 'R': 'ꭇ',
    's': '𝗌', 'S': '𝗌',
    't': 'ƚ', 'T': 'ƚ',
    'u': '𝗎', 'U': '𝗎',
    'v': '᥎', 'V': '᥎',
    'w': 'w', 'W': 'w',
    'x': 'x', 'X': 'x',
    'y': 'ᥡ', 'Y': 'ᥡ',
    'z': 'z', 'Z': 'z',
    '0': '𝟢', '1': '𝟣', '2': '𝟤', '3': '𝟥', '4': '𝟦',
    '5': '𝟧', '6': '𝟨', '7': '𝟩', '8': '𝟪', '9': '𝟫',
    ' ': ' ', '.': '.', ',': ',', '!': '!', '?': '?',
    '-': '-', '_': '_', '@': '@', '#': '#', '$': '$',
    '%': '%', '&': '&', '*': '*', '(': '(', ')': ')',
    '[': '[', ']': ']', '{': '{', '}': '}', ';': ';',
    ':': ':', '"': '"', "'": "'", '\\': '\\', '/': '/',
    '|': '|', '°': '°', '¡': '¡', '¿': '¿'
};

function convertToSpecialLetters(text) {
    let result = '';
    for (let i = 0; i < text.length; i++) {
        const char = text[i];
        result += letterMap[char] || char;
    }
    return result;
}

export default {
    name: 'letra2',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const text = args.join(' ');
            
            if (!text) {
                await replyWithContext(
                    `🌵 Debes proporcionar un texto\n> ${config.prefix}letra2 <texto>`,
                    []
                );
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '✨', key: msg.key } });
            } catch (e) {}
            
            const convertedText = convertToSpecialLetters(text);
            
            const message = `*${convertedText}*`;
            
            await replyWithContext(message, []);
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Letra2 usado por ${pushName || 'Usuario'}: ${text.substring(0, 30)}...`);
            
        } catch (error) {
            console.error('❌ Error en letra2:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(
                `❌ *Error:* ${error.message}`,
                []
            );
        }
    }
};