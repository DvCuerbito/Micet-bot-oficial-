import axios from 'axios';
import { downloadMediaMessage } from '@whiskeysockets/baileys';
import FormData from 'form-data';

// --- FUNCIONES DE SUBIDA (Para obtener la URL de la imagen) ---

function generateUniqueFilename(mime) {
    const ext = mime.split('/')[1] || 'bin';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let id = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    return `${id}.${ext}`;
}

async function uploadUguu(buffer) {
    const form = new FormData();
    form.append('files[]', buffer, generateUniqueFilename('image/jpeg'));
    const res = await axios.post('https://uguu.se/upload.php', form, { headers: form.getHeaders() });
    return res.data?.files?.[0]?.url;
}

async function uploadCatbox(buffer, mime) {
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, { filename: generateUniqueFilename(mime) });
    const res = await axios.post('https://catbox.moe/user/api.php', form, { headers: form.getHeaders() });
    return res.data;
}

async function uploadAuto(buffer, mime) {
    try {
        // Intentamos primero con Uguu ya que Catbox suele dar error 412
        return await uploadUguu(buffer);
    } catch {
        try {
            return await uploadCatbox(buffer, mime);
        } catch (e) {
            throw new Error('No se pudo subir la imagen a ningún servidor');
        }
    }
}

// --- COMANDO PRINCIPAL ---

export default {
    name: 'phpost',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderJid, pushName, replyWithContext, args } = options;
            const from = msg.key.remoteJid;
            
            // 1. Validar que responda a una imagen
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            const quotedMessage = quotedMsg?.quotedMessage;
            
            if (!quotedMessage || !quotedMessage.imageMessage) {
                await replyWithContext(`🌵 Debes responder a una imagen`, []);
                return;
            }

            // 2. Definir el título (si no hay texto, poner uno por defecto)
            const title = args.length > 0 ? args.join(' ') : 'Ñam';
            
            await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

            // 3. Descargar la imagen
            const imageMsg = quotedMessage.imageMessage;
            const mime = imageMsg.mimetype || 'image/jpeg';
            
            const quotedMsgObj = {
                key: { remoteJid: from, id: quotedMsg.stanzaId, participant: quotedMsg.participant || from, fromMe: false },
                message: { imageMessage: imageMsg }
            };
            
            const imageBuffer = await downloadMediaMessage(quotedMsgObj, 'buffer', {}, { logger: console, reuploadRequest: sock.updateMediaMessage });

            // 4. Subir la imagen para obtener el enlace (parámetro &image=)
            const imageUrl = await uploadAuto(imageBuffer, mime);
            
            // 5. Llamada a la API con el título dinámico
            const canvasApi = `https://api.siputzx.my.id/api/canvas/xnxx?title=${encodeURIComponent(title)}&image=${encodeURIComponent(imageUrl)}`;
            
            const response = await axios.get(canvasApi, {
                responseType: 'arraybuffer',
                timeout: 60000
            });
            
            // 6. Enviar resultado
            await sock.sendMessage(from, {
                image: Buffer.from(response.data),
                caption: `*Post generado exitosamente*`,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        newsletterName: 'Meme Maker'
                    }
                }
            }, { quoted: msg });

            await sock.sendMessage(from, { react: { text: '✨', key: msg.key } });
            
        } catch (error) {
            console.error('❌ Error:', error);
            await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
        }
    }
};
