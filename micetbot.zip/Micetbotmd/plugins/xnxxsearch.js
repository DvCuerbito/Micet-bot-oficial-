import axios from "axios";

export default {
    name: 'xnxxsearch',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, args } = options;
            const from = msg.key.remoteJid;
            
            if (!args || args.length === 0) {
                return await sock.sendMessage(from, { text: "[ ★ ] Debes proporcionar una búsqueda" }, { quoted: msg });
            }

            const query = args.join(" ");
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}

            // Consulta a la API
            const apiUrl = `https://api.delirius.store/search/xnxxsearch?query=${encodeURIComponent(query)}`;
            const response = await axios.get(apiUrl, { timeout: 30000 });
            const res = response.data;

            if (!res.status || !res.data || res.data.length === 0) {
                return await sock.sendMessage(from, { text: "🔞 No se encontraron resultados." }, { quoted: msg });
            }

            // Seleccionar 10 resultados aleatorios
            const allResults = res.data;
            const shuffled = allResults.sort(() => 0.5 - Math.random());
            const random10 = shuffled.slice(0, 10);
            
            // Imagen de fondo para las cards (Uguu)
            const cardImageUrl = "https://h.uguu.se/dGjcCSke.jpeg";
            let cardImageBuffer = null;

            try {
                const imgRes = await axios.get(cardImageUrl, { responseType: 'arraybuffer' });
                cardImageBuffer = Buffer.from(imgRes.data);
            } catch (e) {
                console.log("Error cargando imagen de card");
            }

            // Crear las cards con la información exacta de la API
            const cards = [];
            
            for (let i = 0; i < random10.length; i++) {
                const v = random10[i];
                
                cards.push({
                    image: cardImageBuffer,
                    title: `🔞 Resultado ${i + 1}`,
                    body: `❱❱ *Título* » ${v.title}\n` +
                          `❱❱ *Vistas* » ${v.views}\n` +
                          `❱❱ *Porcentaje* » ${v.percentage}\n` +
                          `❱❱ *Duración* » ${v.duration}\n` +
                          `❱❱ *Calidad* » ${v.quality}\n` +
                          `❱❱ *Link* » ${v.link}`,
                    footer: `⭐ Moonlight Staff ⭐`
                });
            }

            // Enviar mensaje con las cards
            await sock.sendMessage(from, {
                text: `🔞 *XNXX SEARCH*`,
                title: 'XNXX Search',
                subtitle: `Resultados para: ${query}`,
                footer: '⭐ Moonlight Staff ⭐',
                cards: cards,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}

        } catch (error) {
            console.error("❌ Error en xnxxsearch:", error);
            await sock.sendMessage(msg.key.remoteJid, { text: "🔞 Error: " + error.message }, { quoted: msg });
        }
    }
};