import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ID del grupo donde se enviarán los reportes
const REPORT_GROUP_ID = "120363406310003071@g.us";

export default {
    name: 'reportuser',
    alias: ['reportarusuario'],
    
    async execute(sock, msg, options) {
        try {
            const { config, sender, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // Verificar si se proporcionó razón
            const texto = args.join(' ').trim();
            
            if (!texto) {
                await sock.sendMessage(from, {
                    text: `🦋 Debes proporcionar una razón para el reporte\n> Ejemplo: ${config.prefix}reportuser Spam`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Determinar el usuario reportado
            const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
            const quotedMessage = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            
            let reportedUser;
            let reportedPushName = "Usuario desconocido";
            
            if (mentionedJid) {
                reportedUser = mentionedJid;
                // Intentar obtener el pushName de la mención (difícil, generalmente no viene)
            } else if (quotedParticipant) {
                reportedUser = quotedParticipant;
                // Intentar obtener el pushName del mensaje citado
                if (quotedMessage) {
                    // El pushName no viene en el mensaje citado directamente
                    // Podemos intentar obtenerlo del mensaje original si está disponible
                }
            } else {
                await sock.sendMessage(from, {
                    text: `🦋 Debes responder o mencionar al usuario que quieres reportar`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Obtener información del grupo de origen
            let groupName = "Chat privado";
            let groupId = from;
            
            if (from.endsWith('@g.us')) {
                try {
                    const groupMetadata = await sock.groupMetadata(from);
                    groupName = groupMetadata.subject || "Grupo sin nombre";
                    groupId = from;
                    
                    // Verificar si el usuario reportado está en el grupo
                    const userExists = groupMetadata.participants.some(p => p.id === reportedUser);
                    if (!userExists) {
                        await sock.sendMessage(from, {
                            text: `🦋 El usuario no está en este grupo`,
                            contextInfo: {
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                        return;
                    }
                    
                    // Intentar obtener el pushName del usuario reportado desde los participantes
                    const reportedParticipant = groupMetadata.participants.find(p => p.id === reportedUser);
                    if (reportedParticipant) {
                        // El pushName no viene en groupMetadata.participants
                        // Solo viene el ID y si es admin o no
                    }
                } catch (error) {
                    console.error('Error obteniendo metadata del grupo:', error);
                    groupName = "Grupo desconocido";
                }
            }
            
            // Intentar obtener pushName del mensaje original (si es una respuesta)
            if (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
                const quotedMsg = msg.message.extendedTextMessage.contextInfo.quotedMessage;
                // A veces el pushName viene en el mensaje original
                if (msg.message.extendedTextMessage.contextInfo.participant) {
                    // No hay pushName aquí
                }
            }
            
            // Obtener el número de teléfono LIMPIO (solo dígitos)
            const reportedNumber = reportedUser.split('@')[0].split(':')[0].replace(/\D/g, '');
            const reporterNumber = sender.split('@')[0].split(':')[0].replace(/\D/g, '');
            
            // Intentar obtener el pushName del mensaje original (si está disponible)
            // A veces el pushName viene en el mensaje cuando se menciona
            if (mentionedJid && msg.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
                // No podemos obtener pushName de aquí
            }
            
            // Buscar el bot principal para enviar el reporte
            if (global.principalBot && global.principalBot.user) {
                await sendReport(global.principalBot, config, reportedUser, reportedPushName, reportedNumber, texto, pushName || reporterNumber, reporterNumber, groupName, groupId);
            } else {
                console.log('[REPORTUSER] No se encontró bot principal, enviando desde el actual');
                await sendReport(sock, config, reportedUser, reportedPushName, reportedNumber, texto, pushName || reporterNumber, reporterNumber, groupName, groupId);
            }
            
            // Responder al usuario confirmando (SIEMPRE desde el bot actual)
            await sock.sendMessage(from, {
                text: `🦋 Se ha reportado a @${reportedUser.split('@')[0]} a mis moderadores`,
                mentions: [reportedUser],
                contextInfo: {
                    mentionedJid: [reportedUser],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
        } catch (error) {
            console.error('Error en reportuser:', error);
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ Error al enviar reporte: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};

// Función para enviar el reporte
async function sendReport(botSocket, config, reportedUser, reportedPushName, reportedNumber, razon, reporterName, reporterNumber, groupName, groupId) {
    try {
        // Construir el mensaje de reporte
        const reportText = 
`ᨙᨐ͜᷍ᨏㅤreportuser ⪨꯭⪨

🌠 Usuario » *${reportedPushName || 'Usuario desconocido'}*
🌠 Id » *${reportedUser}*
🌠 Tag » @${reportedUser.split('@')[0]}
🌠 Number » *${reportedNumber}*
🌠 Razón » *${razon}*
🌠 Reportado por » *${reporterName || reporterNumber}*`;

        // Buscar el banner
        const bannerPath = path.join(process.cwd(), 'img', 'banner.jpg');
        let bannerBuffer = null;
        
        try {
            if (fs.existsSync(bannerPath)) {
                bannerBuffer = fs.readFileSync(bannerPath);
                console.log('✅ Banner cargado para reportuser');
            }
        } catch (error) {
            console.log('⚠️ No se pudo cargar el banner:', error.message);
        }

        // Preparar el mensaje
        const messageData = {
            text: reportText,
            mentions: [reportedUser],
            contextInfo: {
                mentionedJid: [reportedUser],
                forwardingScore: 9999999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.canalId || '',
                    serverMessageId: 0,
                    newsletterName: config.canalNombre || ''
                }
            }
        };

        // Añadir banner si existe
        if (bannerBuffer) {
            messageData.contextInfo.externalAdReply = {
                title: `🌠 NUEVO REPORTE DE USUARIO 🌠`,
                body: `De: ${reporterName || reporterNumber}`,
                thumbnail: bannerBuffer,
                mediaType: 1,
                showAdAttribution: false,
                renderLargerThumbnail: true
            };
        }

        // Enviar al grupo de reportes
        await botSocket.sendMessage(REPORT_GROUP_ID, messageData);
        
        console.log(`📝 Reporte de usuario enviado al grupo ${REPORT_GROUP_ID} desde ${reporterName || reporterNumber}`);
        
    } catch (error) {
        console.error('Error enviando reporte al grupo:', error);
        throw error;
    }
};
