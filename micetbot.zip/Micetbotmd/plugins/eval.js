import syntaxerror from 'syntax-error';
import { format } from 'util';
import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const require = createRequire(__dirname);

export default {
    name: 'eval',
    alias: ['e', 'ev'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            const jid = from; // ✅ Añadido
            
            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar si el usuario es el owner
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isOwner) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}eval\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar si se proporcionó código
            if (!args || args.length === 0) {
                await sock.sendMessage(from, {
                    text: `🌺 *Uso:* ${config.prefix}eval <codigo>\n\n> Ejemplo: ${config.prefix}eval console.log("Hola mundo")`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);
            
            let code = args.join(' ').trim();
            
            // Agregar return automáticamente si es expresión simple
            if (!code.includes('return') && !code.includes(';') && !code.includes('\n')) {
                code = 'return ' + code;
            }
            
            let result;
            let syntax = '';
            
            try {
                // Definir AsyncFunction para permitir await
                const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
                
                // Definir qsender (remitente del mensaje citado)
                const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
                const qsender = quotedMsg?.participant || senderJid;
                
                // Crear objeto m para que funcione m.chat
                const m = {
                    chat: from,
                    sender: senderJid,
                    from: from,
                    msg: msg,
                    pushName: pushName,
                    isGroup: from.includes('@g.us')
                };
                
                // Determinar si es el bot mismo
                const forMe = msg.key?.fromMe || false;
                
                // Crear función con los parámetros disponibles
                const fn = new AsyncFunction(
                    'sock', 'msg', 'options', 'args', 'config', 'usersDB', 'sender', 'pushName', 'from', 'qsender', 'require', 'format', 'syntaxerror', 'm', 'forMe', 'jid',
                    `try {
                        ${code}
                    } catch(e) {
                        throw e;
                    }`
                );
                
                // Ejecutar con todos los parámetros
                result = await fn(
                    sock, msg, options, args, config, usersDB, senderNumber, pushName, from, qsender, require, format, syntaxerror, m, forMe, jid
                );
                
            } catch (err) {
                // Verificar error de sintaxis
                const syn = syntaxerror(code, 'Eval', {
                    allowReturnOutsideFunction: true,
                    allowAwaitOutsideFunction: true
                });
                
                if (syn) {
                    syntax = '```' + syn + '```\n\n';
                }
                
                result = err;
            }
            
            // Formatear resultado
            let output = '';
            if (result !== undefined && result !== null) {
                if (typeof result === 'object' || typeof result === 'function') {
                    try {
                        output = format(result, { depth: 2 });
                    } catch (e) {
                        output = String(result);
                    }
                } else {
                    output = String(result);
                }
            } else {
                output = 'Ejecutado sin retorno';
            }
            
            // Limitar longitud del resultado
            if (output.length > 4000) {
                output = output.substring(0, 4000) + '\n\n... (resultado truncado)';
            }
            
            // Enviar resultado
            await sock.sendMessage(from, {
                text: syntax + '```\n' + output + '\n```',
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            console.log(`✅ Eval ejecutado por OWNER: ${pushName || senderNumber}`);
            console.log(`📝 Código: ${code.substring(0, 100)}${code.length > 100 ? '...' : ''}`);
            
        } catch (error) {
            console.error('❌ Error en eval:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ *Error:*\n\`\`\`${error.message}\`\`\``,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
};