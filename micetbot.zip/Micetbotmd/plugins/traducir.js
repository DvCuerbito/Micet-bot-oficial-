import fetch from 'node-fetch';

// Diccionario de idiomas comunes
const languageMap = {
    // Español a otros
    'español': 'es',
    'es': 'es',
    'spain': 'es',
    'spanish': 'es',
    
    // Inglés
    'ingles': 'en',
    'inglés': 'en',
    'en': 'en',
    'english': 'en',
    
    // Portugués
    'portugues': 'pt',
    'portugués': 'pt',
    'pt': 'pt',
    'portuguese': 'pt',
    
    // Francés
    'frances': 'fr',
    'francés': 'fr',
    'fr': 'fr',
    'french': 'fr',
    
    // Alemán
    'aleman': 'de',
    'alemán': 'de',
    'de': 'de',
    'german': 'de',
    
    // Italiano
    'italiano': 'it',
    'it': 'it',
    'italian': 'it',
    
    // Japonés
    'japones': 'ja',
    'japonés': 'ja',
    'ja': 'ja',
    'japanese': 'ja',
    
    // Coreano
    'coreano': 'ko',
    'ko': 'ko',
    'korean': 'ko',
    
    // Chino
    'chino': 'zh',
    'zh': 'zh',
    'chinese': 'zh',
    
    // Ruso
    'ruso': 'ru',
    'ru': 'ru',
    'russian': 'ru',
    
    // Árabe
    'arabe': 'ar',
    'árabe': 'ar',
    'ar': 'ar',
    'arabic': 'ar',
    
    // Holandés
    'holandes': 'nl',
    'holandés': 'nl',
    'nl': 'nl',
    'dutch': 'nl',
    
    // Griego
    'griego': 'el',
    'el': 'el',
    'greek': 'el',
    
    // Hindi
    'hindi': 'hi',
    'hi': 'hi',
    
    // Turco
    'turco': 'tr',
    'tr': 'tr',
    'turkish': 'tr',
    
    // Polaco
    'polaco': 'pl',
    'pl': 'pl',
    'polish': 'pl',
    
    // Sueco
    'sueco': 'sv',
    'sv': 'sv',
    'swedish': 'sv',
    
    // Danés
    'danes': 'da',
    'danés': 'da',
    'da': 'da',
    'danish': 'da',
    
    // Finés
    'fines': 'fi',
    'finés': 'fi',
    'fi': 'fi',
    'finnish': 'fi'
};

// Función para obtener el código de idioma
function getLanguageCode(lang) {
    const lowerLang = lang.toLowerCase().trim();
    return languageMap[lowerLang] || lowerLang; // Si no está en el mapa, devolver el texto original
}

// Función para traducir usando Google Translate API (gratuita)
async function translateText(text, targetLang) {
    try {
        // Usar la API gratuita de Google Translate
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(text)}`;
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data && data[0] && data[0][0] && data[0][0][0]) {
            return {
                translatedText: data[0][0][0],
                detectedLang: data[2] || 'auto'
            };
        } else {
            throw new Error('No se pudo traducir el texto');
        }
    } catch (error) {
        console.error('Error en traducción:', error);
        throw error;
    }
}

export default {
    name: 'traducir',
    alias: ['translate', 'traductor', 'tl'],
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, senderNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            console.log(`🌐 Comando traducir ejecutado por: ${senderNumber}`);

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            // Verificar argumentos
            if (args.length === 0) {
                return await sock.sendMessage(from, {
                    text: `⭐ Debes proporcionar texto a traducir\n\nEjemplo: ${config.prefix}traducir hola = ingles`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }

            // Unir todos los argumentos en un string
            const fullText = args.join(' ');
            
            // Buscar el separador "="
            const separatorIndex = fullText.indexOf('=');
            
            if (separatorIndex === -1) {
                return await sock.sendMessage(from, {
                    text: `⭐ Formato incorrecto. Debes usar: ${config.prefix}traducir texto = idioma\n\nEjemplo: ${config.prefix}traducir hola = ingles`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }

            // Extraer texto y idioma
            let textToTranslate = fullText.substring(0, separatorIndex).trim();
            let targetLanguage = fullText.substring(separatorIndex + 1).trim();

            if (!textToTranslate) {
                return await sock.sendMessage(from, {
                    text: `🌠 Debes proporcionar el texto a traducir`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }

            if (!targetLanguage) {
                return await sock.sendMessage(from, {
                    text: `🌠 Debes proporcionar el idioma de destino`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }

            // Obtener código de idioma
            const langCode = getLanguageCode(targetLanguage);
            
            console.log(`📝 Texto original: "${textToTranslate}"`);
            console.log(`🌍 Idioma destino: ${targetLanguage} (${langCode})`);

            // Enviar mensaje de procesamiento
            await sock.sendMessage(from, {
                text: `🥕 Traduciendo...`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            // Realizar la traducción
            const result = await translateText(textToTranslate, langCode);

            // Formatear el idioma detectado para mostrarlo
            const detectedLangName = Object.keys(languageMap).find(
                key => languageMap[key] === result.detectedLang
            ) || result.detectedLang;

            // Mensaje de respuesta
            const responseMessage = `⭐ Traducción » *${result.translatedText}*\n⭐ Texto original » *${textToTranslate}*\n⭐ Idioma » *${targetLanguage}*`;

            await sock.sendMessage(from, {
                text: responseMessage,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            console.log(`✅ Traducción completada: "${textToTranslate}" -> "${result.translatedText}"`);

        } catch (error) {
            console.error('❌ Error en traducir:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `⭐ Error al traducir: ${error.message}\n\n> Verifica que el idioma sea válido o intenta con otro texto`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};
