import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';
import fetch from 'node-fetch';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const execAsync = promisify(exec);

export default {
    name: 'play',
    alias: ['ytaudio', 'playaudio'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            const query = args.join(' ').trim();
            
            if (!query) {
                return await sock.sendMessage(from, {
                    text: `🌽 Debes proporcionar el nombre o link de una canción`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            await sock.sendPresenceUpdate('composing', from);
            
            try {
                await sock.sendMessage(from, { react: { text: '🎵', key: msg.key } });
            } catch (e) {}
            
            const tempDir = path.join(__dirname, '..', 'temp');
            if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
            
            const outputPath = path.join(tempDir, `audio_${Date.now()}.mp3`);
            
            let videoInfo = null;
            let audioBuffer = null;
            let usedMethod = '';
            
            // ============ MÉTODO 1: yt-dlp ============
            try {
                const cookiesPath = path.join(process.cwd(), 'cookies.txt');
                let cookiesOption = '';
                
                if (fs.existsSync(cookiesPath)) {
                    cookiesOption = `--cookies "${cookiesPath}"`;
                    console.log('✅ Usando archivo de cookies');
                }
                
                const ytDlpPath = path.join(process.cwd(), 'yt-dlp');
                const jsRuntime = '--js-runtimes node';
                
                let infoCommand;
                if (query.includes('youtu.be') || query.includes('youtube.com')) {
                    infoCommand = `"${ytDlpPath}" ${jsRuntime} ${cookiesOption} -j "${query}"`;
                } else {
                    infoCommand = `"${ytDlpPath}" ${jsRuntime} ${cookiesOption} -j "ytsearch1:${query}"`;
                }
                
                console.log(`📥 [MÉTODO 1] Obteniendo información`);
                
                const { stdout: infoStdout } = await execAsync(infoCommand, { timeout: 30000, cwd: process.cwd() });
                videoInfo = JSON.parse(infoStdout);
                
                let downloadCommand;
                if (query.includes('youtu.be') || query.includes('youtube.com')) {
                    downloadCommand = `"${ytDlpPath}" ${jsRuntime} -x --audio-format mp3 --audio-quality 0 ${cookiesOption} -o "${outputPath}" "${query}"`;
                } else {
                    downloadCommand = `"${ytDlpPath}" ${jsRuntime} -x --audio-format mp3 --audio-quality 0 ${cookiesOption} -o "${outputPath}" "ytsearch1:${query}"`;
                }
                
                console.log(`📥 [MÉTODO 1] Descargando audio`);
                
                await execAsync(downloadCommand, { timeout: 120000, cwd: process.cwd() });
                
                if (fs.existsSync(outputPath)) {
                    audioBuffer = fs.readFileSync(outputPath);
                    usedMethod = 'yt-dlp';
                    console.log('✅ [MÉTODO 1] Audio descargado con yt-dlp');
                }
            } catch (error1) {
                console.log('⚠️ [MÉTODO 1] Falló yt-dlp, intentando con API:', error1.message);
            }
            
            // ============ MÉTODO 2: API NeoApis ============
            if (!audioBuffer) {
                try {
                    let videoUrl;
                    
                    // Si es una URL directa, usarla
                    if (query.includes('youtu.be') || query.includes('youtube.com')) {
                        videoUrl = query;
                    } else {
                        // Buscar en YouTube usando yt-search
                        console.log(`🔍 [MÉTODO 2] Buscando en YouTube: ${query}`);
                        const searchResponse = await fetch(`https://www.neoapis.xyz/api/search/yt-search?q=${encodeURIComponent(query)}`);
                        const searchData = await searchResponse.json();
                        
                        if (!searchData.status || !searchData.data || searchData.data.length === 0) {
                            throw new Error('No se encontraron resultados en YouTube');
                        }
                        
                        videoUrl = searchData.data[0].url;
                        console.log(`✅ [MÉTODO 2] Video encontrado: ${searchData.data[0].title}`);
                        
                        // Guardar info del video desde la búsqueda
                        videoInfo = {
                            title: searchData.data[0].title || query,
                            channel: searchData.data[0].channel || 'YouTube',
                            webpage_url: videoUrl,
                            original_url: videoUrl,
                            thumbnail: searchData.data[0].thumbnail || ''
                        };
                    }
                    
                    // Llamar a la API de descarga
                    console.log(`📥 [MÉTODO 2] Descargando con API: ${videoUrl}`);
                    const apiResponse = await fetch(`https://www.neoapis.xyz/api/downloader/ytdl?url=${encodeURIComponent(videoUrl)}&type=mp3`);
                    const apiData = await apiResponse.json();
                    
                    if (!apiData.status || !apiData.data) {
                        throw new Error('Error en la API');
                    }
                    
                    // Si no teníamos info del video, usar la de la API
                    if (!videoInfo) {
                        videoInfo = {
                            title: apiData.data.title || query,
                            channel: 'YouTube',
                            webpage_url: videoUrl,
                            original_url: videoUrl,
                            thumbnail: ''
                        };
                    }
                    
                    // Descargar el audio desde la URL
                    const downloadUrl = apiData.data.download;
                    console.log(`📥 [MÉTODO 2] Descargando desde: ${downloadUrl}`);
                    
                    const audioResponse = await axios.get(downloadUrl, {
                        responseType: 'arraybuffer',
                        timeout: 120000
                    });
                    
                    audioBuffer = Buffer.from(audioResponse.data);
                    fs.writeFileSync(outputPath, audioBuffer);
                    
                    usedMethod = 'API NeoApis';
                    console.log('✅ [MÉTODO 2] Audio descargado con API');
                    
                } catch (error2) {
                    console.log('❌ [MÉTODO 2] Falló API:', error2.message);
                    throw new Error('No se pudo descargar el audio con ningún método disponible');
                }
            }
            
            if (!audioBuffer || !videoInfo) {
                throw new Error('No se pudo obtener el audio');
            }
            
            // ============ ENVIAR ============
            const videoTitle = videoInfo.title || 'Sin título';
            const videoChannel = videoInfo.channel || videoInfo.uploader || 'Canal desconocido';
            const videoUrl = videoInfo.webpage_url || videoInfo.original_url || query;
            const videoThumbnail = videoInfo.thumbnail || '';
            const audioQuality = 'MP3 128kbps';
            const stats = fs.statSync(outputPath);
            const sizeMB = (stats.size / 1024 / 1024).toFixed(2);
            
            // Descargar miniatura
            let thumbnailBuffer = null;
            if (videoThumbnail) {
                try {
                    const thumbResponse = await axios.get(videoThumbnail, {
                        responseType: 'arraybuffer',
                        timeout: 10000
                    });
                    thumbnailBuffer = Buffer.from(thumbResponse.data);
                } catch (e) {
                    console.log('Error descargando miniatura:', e.message);
                }
            }
            
            // Mensaje con información del video
            const caption = `あ🏮 *Título* » ${videoTitle}\n` +
                          `あ🏮 *Canal* » ${videoChannel}\n` +
                          `あ🏮 *Calidad* » ${audioQuality}\n` +
                          `あ🏮 *Tamaño* » ${sizeMB} MB\n` +
                          `あ🏮 *Link* » ${videoUrl}`;
            
            // Enviar imagen con información
            if (thumbnailBuffer) {
                await sock.sendMessage(from, {
                    image: thumbnailBuffer,
                    caption: caption,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, {
                    text: caption,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            // Enviar el audio
            await sock.sendMessage(from, {
                audio: audioBuffer,
                mimetype: 'audio/mpeg',
                fileName: `${videoTitle.substring(0, 50)}.mp3`,
                ptt: false,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            // Limpiar archivos temporales
            setTimeout(() => {
                try { if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch (e) {}
            }, 10000);
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Audio enviado por ${pushName || 'Usuario'}: ${videoTitle} [${usedMethod}]`);
            
        } catch (error) {
            console.error('❌ Error en play:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            let errorMsg = error.message;
            if (errorMsg.includes('JavaScript runtime')) {
                errorMsg = 'Node.js no está instalado. Ejecuta: apt install nodejs -y';
            } else if (errorMsg.includes('Sign in to confirm')) {
                errorMsg = 'YouTube bloqueó la solicitud';
            }
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ *Error:* ${errorMsg}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};