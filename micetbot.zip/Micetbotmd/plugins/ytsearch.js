
import axios from 'axios';
import yts from 'yt-search';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `play_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

async function descargarYEnviar(sock, downloadUrl, title, formato, config, senderJid, pushName, userNumber, quotedMsg) {
    const audioResponse = await axios.get(downloadUrl, {
        responseType: 'arraybuffer',
        timeout: 120000,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    });
    
    const audioBuffer = Buffer.from(audioResponse.data);
    const cleanTitle = title.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);
    
    if (formato === 'audio') {
        await sock.sendMessage(msg.key.remoteJid, {
            audio: audioBuffer,
            mimetype: 'audio/mpeg',
            fileName: `${cleanTitle}.mp3`,
            ptt: false,
            contextInfo: {
                mentionedJid: senderJid ? [senderJid] : [],
                forwardingScore: 9999999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.canalId || '',
                    serverMessageId: 0,
                    newsletterName: config.canalNombre || ''
                }
            }
        }, { quoted: quotedMsg });
    } else {
        await sock.sendMessage(msg.key.remoteJid, {
            document: audioBuffer,
            mimetype: 'audio/mpeg',
            fileName: `${cleanTitle}.mp3`,
            caption: ``,
            contextInfo: {
                mentionedJid: senderJid ? [senderJid] : [],
                forwardingScore: 9999999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.canalId || '',
                    serverMessageId: 0,
                    newsletterName: config.canalNombre || ''
                }
            }
        }, { quoted: quotedMsg });
    }
    
    console.log(`✅ Música descargada por ${pushName || userNumber} como ${formato}`);
}

export default {
    name: 'play2',
    alias: ['music', 'song'],
    description: 'Busca y descarga música de YouTube',
    category: 'download',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, senderJid, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            if (!args || args.length === 0) {
                return await replyWithContext(`「✰」Debes proporcionar una búsqueda o un enlace de YouTube`);
            }
            
            // Detectar si es un comando de descarga directa (audio/documento)
            const firstArg = args[0].toLowerCase();
            let formato = null;
            let queryStart = 0;
            
            if (firstArg === 'audio' || firstArg === 'documento') {
                formato = firstArg;
                queryStart = 1;
            }
            
            const query = args.slice(queryStart).join(' ').trim();
            
            if (!query) {
                return await replyWithContext(`🎵 *Uso correcto:*\n> ${config.prefix}play +canción\n> ${config.prefix}play +https://youtu.be/...`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🎵', key: msg.key } });
            } catch (e) {}
            
            let titleResult = '';
            let author = '';
            let imageUrl = '';
            let downloadUrl = '';
            let duration = '';
            
            // Detectar si es enlace de YouTube o búsqueda
            const isUrl = query.includes('youtube.com') || query.includes('youtu.be');
            
            if (isUrl) {
                // Usar API de Delirius para enlace directo
                const apiUrl = `https://api.delirius.store/download/youtube?url=${encodeURIComponent(query)}`;
                const response = await axios.get(apiUrl, { timeout: 30000 });
                
                if (!response.data?.status || !response.data?.data) {
                    throw new Error('No se pudo obtener la información');
                }
                
                const data = response.data.data;
                titleResult = data.title || 'Sin título';
                author = data.author || 'Desconocido';
                imageUrl = data.image || '';
                downloadUrl = data.download || '';
                duration = data.duration || '';
            } else {
                // Usar yt-search para búsqueda
                const searchResults = await yts(query);
                const videos = searchResults.videos || searchResults.all || [];
                
                if (!videos || videos.length === 0) {
                    throw new Error('No se encontraron resultados');
                }
                
                const firstVideo = videos[0];
                titleResult = firstVideo.title || 'Sin título';
                author = firstVideo.author?.name || 'Desconocido';
                imageUrl = firstVideo.thumbnail || '';
                duration = firstVideo.timestamp || '';
                
                // Obtener enlace de descarga de la API
                const videoUrl = firstVideo.url;
                const apiUrl = `https://api.delirius.store/download/youtube?url=${encodeURIComponent(videoUrl)}`;
                const response = await axios.get(apiUrl, { timeout: 30000 });
                
                if (response.data?.status && response.data?.data?.download) {
                    downloadUrl = response.data.data.download;
                } else {
                    throw new Error('No se pudo obtener el enlace de descarga');
                }
            }
            
            if (!downloadUrl) {
                throw new Error('No se pudo obtener el enlace de descarga');
            }
            
            // Si se especificó formato, descargar directamente
            if (formato) {
                await descargarYEnviar(sock, downloadUrl, titleResult, formato, config, senderJid, pushName, userNumber, msg);
                try {
                    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
                } catch (e) {}
                return;
            }
            
            // Si no se especificó formato, mostrar información y botones
            let imageBuffer = null;
            if (imageUrl) {
                try {
                    const imgResponse = await axios.get(imageUrl, { responseType: 'arraybuffer', timeout: 15000 });
                    imageBuffer = Buffer.from(imgResponse.data);
                } catch (e) {
                    console.log('Error descargando imagen:', e.message);
                }
            }
            
            const infoText = `🎵 *${titleResult}*\n\n` +
                          `👤 *Artista:* ${author}\n` +
                          `⏱️ *Duración:* ${duration || 'N/A'}\n\n` +
                          `📥 *Selecciona el formato de descarga:*`;
            
            if (imageBuffer) {
                await sock.sendMessage(from, {
                    image: imageBuffer,
                    caption: infoText,
                    footer: "🎵 Moonlight Music",
                    interactiveButtons: [
                        {
                            name: "quick_reply",
                            buttonParamsJson: JSON.stringify({
                                display_text: "🎵 Audio MP3",
                                id: `${config.prefix}play audio ${query}`
                            })
                        },
                        {
                            name: "quick_reply",
                            buttonParamsJson: JSON.stringify({
                                display_text: "📄 Documento MP3",
                                id: `${config.prefix}play documento ${query}`
                            })
                        }
                    ],
                    contextInfo: {
                        mentionedJid: senderJid ? [senderJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, {
                    text: infoText,
                    footer: "🎵 Moonlight Music",
                    interactiveButtons: [
                        {
                            name: "quick_reply",
                            buttonParamsJson: JSON.stringify({
                                display_text: "🎵 Audio MP3",
                                id: `${config.prefix}play audio ${query}`
                            })
                        },
                        {
                            name: "quick_reply",
                            buttonParamsJson: JSON.stringify({
                                display_text: "📄 Documento MP3",
                                id: `${config.prefix}play documento ${query}`
                            })
                        }
                    ],
                    contextInfo: {
                        mentionedJid: senderJid ? [senderJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            console.log(`🎵 Música encontrada: ${titleResult} por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en play:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:* ${error.message}`);
            } catch (e) {}
        }
    }
};