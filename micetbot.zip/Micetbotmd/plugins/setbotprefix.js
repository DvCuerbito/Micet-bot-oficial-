import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Prefijos permitidos
const ALLOWED_PREFIXES = ['.', '/', '-', '#', '!'];

export default {
    name: 'setbotprefix',
    alias: ['botprefix'],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, args, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            // ==========================================
            // OBTENER NÚMERO DEL BOT
            // ==========================================
            let botNumber = '';
            if (sock.phoneNumber) {
                botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            if (!botNumber) {
                throw new Error('No se pudo identificar el número del bot');
            }
            
            // ==========================================
            // VERIFICAR SI EL USUARIO ES EL BOTOWNER
            // ==========================================
            const isBotOwner = config.botowner && 
                              config.botowner.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '');
            
            if (!isBotOwner) {
                await sock.sendMessage(from, {
                    text: `❀ *Solo el dueño del bot puede cambiar su prefijo*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // ==========================================
            // SI HAY ARGUMENTO, CAMBIAR PREFIJO DIRECTAMENTE
            // ==========================================
            if (args && args.length > 0) {
                let newPrefix = args[0];
                
                // Eliminar el '+' si está presente al inicio
                if (newPrefix.startsWith('+')) {
                    newPrefix = newPrefix.substring(1).trim();
                }
                
                // Verificar que el prefijo no esté vacío
                if (!newPrefix || newPrefix.length === 0) {
                    await sock.sendMessage(from, {
                        text: `🌽 *El prefijo no puede estar vacío*`,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    return;
                }
                
                // Verificar que el prefijo esté en la lista de permitidos
                if (!ALLOWED_PREFIXES.includes(newPrefix)) {
                    await sock.sendMessage(from, {
                        text: `🌽 *Prefijo no permitido*\n\n` +
                              `> *Prefijos permitidos:* ${ALLOWED_PREFIXES.join(', ')}`,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    return;
                }
                
                try {
                    console.log(`📝 Botowner ${senderNumber} está cambiando el prefijo del bot ${botNumber}...`);
                    
                    const configPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
                    
                    if (!fs.existsSync(configPath)) {
                        throw new Error(`No se encontró configuración para el bot ${botNumber}`);
                    }
                    
                    console.log(`📝 Leyendo configuración actual de: ${configPath}`);
                    
                    let configContent = fs.readFileSync(configPath, 'utf8');
                    const jsonMatch = configContent.match(/export default\s+({[\s\S]*})/);
                    if (!jsonMatch || !jsonMatch[1]) {
                        throw new Error('Formato de archivo config.js inválido');
                    }
                    
                    const currentConfig = eval('(' + jsonMatch[1] + ')');
                    const oldPrefix = currentConfig.prefix || config.prefix;
                    currentConfig.prefix = newPrefix;
                    
                    console.log(`📝 Actualizando prefijo de "${oldPrefix}" a "${newPrefix}"`);
                    
                    const newConfigContent = `// Configuración del Bot - ${currentConfig.tipo || 'Sub-Bot'}
// Creado para el número: ${botNumber}
// Actualizado el: ${new Date().toLocaleString()}

export default ${JSON.stringify(currentConfig, null, 2)}
`;
                    
                    fs.writeFileSync(configPath, newConfigContent);
                    console.log(`✅ Configuración actualizada para bot ${botNumber}`);
                    
                    await sock.sendMessage(from, {
                        text: `🌽 *Prefijo actualizado con éxito*\n\n` +
                              `> *Nuevo prefijo:* ${newPrefix}\n` +
                              `> *Anterior:* ${oldPrefix}\n` +
                              `> *Bot:* ${botNumber}\n` +
                              `> *Actualizado por:* Bot Owner\n\n` +
                              `🍭 Ahora usa ${newPrefix} para los comandos`,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    
                } catch (error) {
                    console.error('Error en setbotprefix:', error);
                    
                    await sock.sendMessage(from, {
                        text: `⚙️ *Error al cambiar el prefijo*\n> ${error.message}`,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
                return;
            }
            
            // ==========================================
            // MOSTRAR LISTA DESPLEGABLE DE PREFIJOS
            // ==========================================
            
            // Crear filas para la lista desplegable (usando 'id' no 'rowId')
            const rows = ALLOWED_PREFIXES.map(prefix => ({
                title: `Prefijo: "${prefix}"`,
                description: `Cambiar el prefijo del bot a "${prefix}"`,
                id: `${config.prefix}botprefix +${prefix}`
            }));
            
            const sections = [{
                title: "🌈 PREFIJOS DISPONIBLES",
                rows: rows
            }];
            
            await sock.sendMessage(from, {
                text: "🌽 *Selecciona un prefijo para el bot*",
                footer: "© Moonlight Staff",
                interactiveButtons: [
                    {
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "Seleccionar",
                            sections: sections,
                        }),
                    },
                ],
            }, { quoted: msg });
            
        } catch (error) {
            console.error('Error general en setbotprefix:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ Error inesperado en setbotprefix`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};