import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ====================
// FUNCIONES LOCALES
// ====================

// Cargar base de datos de niveles
function loadLevelDB() {
    try {
        const levelFile = path.join(__dirname, '..', 'databases', 'level.json');
        if (fs.existsSync(levelFile)) {
            const data = fs.readFileSync(levelFile, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando level.json:', error);
    }
    return {};
}

// Cargar base de datos de usuarios
function loadUsersDB() {
    try {
        const usersFile = path.join(__dirname, '..', 'databases', 'users.json');
        if (fs.existsSync(usersFile)) {
            const data = fs.readFileSync(usersFile, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando users.json:', error);
    }
    return {};
}

// Extraer número de cualquier JID
function extractNumberFromJid(jid) {
    if (!jid) return null;
    const number = jid.split('@')[0];
    return number.replace(/\D/g, '');
}

// 🔥 FUNCIÓN PARA OBTENER EL NÚMERO REAL (sea LID o JID) 🔥
function getRealPhoneNumber(jid, usersDB) {
    if (!jid) return null;
    const identificador = jid.split('@')[0];
    
    // Buscar en usersDB por LID
    for (const [num, data] of Object.entries(usersDB)) {
        if (data.lid === jid || data.lid === identificador) return num;
        if (data.jid === jid || data.jid === identificador) return num;
    }
    
    if (/^[\d]+$/.test(identificador) && identificador.length > 8) return identificador;
    return null;
}

// Calcular nivel basado en EXP
function calculateLevel(exp) {
    let level = 1;
    let expNeeded = 100;
    let currentExp = exp;
    
    while (currentExp >= expNeeded) {
        currentExp -= expNeeded;
        level++;
        expNeeded = Math.floor(100 * Math.pow(1.5, level - 1));
    }
    
    return {
        level,
        currentExp,
        expNeeded,
        totalExp: exp
    };
}

// Obtener información de nivel de un usuario por su número
function getUserLevelInfo(userNumber) {
    try {
        const levelDB = loadLevelDB();
        
        if (!userNumber || !levelDB[userNumber]) {
            return {
                exists: false,
                level: 1,
                currentExp: 0,
                expNeeded: 100,
                totalExp: 0,
                commands: 0
            };
        }
        
        const userData = levelDB[userNumber];
        const levelData = calculateLevel(userData.exp || 0);
        
        return {
            exists: true,
            level: levelData.level,
            currentExp: levelData.currentExp,
            expNeeded: levelData.expNeeded,
            totalExp: levelData.totalExp,
            commands: userData.commands || 0
        };
        
    } catch (error) {
        console.error('Error obteniendo info de nivel:', error);
        return {
            exists: false,
            level: 1,
            currentExp: 0,
            expNeeded: 100,
            totalExp: 0,
            commands: 0
        };
    }
}

// Obtener nombre para mostrar de un usuario
function getDisplayName(usersDB, userIdentifier, defaultName = 'Usuario') {
    try {
        const userNumber = getRealPhoneNumber(userIdentifier, usersDB) || extractNumberFromJid(userIdentifier);
        
        if (userNumber && usersDB[userNumber]) {
            return usersDB[userNumber].pushName || usersDB[userNumber].name || userNumber;
        }
        
        return userNumber || userIdentifier.split('@')[0] || defaultName;
        
    } catch (error) {
        console.error('Error obteniendo nombre para mostrar:', error);
        return defaultName;
    }
}

// ====================
// COMANDO PRINCIPAL
// ====================

export default {
    name: 'level',
    alias: ['lvl', 'nivel', 'exp'],
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, senderNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            // Cargar base de datos de usuarios
            const usersDB = loadUsersDB();
            
            // Variables para el usuario objetivo
            let targetJid = senderJid;
            let targetNumber = senderNumber;
            let targetPushName = pushName;
            let targetMentionJid = null;
            
            // Obtener información del mensaje
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            const mentionedJids = quotedMsg?.mentionedJid || [];
            
            console.log('🔍 Debug - Datos del mensaje:');
            console.log('  SenderNumber:', senderNumber);
            console.log('  SenderJid:', senderJid);
            console.log('  Quoted participant:', quotedMsg?.participant);
            console.log('  Mentioned JIDs:', mentionedJids);
            
            // Prioridad 1: Hay mención con @
            if (mentionedJids.length > 0) {
                targetJid = mentionedJids[0];
                targetNumber = getRealPhoneNumber(targetJid, usersDB);
                targetMentionJid = targetJid;
                targetPushName = getDisplayName(usersDB, targetJid, 'Usuario mencionado');
                console.log(`  ✅ Usando mención: ${targetJid} -> Número: ${targetNumber} -> Nombre: ${targetPushName}`);
            }
            // Prioridad 2: Hay mensaje citado
            else if (quotedMsg?.participant) {
                targetJid = quotedMsg.participant;
                targetNumber = getRealPhoneNumber(targetJid, usersDB);
                targetMentionJid = targetJid;
                targetPushName = getDisplayName(usersDB, targetJid, 'Usuario citado');
                console.log(`  ✅ Usando citado: ${targetJid} -> Número: ${targetNumber} -> Nombre: ${targetPushName}`);
            }
            // Prioridad 3: El propio usuario
            else {
                targetMentionJid = senderJid;
                targetNumber = senderNumber;
                targetPushName = pushName;
                console.log(`  ✅ Usando propio usuario: ${senderJid} -> Número: ${targetNumber} -> Nombre: ${pushName}`);
            }
            
            // Si no se pudo obtener el número, usar el extraído del JID
            if (!targetNumber) {
                targetNumber = extractNumberFromJid(targetJid);
                console.log(`  ⚠️ Usando número extraído: ${targetNumber}`);
            }
            
            // Obtener información de nivel del usuario objetivo
            const levelInfo = getUserLevelInfo(targetNumber);
            
            console.log('📊 Información de nivel:');
            console.log('  Número:', targetNumber);
            console.log('  Existe:', levelInfo.exists);
            console.log('  Nivel:', levelInfo.level);
            console.log('  EXP total:', levelInfo.totalExp);
            console.log('  Comandos:', levelInfo.commands);
            
            // Calcular porcentaje de progreso
            const percentage = levelInfo.expNeeded > 0 
                ? Math.round((levelInfo.currentExp / levelInfo.expNeeded) * 100) 
                : 0;
            
            // Crear barra de progreso visual
            const progressBarLength = 10;
            const filled = Math.min(Math.round((percentage / 100) * progressBarLength), progressBarLength);
            const empty = progressBarLength - filled;
            const progressBar = '█'.repeat(filled) + '░'.repeat(empty);
            
            // Construir mensaje
            const message = `⁽͡₍֭  ֽ፝֟  ֥ ₎͡⁾ Nivel de *${targetPushName}*\n\n` +
                          `꒰͡͡𖹭͡꒱ Nivel » *${levelInfo.level}*\n` +
                          `꒰͡͡𖹭͡꒱ Exp » *${levelInfo.totalExp}*\n` +
                          `꒰͡͡𖹭͡꒱ Proceso » *${levelInfo.currentExp}* » *${levelInfo.expNeeded}* (${percentage}%)\n` +
                          `╰► ${progressBar} ${percentage}%\n\n` +
                          `꒰͡͡𖹭͡꒱ Total cmd » *${levelInfo.commands}*\n` +
                          `︶͜ᩙᨘٜ⏝͜ᩙٜ︶ᩙִ   ᨘ̇🪾ᨘ ̇ ִ︶͜ᩙٜ⏝͜ᩙٜ︶ᩙ`;
            
            // Preparar menciones
            const mentions = targetMentionJid ? [targetMentionJid] : [];
            
            console.log('📤 Enviando mensaje:');
            console.log('  Target JID:', targetMentionJid);
            console.log('  Display name:', targetPushName);
            console.log('  Level:', levelInfo.level);
            console.log('  Comandos:', levelInfo.commands);
            
            // Enviar mensaje con contexto
            await sock.sendMessage(from, {
                text: message,
                mentions: mentions,
                contextInfo: {
                    mentionedJid: mentions,
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            console.log(`📊 Comando level ejecutado para ${targetPushName} (${targetNumber}) - Nivel: ${levelInfo.level} - Comandos: ${levelInfo.commands}`);
            
        } catch (error) {
            console.error('❌ Error en comando level:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ Error al obtener información de nivel: ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
};