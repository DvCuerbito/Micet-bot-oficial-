import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { downloadMediaMessage } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PACKS_FILE = path.join(__dirname, '..', 'databases', 'packs.json');

const loadPacksDB = () => {
    try {
        if (fs.existsSync(PACKS_FILE)) {
            const data = fs.readFileSync(PACKS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando packs.json:', error);
    }
    return {};
};

const savePacksDB = (packsDB) => {
    try {
        const dbDir = path.join(__dirname, '..', 'databases');
        if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
        fs.writeFileSync(PACKS_FILE, JSON.stringify(packsDB, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando packs.json:', error);
        return false;
    }
};

export default {
    name: 'addsticker',
    alias: ['stickeradd'],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, senderJid, args, pushName } = options;
            const from = msg.key.remoteJid;
            
            const packName = args.join(' ').trim();
            
            if (!packName) {
                return await sock.sendMessage(from, {
                    text: `「✰」Debes proporcionar el nombre del pack\n> Ejemplo: ${config.prefix}addsticker Mis Stickers (Respondiendo a un sticker)`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            const quotedMessage = quotedMsg?.quotedMessage;
            
            if (!quotedMessage || !quotedMessage.stickerMessage) {
                return await sock.sendMessage(from, {
                    text: `「✰」 *Debes responder a un sticker*\n> Ejemplo: ${config.prefix}addsticker Mis Stickers (respondiendo a un sticker)`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            const packsDB = loadPacksDB();
            
            if (!packsDB[senderNumber] || !packsDB[senderNumber].packs) {
                return await sock.sendMessage(from, {
                    text: `「✰」 No tienes ningún pack creado\n> Crea uno con ${config.prefix}newpack <nombre>`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            const pack = packsDB[senderNumber].packs.find(p => p.name.toLowerCase() === packName.toLowerCase());
            
            if (!pack) {
                const similarPacks = packsDB[senderNumber].packs.filter(p => 
                    p.name.toLowerCase().includes(packName.toLowerCase())
                );
                
                if (similarPacks.length > 0) {
                    return await sock.sendMessage(from, {
                        text: `「✰」 No tienes un pack llamado \`"${packName}"\` `,
                        contextInfo: {
                            mentionedJid: [senderJid],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
                
                return await sock.sendMessage(from, {
                    text: `「✰」No tienes un pack llamado "${packName}"\n> Crea uno usando ${config.prefix}newpack ${packName}`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            if (pack.stickers.length >= 50) {
                return await sock.sendMessage(from, {
                    text: `「✰」Límite de stickers alcanzado *(50/50)*`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            const quotedMsgObj = {
                key: {
                    remoteJid: from,
                    id: quotedMsg.stanzaId,
                    participant: quotedMsg.participant || from,
                    fromMe: false
                },
                message: {
                    stickerMessage: quotedMessage.stickerMessage
                }
            };
            
            const stickerBuffer = await downloadMediaMessage(
                quotedMsgObj,
                'buffer',
                {},
                {
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage
                }
            );
            
            if (!stickerBuffer || stickerBuffer.length === 0) {
                throw new Error('No se pudo descargar el sticker');
            }
            
            const stickerId = Date.now().toString() + Math.random().toString(36).substring(7);
            
            pack.stickers.push({
                id: stickerId,
                buffer: stickerBuffer.toString('base64'),
                addedAt: new Date().toLocaleString(),
                timestamp: Date.now()
            });
            
            pack.lastModified = Date.now().toString();
            
            savePacksDB(packsDB);
            
            await sock.sendMessage(from, {
                text: `《✧》Sticker agregado al pack \`${pack.name}\`!\n> Ahora tiene *${pack.stickers.length}* sticker(s)`,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
        } catch (error) {
            console.error('❌ Error en addsticker:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ Error: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};