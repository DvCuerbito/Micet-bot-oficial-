// Lista de rangos permitidos (owners y mods)
const ALLOWED_RANKS = ['owner', 'c-owner', 'srmod', 'mod'];

export default {
    name: 'modban',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, args, pushName, saveUsersDB } = options;
            const from = msg.key.remoteJid;
            
            console.log(`🔨 Comando modban ejecutado por: ${senderNumber}`);

            // Verificar si el usuario tiene permisos (owner de config o mods)
            const userData = usersDB[senderNumber];
            const userRank = userData?.rank;
            const isAllowed = userRank && ALLOWED_RANKS.includes(userRank);
            
            // Verificar si es owner según config.js
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isOwner && !isAllowed) {
                return await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}modban\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            let targetUserJid = null;
            let targetUserNumber = null;
            let reason = '';

            // Obtener el texto completo del mensaje para extraer la razón
            let fullText = '';
            if (msg.message?.conversation) {
                fullText = msg.message.conversation;
            } else if (msg.message?.extendedTextMessage?.text) {
                fullText = msg.message.extendedTextMessage.text;
            }
            
            // Remover el prefijo y el comando
            const withoutPrefix = fullText.replace(`${config.prefix}modban`, '').trim();

            // 🔥 FUNCIÓN PARA OBTENER EL NÚMERO REAL (sea LID o JID) 🔥
            const getRealPhoneNumber = (jid) => {
                if (!jid) return null;
                
                // Extraer el identificador (lo que está antes del @)
                const identificador = jid.split('@')[0];
                
                // CASO 1: Buscar en usersDB por LID
                for (const [num, data] of Object.entries(usersDB)) {
                    if (data.lid === jid || data.lid === identificador) {
                        console.log(`✅ LID encontrado! Número real: ${num}`);
                        return num;
                    }
                }
                
                // CASO 2: Buscar en usersDB por JID
                for (const [num, data] of Object.entries(usersDB)) {
                    if (data.jid === jid || data.jid === identificador) {
                        console.log(`✅ JID encontrado! Número real: ${num}`);
                        return num;
                    }
                }
                
                // CASO 3: Si ya es un número de teléfono (solo dígitos)
                if (/^[\d]+$/.test(identificador) && identificador.length > 8) {
                    // Verificar si existe en usersDB
                    if (usersDB[identificador]) {
                        return identificador;
                    }
                    return identificador; // Asumir que es el número
                }
                
                // Si no se encuentra, devolver null
                return null;
            };

            // Verificar si hay mención
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
                
                // Obtener el número real
                targetUserNumber = getRealPhoneNumber(targetUserJid);
                
                if (!targetUserNumber) {
                    return await sock.sendMessage(from, {
                        text: `❌ No se pudo obtener el número del usuario mencionado.`,
                        contextInfo: {
                            mentionedJid: [],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
                
                // Extraer razón (todo después de la mención)
                const mentionText = `@${targetUserJid.split('@')[0]}`;
                reason = withoutPrefix.replace(mentionText, '').trim();
                
                console.log(`✅ Usuario mencionado: ${targetUserJid} -> Número: ${targetUserNumber}`);
            }
            // Verificar si es respuesta
            else if (msg.message?.extendedTextMessage?.contextInfo?.stanzaId) {
                const quotedMsg = msg.message.extendedTextMessage.contextInfo;
                if (quotedMsg.participant) {
                    targetUserJid = quotedMsg.participant;
                    
                    // Obtener el número real
                    targetUserNumber = getRealPhoneNumber(targetUserJid);
                    
                    if (!targetUserNumber) {
                        return await sock.sendMessage(from, {
                            text: `❌ No se pudo obtener el número del usuario citado.`,
                            contextInfo: {
                                mentionedJid: [],
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                    }
                    
                    // La razón es todo el texto después del comando
                    reason = withoutPrefix;
                    console.log(`✅ Usuario por respuesta: ${targetUserJid} -> Número: ${targetUserNumber}`);
                }
            }

            // Si no se encontró usuario
            if (!targetUserJid || !targetUserNumber) {
                return await sock.sendMessage(from, {
                    text: `🌠 Debes mencionar o responder a un usuario para banear`,
                    contextInfo: {
                        mentionedJid: [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }

            // Verificar si se proporcionó razón
            if (!reason) {
                return await sock.sendMessage(from, {
                    text: `🦋 Debes proporcionar una razón de baneo`,
                    contextInfo: {
                        mentionedJid: [targetUserJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }

            // Obtener pushName del usuario a banear
            const targetName = usersDB[targetUserNumber]?.pushName || 
                               usersDB[targetUserNumber]?.name || 
                               targetUserNumber;

            // Obtener pushName del usuario que banea
            const bannerName = pushName || senderNumber;

            // Fecha actual
            const fecha = new Date().toLocaleString('es-ES', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });

            // Guardar el ban en usersDB
            if (!usersDB[targetUserNumber]) {
                usersDB[targetUserNumber] = {
                    number: targetUserNumber,
                    jid: targetUserJid,
                    name: targetName,
                    pushName: targetName,
                    registered: new Date().toISOString()
                };
            }

            usersDB[targetUserNumber].banned = {
                isBanned: true,
                reason: reason,
                date: fecha,
                bannedBy: senderNumber,
                bannedByName: bannerName,
                timestamp: Date.now()
            };

            // Guardar cambios en users.json usando la función del handler
            if (saveUsersDB) {
                saveUsersDB(usersDB);
            }

            // Mensaje de éxito
            const mensajeExito = `🦋 *${targetName}* fue baneado

🌠 Razón » *${reason}*
🌠 Fecha » *${fecha}*
🌠 Baneado por » *${bannerName}*`;

            await sock.sendMessage(from, {
                text: mensajeExito,
                contextInfo: {
                    mentionedJid: [targetUserJid, senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            console.log(`✅ Usuario baneado: ${targetName} (${targetUserNumber}) por ${bannerName} - Razón: ${reason}`);

        } catch (error) {
            console.error('❌ Error en modban:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `🌸 Error al ejecutar el comando: ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};