export default {
    name: 'furro',
    alias: ['furry'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            console.log(`🦊 Comando furro ejecutado por: ${senderNumber}`);

            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            let targetUserJid = senderJid;
            let targetUserNumber = senderNumber;

            // Verificar si hay mención
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
                targetUserNumber = targetUserJid.split('@')[0];
                console.log(`✅ Usuario mencionado: ${targetUserNumber}`);
            }
            // Verificar si es respuesta
            else if (msg.message?.extendedTextMessage?.contextInfo?.stanzaId) {
                const quotedMsg = msg.message.extendedTextMessage.contextInfo;
                if (quotedMsg.participant) {
                    targetUserJid = quotedMsg.participant;
                    targetUserNumber = targetUserJid.split('@')[0];
                }
                console.log(`✅ Usuario por respuesta: ${targetUserNumber}`);
            }

            // Obtener nombre del usuario objetivo
            const targetName = usersDB[targetUserNumber]?.pushName || 
                              usersDB[targetUserNumber]?.name || 
                              targetUserNumber;

            // Calcular porcentaje basado en el número del usuario
            let hash = 0;
            for (let i = 0; i < targetUserNumber.length; i++) {
                hash = ((hash << 3) - hash) + targetUserNumber.charCodeAt(i);
                hash = hash & hash;
            }
            const porcentaje = Math.abs(hash) % 101;

            // Determinar fursona según el porcentaje
            let fursona = "";
            if (porcentaje <= 10) {
                fursona = "🐭 Ratón - Pequeño y tierno";
            } else if (porcentaje <= 20) {
                fursona = "🐱 Gato - Elegante y juguetón";
            } else if (porcentaje <= 30) {
                fursona = "🐶 Perro - Leal y energético";
            } else if (porcentaje <= 40) {
                fursona = "🦊 Zorro - Astuto y carismático";
            } else if (porcentaje <= 50) {
                fursona = "🐺 Lobo - Social y misterioso";
            } else if (porcentaje <= 60) {
                fursona = "🐻 Oso - Grande y acogedor";
            } else if (porcentaje <= 70) {
                fursona = "🦁 León - Majestuoso y valiente";
            } else if (porcentaje <= 80) {
                fursona = "🐉 Dragón - Poderoso y legendario";
            } else if (porcentaje <= 90) {
                fursona = "🦄 Unicornio - Mágico y especial";
            } else {
                fursona = "🐺🦊 Híbrido - Combinación única de especies";
            }

            // Textos dinámicos según el porcentaje
            let textoDinamico = "";
            if (porcentaje <= 10) {
                textoDinamico = "🧐 No sabes nada del fandom furry";
            } else if (porcentaje <= 20) {
                textoDinamico = "👀 Has visto algunos furros en internet";
            } else if (porcentaje <= 30) {
                textoDinamico = "🐾 Te parecen interesantes los trajes";
            } else if (porcentaje <= 40) {
                textoDinamico = "🎨 Dibujas o aprecias el arte furry";
            } else if (porcentaje <= 50) {
                textoDinamico = "🦊 Tienes una fursona en mente";
            } else if (porcentaje <= 60) {
                textoDinamico = "🐺 Asistes a convenciones furry";
            } else if (porcentaje <= 70) {
                textoDinamico = "🧶 Tienes o quieres un fursuit";
            } else if (porcentaje <= 80) {
                textoDinamico = "🌈 Eres parte activa del fandom";
            } else if (porcentaje <= 90) {
                textoDinamico = "🌟 Eres un furry de corazón y alma";
            } else {
                textoDinamico = "🦁🐉 Eres la definición de furry legendario";
            }

            // Enviar mensaje de cálculo con las 5 ediciones
            const progressMessages = [
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 20%`,
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 40%`,
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 60%`,
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 80%`,
                `*ׄ─ׄ𖤐─ׄ* 100%`
            ];

            console.log(`🔄 Iniciando cálculo furry para: ${targetName}`);

            // Enviar primer mensaje de progreso
            const progressMsg = await sock.sendMessage(from, { 
                text: `🦊 *Analizando tu nivel furry...*\n\n${progressMessages[0]}`,
                contextInfo: {
                    mentionedJid: [targetUserJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            });

            // Editar el mensaje 4 veces más con delay
            for (let i = 1; i < progressMessages.length; i++) {
                await new Promise(resolve => setTimeout(resolve, 1000));
                await sock.sendMessage(from, { 
                    text: `🦊 *Analizando tu nivel furry...*\n\n${progressMessages[i]}`,
                    edit: progressMsg.key,
                    contextInfo: {
                        mentionedJid: [targetUserJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                });
                console.log(`📝 Editando mensaje ${i + 1}/5`);
            }

            // Esperar un poco antes del resultado final
            await new Promise(resolve => setTimeout(resolve, 1500));

            // Eliminar mensaje de progreso
            await sock.sendMessage(from, { 
                delete: progressMsg.key 
            });

            // Enviar resultado final
            const resultadoFinal = `🦊 *Análisis Furry completado* de @${targetUserNumber}

🌈 *Porcentaje Furry:* ${porcentaje}%
🦁 *Tu fursona sería:* ${fursona}

> ${textoDinamico}`;

            await sock.sendMessage(from, {
                text: resultadoFinal,
                contextInfo: {
                    mentionedJid: [targetUserJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            console.log(`🎉 Cálculo furry completado: ${targetName} = ${porcentaje}%`);

        } catch (error) {
            console.error(`❌ Error en comando furro:`, error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { 
                    text: `🦊 Error al calcular tu nivel furry: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};