import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 0,
            minerals: {
                piedras: 0,
                diamantes: 0,
                esmeraldas: 0,
                oro: 0
            },
            health: 100,
            lastMine: 0,
            lastWork: 0,
            lastCrime: 0,
            lastAdventure: 0,
            lastClaim: 0,
            lastChest: 0,
            items: {
                agua: 0,
                vendas: 0,
                pastillas: 0
            }
        };
    }
    return economy[userNumber];
}

// Función para formatear números sin notación científica
function formatNumber(num) {
    if (num === undefined || num === null) return '0';
    if (typeof num === 'number') {
        if (num > 999999) {
            return num.toLocaleString('es-MX', { useGrouping: true });
        }
        return num.toString();
    }
    if (typeof num === 'string' && num.includes('e')) {
        const parsed = parseFloat(num);
        return parsed.toLocaleString('es-MX', { useGrouping: true });
    }
    return num.toString();
}

export default {
    name: 'pay',
    alias: ['pagar', 'transferir', 'enviar'],
    
    async execute(sock, msg, options) {
        try {
            const { 
                config, 
                senderNumber, 
                pushName,
                replyWithContext,
                senderJid,
                usersDB,
                args 
            } = options;
            
            const from = msg.key.remoteJid;
            
            if (!senderNumber) {
                return await replyWithContext(
                    '❌ No se pudo identificar tu número',
                    [senderJid]
                );
            }
            
            // Verificar argumentos
            if (!args || args.length < 2) {
                return await replyWithContext(
                    `💸 *TRANSFERIR COINS*\n\n` +
                    `> Uso: ${config.prefix}pay [cantidad] @usuario\n` +
                    `> Ejemplo: ${config.prefix}pay 100 @usuario\n\n` +
                    `> Transfiere coins a otro usuario`,
                    [senderJid]
                );
            }
            
            // Obtener cantidad
            const cantidad = parseInt(args[0]);
            
            if (isNaN(cantidad) || cantidad < 1) {
                return await replyWithContext(
                    '❌ La cantidad debe ser un número positivo',
                    [senderJid]
                );
            }
            
            // ==========================================
            // OBTENER USUARIO DESTINO POR MENCIÓN
            // ==========================================
            const mencionado = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            
            if (!mencionado) {
                return await replyWithContext(
                    '❌ Debes mencionar al usuario que recibirá los coins\n' +
                    `> Ejemplo: ${config.prefix}pay 100 @usuario`,
                    [senderJid]
                );
            }
            
            // Extraer el identificador (puede ser LID o número)
            const identificador = mencionado.split('@')[0];
            
            // Buscar en usersDB por LID para encontrar el número
            let receptorNumber = identificador;
            let receptorName = "Usuario";
            
            // Buscar en usersDB si el identificador es un LID
            for (const [num, userData] of Object.entries(usersDB)) {
                if (userData.lid === mencionado || userData.lid === identificador) {
                    receptorNumber = num;
                    receptorName = userData.pushName || "Usuario";
                    break;
                }
            }
            
            // Si no se encontró en usersDB, intentar con el identificador directamente
            if (receptorNumber === identificador && usersDB[identificador]) {
                receptorName = usersDB[identificador]?.pushName || "Usuario";
            }
            
            // Verificar que no se está enviando a sí mismo
            if (receptorNumber === senderNumber) {
                return await replyWithContext(
                    '❌ No puedes transferirte coins a ti mismo',
                    [senderJid]
                );
            }
            
            // Cargar economía
            let economy = loadEconomy();
            
            // Inicializar usuario remitente
            const sender = initUserEconomy(economy, senderNumber, pushName);
            
            // Verificar si el remitente tiene suficientes coins
            if (sender.coins < cantidad) {
                return await replyWithContext(
                    `❌ No tienes suficientes coins\n` +
                    `> Quieres transferir: *${formatNumber(cantidad)}* coins\n` +
                    `> Tienes: *${formatNumber(sender.coins)}* coins`,
                    [senderJid]
                );
            }
            
            // Inicializar usuario receptor si no existe
            if (!economy[receptorNumber]) {
                economy[receptorNumber] = {
                    number: receptorNumber,
                    name: receptorName,
                    coins: 0,
                    minerals: {
                        piedras: 0,
                        diamantes: 0,
                        esmeraldas: 0,
                        oro: 0
                    },
                    health: 100,
                    lastMine: 0,
                    lastWork: 0,
                    lastCrime: 0,
                    lastAdventure: 0,
                    lastClaim: 0,
                    lastChest: 0,
                    items: {
                        agua: 0,
                        vendas: 0,
                        pastillas: 0
                    }
                };
            }
            
            const receptor = economy[receptorNumber];
            
            // Realizar transferencia
            sender.coins -= cantidad;
            receptor.coins += cantidad;
            
            // Guardar cambios
            saveEconomy(economy);
            
            // Formatear números para mostrar
            const cantidadFormateada = formatNumber(cantidad);
            const senderCoinsFormateado = formatNumber(sender.coins);
            const receptorCoinsFormateado = formatNumber(receptor.coins);
            
            // Mensaje de confirmación
            const transferText = `💸 *TRANSFERENCIA EXITOSA*\n\n` +
                `📤 *Remitente:* ${pushName}\n` +
                `📥 *Destinatario:* ${receptorName}\n\n` +
                `💰 *Cantidad:* ${cantidadFormateada} coins\n\n` +
                `📊 *Nuevos saldos:*\n` +
                `> ${pushName}: *${senderCoinsFormateado}* coins\n` +
                `> ${receptorName}: *${receptorCoinsFormateado}* coins`;
            
            // Mencionar a ambos usuarios
            const mentions = [senderJid, mencionado];
            
            await replyWithContext(transferText, mentions);
            
            // Opcional: Notificar al receptor en privado si el comando se usó en grupo
            if (from.endsWith('@g.us')) {
                try {
                    const notificacionPrivada = `💸 *Has recibido una transferencia*\n\n` +
                        `> *De:* ${pushName}\n` +
                        `> *Cantidad:* ${cantidadFormateada} coins\n\n` +
                        `> Tu nuevo saldo: *${receptorCoinsFormateado}* coins`;
                    
                    await sock.sendMessage(mencionado, { 
                        text: notificacionPrivada,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    });
                } catch (e) {
                    console.log('No se pudo enviar notificación privada al receptor');
                }
            }
            
        } catch (error) {
            console.error('❌ Error en comando pay:', error);
            await options.replyWithContext(
                `❌ Error: ${error.message}`,
                [options.senderJid]
            );
        }
    }
};
