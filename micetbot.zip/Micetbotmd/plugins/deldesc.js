import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'deldesc',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, sender } = options;
            const from = msg.key.remoteJid;
            const user = msg.key.participant || from;
            
            // Solo el owner puede usar este comando
            const OWNER_ID = '189202503315478@lid';
            
            if (user !== OWNER_ID) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}deldesc\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const fullArgs = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const cleanArgs = fullArgs.replace(config.prefix + 'deldesc', '').trim();

            if (!cleanArgs || !cleanArgs.includes('+')) {
                await sock.sendMessage(from, {
                    text: '☆ Formato: /deldesc +categoría +descripción\n> ✐ Ej: /deldesc +angry +{user} está enojado con {user2}',
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const parts = cleanArgs.split('+').slice(1);
            if (parts.length < 2) {
                await sock.sendMessage(from, {
                    text: '☆ Debes especificar categoría y descripción.',
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const categoryName = parts[0].trim().toLowerCase();
            const searchDescription = parts.slice(1).join('+').trim();

            if (!categoryName || !searchDescription) {
                await sock.sendMessage(from, {
                    text: '☆ Debes especificar categoría y descripción.',
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const descFile = path.join(__dirname, '..', 'databases', 'gif_descriptions.json');
            let descriptions = {};
            
            if (fs.existsSync(descFile)) {
                descriptions = JSON.parse(fs.readFileSync(descFile, 'utf8'));
            }

            if (!descriptions[categoryName] || descriptions[categoryName].length === 0) {
                await sock.sendMessage(from, {
                    text: `❖ No hay descripciones en la categoría *${categoryName}*`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const categoryDescriptions = descriptions[categoryName];
            let deletedIndex = -1;
            let deletedDesc = null;

            for (let i = 0; i < categoryDescriptions.length; i++) {
                if (categoryDescriptions[i].text.includes(searchDescription)) {
                    deletedIndex = i;
                    deletedDesc = categoryDescriptions[i];
                    break;
                }
            }

            if (deletedIndex === -1) {
                await sock.sendMessage(from, {
                    text: `❖ No se encontró la descripción en *${categoryName}*`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            descriptions[categoryName].splice(deletedIndex, 1);

            if (descriptions[categoryName].length === 0) {
                delete descriptions[categoryName];
            }

            fs.writeFileSync(descFile, JSON.stringify(descriptions, null, 2));

            await sock.sendMessage(from, {
                text: `☆ Se ha eliminado la descripción de *${categoryName}*\n> 🍒: ${deletedDesc.text}`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });

        } catch (error) {
            console.log('Error en comando deldesc:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: '❖ Error al eliminar la descripción.',
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};