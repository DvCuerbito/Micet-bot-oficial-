import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'help',
    alias: ['menu', 'commands'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, sender, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // Verificar registro
            if (usersDB && sender && !usersDB[sender]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso: ${config.prefix}reg nombre`
                }, { quoted: msg });
                return;
            }
            
            // Obtener número del bot
            let botNumber = '';
            if (sock.phoneNumber) {
                botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            // Cargar configuración del bot
            let botConfig = { ...config };
            if (botNumber) {
                const configPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
                if (fs.existsSync(configPath)) {
                    try {
                        const configContent = fs.readFileSync(configPath, 'utf8');
                        const jsonMatch = configContent.match(/export default\s+({[\s\S]*})/);
                        if (jsonMatch && jsonMatch[1]) {
                            const infoConfig = eval('(' + jsonMatch[1] + ')');
                            if (infoConfig) botConfig = infoConfig;
                        }
                    } catch (e) {}
                }
            }
            
            // Cargar menú y categorías
            const menuPath = path.join(__dirname, '..', 'databases', 'menu.json');
            let menuData = { categories: [], categoryDescriptions: {} };
            
            try {
                if (fs.existsSync(menuPath)) {
                    const data = fs.readFileSync(menuPath, 'utf8');
                    menuData = JSON.parse(data);
                }
            } catch (error) {
                console.error('Error cargando menú:', error);
            }
            
            // Construir rows de categorías
            const categoryRows = [];
            
            if (menuData.categories && menuData.categories.length > 0) {
                for (const category of menuData.categories) {
                    const catDesc = menuData.categoryDescriptions?.[category.name] || 
                                   `Comandos de ${category.name}`;
                    const cmdCount = category.commands?.length || 0;
                    
                    categoryRows.push({
                        title: `${category.name.toUpperCase()}`,
                        description: `${catDesc} (${cmdCount})`,
                        id: `${botConfig.prefix || config.prefix}allmenu ${category.name.toLowerCase()}`
                    });
                }
            }
            
            // Si no hay categorías
            if (categoryRows.length === 0) {
                categoryRows.push({
                    title: "📂 SIN CATEGORÍAS",
                    description: "No hay categorías disponibles",
                    id: `${botConfig.prefix || config.prefix}allmenu`
                });
            }
            
            // Texto del encabezado
            const menuText = `๋ ★ *${pushName}* Bienvenido al menu de categorias\n\n` +
                           `ᅟᅟ ㅤ︵ֵ֟፝⏜╲⋱ ⫶ ⋰╱⏜ֵ፝֟︵\n\n` +
                           `♡᳝݀  𐨂🪷໊݀ *Bot* › ${botConfig.name || config.name}\n` +
                           `♡᳝݀  𐨂🪷໊݀ *Tipo* › ${botConfig.tipo || config.tipo}\n` +
                           `♡᳝݀  𐨂🪷໊݀ *Developer* › *StarLyn*\n` +
                           `          .  ׄ ⌣ ִ ⏜ׄ   🌼    ׄ⏜ ִ ⌣\n\n`;
            
            // ==========================================
            // CARGAR IMAGEN DEL BOT (igual que allmenu)
            // ==========================================
            let bannerBuffer = null;
            let imagePath = '';
            let useImage = false;
            
            if (botNumber) {
                const bannerPath = path.join(process.cwd(), 'info', botNumber, 'banner.jpg');
                
                if (fs.existsSync(bannerPath)) {
                    try {
                        bannerBuffer = fs.readFileSync(bannerPath);
                        imagePath = bannerPath;
                        if (bannerBuffer && bannerBuffer.length > 0) {
                            useImage = true;
                        }
                    } catch (bannerError) {
                        console.log(`⚠️ Error cargando imagen:`, bannerError.message);
                    }
                }
            }
            
            // Si no hay imagen específica, buscar imagen general
            if (!useImage) {
                const generalBannerPath = path.join(__dirname, '..', 'img', 'banner.jpg');
                if (fs.existsSync(generalBannerPath)) {
                    try {
                        bannerBuffer = fs.readFileSync(generalBannerPath);
                        imagePath = generalBannerPath;
                        if (bannerBuffer && bannerBuffer.length > 0) {
                            useImage = true;
                        }
                    } catch (bannerError) {
                        console.log(`⚠️ Error cargando imagen general:`, bannerError.message);
                    }
                }
            }
            
            // ====================
            // ENVIAR CON O SIN IMAGEN
            // ====================
            let messageSent = false;
            
            if (useImage && bannerBuffer && bannerBuffer.length > 0) {
                try {
                    const mimeType = imagePath.endsWith('.png') ? 'image/png' : 'image/jpeg';
                    
                    await sock.sendMessage(from, {
                        image: bannerBuffer,
                        caption: menuText,
                        mimetype: mimeType,
                        footer: "Selecciona una categoria",
                        interactiveButtons: [
                            {
                                name: "single_select",
                                buttonParamsJson: JSON.stringify({
                                    title: "Seleccionar",
                                    sections: [
                                        {
                                            title: "Categorías Disponibles",
                                            rows: categoryRows
                                        }
                                    ]
                                }),
                            },
                        ],
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: botConfig.canalId || config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: botConfig.canalNombre || config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    
                    messageSent = true;
                    console.log('✅ Help con imagen enviado');
                    
                } catch (imageError) {
                    console.error('❌ Error al enviar con imagen:', imageError.message);
                }
            }
            
            // Si no se pudo enviar con imagen, enviar solo texto
            if (!messageSent) {
                await sock.sendMessage(from, {
                    text: menuText,
                    footer: "Selecciona una categoria",
                    interactiveButtons: [
                        {
                            name: "single_select",
                            buttonParamsJson: JSON.stringify({
                                title: "Seleccionar",
                                sections: [
                                    {
                                        title: "Categorías Disponibles",
                                        rows: categoryRows
                                    }
                                ]
                            }),
                        },
                    ],
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: botConfig.canalId || config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: botConfig.canalNombre || config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
                console.log('✅ Help sin imagen enviado');
            }
            
            console.log(`✅ Help enviado a ${pushName || sender}`);
            
        } catch (error) {
            console.error('❌ Error en help:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ Error al generar el menú: ${error.message}`
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};