import axios from 'axios';

export default {
    name: 'megumin',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Debes estar registrado.\n> Uso: ${config.prefix}reg nombre`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🕓', key: msg.key } });
            } catch (e) {}
            
            const res = await axios.get('https://api.waifu.pics/sfw/megumin', { timeout: 10000 });
            
            if (!res.data || !res.data.url) {
                throw new Error('No se pudo obtener la imagen');
            }
            
            const imageUrl = res.data.url;
            const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            const imageBuffer = Buffer.from(response.data);
            
            await sock.sendMessage(from, {
                image: imageBuffer,
                caption: `ෆ⁠╹⁠ ⁠.̮⁠ ⁠╹⁠ෆ`,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Megumin enviado a ${pushName || senderNumber}`);
            
        } catch (error) {
            console.error('❌ Error en megumin:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '✖️', key: msg.key } });
            } catch (e) {}
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ Error: ${error.message}`,
                contextInfo: {
                    mentionedJid: [options.senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};