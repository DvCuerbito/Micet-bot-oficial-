import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PACKS_FILE = path.join(__dirname, '..', 'databases', 'packs.json');

const loadPacksDB = () => {
    try {
        if (fs.existsSync(PACKS_FILE)) {
            const data = fs.readFileSync(PACKS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando packs.json:', error);
    }
    return {};
};

export default {
    name: 'getpack',
    alias: ['pack', 'verpack'],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, senderJid, args, pushName } = options;
            const from = msg.key.remoteJid;
            
            const packName = args.join(' ').trim().toLowerCase();
            
            if (!packName) {
                return await sock.sendMessage(from, {
                    text: `「✰」Debes proporcionar el nombre del pack\n> Ejemplo: ${config.prefix}getpack Mis Stickers`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            const packsDB = loadPacksDB();
            
            if (!packsDB[senderNumber] || !packsDB[senderNumber].packs) {
                return await sock.sendMessage(from, {
                    text: `「✰」No tienes ningún pack creado\n> Usa ${config.prefix}newpack para crear uno`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            // Buscar el pack por nombre
            let pack = packsDB[senderNumber].packs.find(p => p.name.toLowerCase() === packName);
            
            if (!pack) {
                return await sock.sendMessage(from, {
                    text: `「✰」No tienes un pack llamado "${packName}"\n> Usa ${config.prefix}packlist para ver tus packs`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            if (!pack.stickers || pack.stickers.length < 4) {
                return await sock.sendMessage(from, {
                    text: `「✰」El pack "${pack.name}" no tiene suficientes stickers (mínimo 4)*\n> Agrega stickers con ${config.prefix}addsticker ${pack.name}`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            // Validar stickers
            const validStickers = pack.stickers.map(s => {
                try {
                    return Buffer.from(s.buffer, 'base64');
                } catch {
                    return null;
                }
            }).filter(s => s && Buffer.isBuffer(s) && s.length > 0);
            
            if (validStickers.length < 4) {
                return await sock.sendMessage(from, {
                    text: `「✰」Algunos stickers del pack están corruptos\n> Intenta agregarlos nuevamente`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);
            
            try {
                await sock.sendMessage(from, { react: { text: '📦', key: msg.key } });
            } catch (e) {}
            
            const MAX_STICKERS = 50;
            const selected = validStickers.slice(0, MAX_STICKERS);
            const cover = selected[0];
            
            // Crear los stickers con metadata
            const webp = await import('node-webpmux');
            const stickerResults = await Promise.all(selected.map(async (buffer) => {
                try {
                    const img = new webp.default.Image();
                    await img.load(buffer);
                    const json = { 
                        'sticker-pack-id': 'https://github.com/Moonlight-Bot', 
                        'sticker-pack-name': pack.name, 
                        'sticker-pack-publisher': pack.author || 'Moonlight Bot', 
                        emojis: ['✨'] 
                    };
                    const exifAttr = Buffer.from([0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
                    const jsonBuff = Buffer.from(JSON.stringify(json), 'utf-8');
                    const exif = Buffer.concat([exifAttr, jsonBuff]);
                    exif.writeUIntLE(jsonBuff.length, 14, 4);
                    img.exif = exif;
                    const tmpOut = `./temp/pack-sticker-${Date.now()}-${Math.random().toString(36).slice(2)}.webp`;
                    await img.save(tmpOut);
                    const stickerBuf = fs.readFileSync(tmpOut);
                    fs.unlinkSync(tmpOut);
                    return { sticker: stickerBuf, isAnimated: false, isLottie: false, emojis: ['✨'] };
                } catch {
                    return { sticker: buffer, isAnimated: false, isLottie: false, emojis: ['✨'] };
                }
            }));
            
            // Enviar el pack completo usando stickerPack
            await sock.sendMessage(from, { 
                stickerPack: { 
                    name: pack.name, 
                    publisher: `𝘔𝘢𝘥𝘦 𝘸𝘪𝘵𝘩 ❤️ | 𝘔𝘰𝘰𝘯𝘭𝘪𝘨𝘩𝘵 𝘚𝘵𝘢𝘧𝘧`, 
                    description: pack.desc || `Paquete de stickers creado por ${pushName || senderNumber}`,
                    cover: cover, 
                    stickers: stickerResults 
                } 
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Pack "${pack.name}" enviado por ${pushName || senderNumber} - ${selected.length} stickers`);
            
        } catch (error) {
            console.error('❌ Error en getpack:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ Error: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};