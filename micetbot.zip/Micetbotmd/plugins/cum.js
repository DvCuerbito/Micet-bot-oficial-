import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function loadUsersDB() {
    try {
        const usersFile = path.join(__dirname, '..', 'databases', 'users.json');
        if (fs.existsSync(usersFile)) return JSON.parse(fs.readFileSync(usersFile, 'utf8'));
    } catch (error) { console.error('Error cargando users.json:', error); }
    return {};
}

function extractNumberFromJid(jid) {
    if (!jid) return null;
    return jid.split('@')[0].replace(/\D/g, '');
}

function getDisplayName(usersDB, userIdentifier, defaultName = 'Usuario') {
    try {
        if (!userIdentifier) return defaultName;
        const userNumber = extractNumberFromJid(userIdentifier);
        if (userNumber && usersDB[userNumber]) return usersDB[userNumber].pushName || usersDB[userNumber].name || userNumber;
        for (const [num, userData] of Object.entries(usersDB)) {
            if (userData.lid === userIdentifier || userData.jid === userIdentifier) return userData.pushName || userData.name || num;
        }
        return userNumber || userIdentifier.split('@')[0] || defaultName;
    } catch (error) { return defaultName; }
}

export default {
    name: 'cum',
    async execute(sock, msg, options) {
        try {
            const { config, pushName, senderNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            const usersDB = loadUsersDB();
            const userName1 = pushName || senderNumber || 'Usuario';
            let user2Jid = null;
            let userName2 = null;

            const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
            let mentionedJids = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

            if (mentionedJids.length > 0) {
                user2Jid = mentionedJids[0];
                userName2 = getDisplayName(usersDB, user2Jid, 'Usuario mencionado');
            } else if (quotedParticipant) {
                user2Jid = quotedParticipant;
                userName2 = getDisplayName(usersDB, user2Jid, 'Usuario citado');
            }

            if (!userName2) userName2 = userName1;

            const categoriesFile = path.join(__dirname, '..', 'databases', 'categories.json');
            let categories = {};
            if (fs.existsSync(categoriesFile)) categories = JSON.parse(fs.readFileSync(categoriesFile, 'utf8'));

            const categoryName = 'cum';
            if (!categories[categoryName]?.videos?.length) return;

            const videoInfo = categories[categoryName].videos[Math.floor(Math.random() * categories[categoryName].videos.length)];
            let descriptionText = `${userName1} se corre sobre ${userName2}`;

            const descFile = path.join(__dirname, '..', 'databases', 'gif_descriptions.json');
            if (fs.existsSync(descFile)) {
                try {
                    let descriptions = JSON.parse(fs.readFileSync(descFile, 'utf8'));
                    if (descriptions[categoryName]?.length > 0) {
                        descriptionText = descriptions[categoryName][Math.floor(Math.random() * descriptions[categoryName].length)].text
                            .replace(/\{user\}/g, userName1).replace(/\{user1\}/g, userName1).replace(/\{user2\}/g, userName2);
                    }
                } catch (e) {}
            }

            const gifPath = path.join(__dirname, '..', 'videos', categoryName, videoInfo.filename);
            const gifBuffer = fs.readFileSync(gifPath);
            const mentions = [senderJid];
            if (user2Jid && user2Jid !== senderJid) mentions.push(user2Jid);

            await sock.sendMessage(from, {
                video: gifBuffer, caption: descriptionText, gifPlayback: true, mimetype: 'video/mp4', mentions: mentions,
                contextInfo: { mentionedJid: mentions, isForwarded: true, forwardedNewsletterMessageInfo: { newsletterJid: config.canalId || '', newsletterName: config.canalNombre || '' } }
            }, { quoted: msg });
        } catch (error) { console.error(error); }
    }
};