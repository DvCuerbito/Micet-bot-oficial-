import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'gp',
    alias: ['groupinfo', 'infogp'],

    async execute(sock, msg, options) {
        try {
            const { config, senderJid, pushName, replyWithContext, getBotNumber } = options;
            const from = msg.key.remoteJid;

            // Verificar que sea un grupo
            if (!from.endsWith('@g.us')) {
                await replyWithContext(`🌸 Este comando solo puede usarse en grupos.`);
                return;
            }

            // 1. Obtener metadatos del grupo
            const metadata = await sock.groupMetadata(from);
            const groupAdmins = metadata.participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin');

            // 2. Obtener información del Bot Primario desde primarios.json
            const PRIMARIOS_FILE = path.join(process.cwd(), 'databases', 'primarios.json');
            let primarioJid = 'aleatorio';
            let primarioNombre = 'aleatorio';
            let primarioTipo = 'PRINCIPAL';

            if (fs.existsSync(PRIMARIOS_FILE)) {
                const primariosDB = JSON.parse(fs.readFileSync(PRIMARIOS_FILE, 'utf8'));
                if (primariosDB[from]) {
                    const phone = primariosDB[from].botPhone.replace(/\D/g, '');
                    primarioJid = `${phone}@s.whatsapp.net`;
                    primarioNombre = primariosDB[from].botNombre || config.name || 'Bot';

                    let currentNumber = '';
                    if (typeof getBotNumber === 'function') {
                        currentNumber = getBotNumber();
                    } else if (sock.user?.id) {
                        currentNumber = sock.user.id.split(':')[0].replace(/\D/g, '');
                    } else if (sock.phoneNumber) {
                        currentNumber = sock.phoneNumber.replace(/\D/g, '');
                    }
                    
                    if (phone === currentNumber) {
                        if (sock.isMainBot) primarioTipo = 'Main Bot';
                        else if (sock.isSubBot) primarioTipo = 'Sub Bot';
                        else primarioTipo = 'Principal';
                    } else {
                        primarioTipo = primariosDB[from].botType || 'PRINCIPAL';
                    }
                }
            }

            // 3. Obtener la cantidad de bots en el grupo
            let botsInGroup = 0;
            const botsList = [];
            
            // Obtener todos los bots activos
            const activeBots = [];
            
            // Principal de creds.json
            try {
                const credsPath = path.join(process.cwd(), 'sessions', 'creds.json');
                if (fs.existsSync(credsPath)) {
                    const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
                    if (creds?.me?.id) {
                        const principalNumber = creds.me.id.split(':')[0].replace(/\D/g, '');
                        activeBots.push(principalNumber);
                    }
                }
            } catch (e) {}
            
            // Main bots
            const mainsDir = path.join(process.cwd(), 'Sessions/Main');
            if (fs.existsSync(mainsDir)) {
                const mainFolders = fs.readdirSync(mainsDir, { withFileTypes: true })
                    .filter(d => d.isDirectory())
                    .map(folder => folder.name);
                activeBots.push(...mainFolders);
            }
            
            // Sub bots
            const subsDir = path.join(process.cwd(), 'Sessions/Subs');
            if (fs.existsSync(subsDir)) {
                const subFolders = fs.readdirSync(subsDir, { withFileTypes: true })
                    .filter(d => d.isDirectory())
                    .map(folder => folder.name);
                activeBots.push(...subFolders);
            }
            
            // Contar bots en el grupo
            for (const participant of metadata.participants) {
                const participantNumber = participant.id.split('@')[0].replace(/\D/g, '');
                if (activeBots.includes(participantNumber)) {
                    botsInGroup++;
                    botsList.push(participantNumber);
                }
            }

            // 4. Obtener la foto del grupo
            let pp;
            try {
                pp = await sock.profilePictureUrl(from, 'image');
            } catch {
                pp = 'https://telegra.ph/file/241f050c4bcc293340fca.jpg';
            }

            // 5. Construir el mensaje
            const mentionText = primarioJid !== 'aleatorio' ? `@${primarioJid.split('@')[0]}` : 'aleatorio';
            
            let infoText = `
★ ۪ ׄ🍀᪲ ۪࠭ *𝗇ᦅ𝗆bꭇᧉ* › ${metadata.subject}
★ ۪ ׄ🍀᪲ ۪࠭ *ꪱ𝗇ƚᧉgꭇα𝗇ƚᧉ𝗌* › ${metadata.participants.length}
★ ۪ ׄ🍀᪲ ۪࠭ *αd𝗆ꪱ𝗇𝗌* › ${groupAdmins.length}
★ ۪ ׄ🍀᪲ ۪࠭ *bᦅƚ𝗌* › ${botsInGroup}
★ ۪ ׄ🍀᪲ ۪࠭ *ꪱd* › ${from}

★ ۪ ׄ🍀᪲ ۪࠭ *bᦅƚ 𝗉ꭇꪱ𝗆αꭇꪱᦅ* › ${mentionText}
★ ۪ ׄ🍀᪲ ۪࠭ *bᦅƚ𝗇α𝗆ᧉ* › ${primarioNombre}
★ ۪ ׄ🍀᪲ ۪࠭ *ƚꪱ𝗉ᦅ* › ${primarioTipo}`;

            // Agregar descripción al final si existe
            if (metadata.desc && metadata.descId) {
                infoText += `\n\n★ ۪ ׄ🍀᪲ ۪࠭*dᧉ𝗌cꭇꪱ𝗉cꪱó𝗇* ›\n${metadata.desc}`;
            }

            // 6. Enviar mensaje con imagen
            await sock.sendMessage(from, {
                image: { url: pp },
                caption: infoText,
                mentions: primarioJid !== 'aleatorio' ? [primarioJid] : [],
                contextInfo: {
                    mentionedJid: primarioJid !== 'aleatorio' ? [primarioJid] : [],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            console.log(`✅ GroupInfo ejecutado por ${pushName || 'Usuario'} en grupo ${metadata.subject}`);

        } catch (error) {
            console.error('❌ Error en gp:', error);
            await sock.sendMessage(msg.key.remoteJid, { 
                text: `❌ Error: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};
