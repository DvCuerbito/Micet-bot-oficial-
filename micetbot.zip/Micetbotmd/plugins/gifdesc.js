import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ALLOWED_RANKS = ['owner', 'c-owner', 'srmod', 'mod', 'trialmod', 'trial', 'helper', 'applicant'];

export default {
    name: 'gifdesc',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, senderNumber, senderJid, usersDB } = options;
            const from = msg.key.remoteJid;
            
            const userData = usersDB[senderNumber];
            const userRank = userData?.rank;
            const isAllowed = userRank && ALLOWED_RANKS.includes(userRank);
            
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isOwner && !isAllowed) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}gifdesc\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const fullArgs = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const cleanArgs = fullArgs.replace(config.prefix + 'gifdesc', '').trim();

            if (!cleanArgs || !cleanArgs.includes('=')) {
                await sock.sendMessage(from, {
                    text: '☆ Formato: /gifdesc +categoría = +descripción\n> ✐ Ej: /gifdesc +talk = +{user} está hablando con {user2}',
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const parts = cleanArgs.split('=').map(part => part.trim());
            if (parts.length < 2) {
                await sock.sendMessage(from, {
                    text: '☆ Debes especificar categoría y descripción.',
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            let categoryName = parts[0];
            let description = parts[1];

            if (categoryName.startsWith('+')) {
                categoryName = categoryName.substring(1).toLowerCase();
            }
            if (description.startsWith('+')) {
                description = description.substring(1);
            }

            if (!categoryName || !description) {
                await sock.sendMessage(from, {
                    text: '☆ Debes especificar categoría y descripción.',
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const descFile = path.join(__dirname, '..', 'databases', 'gif_descriptions.json');
            let descriptions = {};
            
            if (fs.existsSync(descFile)) {
                descriptions = JSON.parse(fs.readFileSync(descFile, 'utf8'));
            }

            if (!descriptions[categoryName]) {
                descriptions[categoryName] = [];
            }

            const existingDesc = descriptions[categoryName].find(desc => 
                desc.text === description
            );

            if (existingDesc) {
                await sock.sendMessage(from, {
                    text: `❖ Esta descripción ya existe en *${categoryName}*`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const newDescription = {
                text: description,
                addedBy: senderJid,
                addedByNumber: senderNumber,
                addedByName: pushName || senderNumber,
                addedAt: new Date().toLocaleString()
            };

            descriptions[categoryName].push(newDescription);
            fs.writeFileSync(descFile, JSON.stringify(descriptions, null, 2));

            await sock.sendMessage(from, {
                text: `☆ Se ha agregado una nueva descripción a *${categoryName}*\n> 🐞: ${description}\n> 🍬 Agregado por: @${senderNumber}`,
                mentions: [senderJid],
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });

        } catch (error) {
            console.log('Error en comando gifdesc:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: '❖ Error al agregar la descripción.',
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};