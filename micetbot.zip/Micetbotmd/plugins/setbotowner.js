import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'setbotowner',
    alias: ['cambiardueño'],
    
    async execute(sock, msg, options) {
        try {
            const { config, sender, args, senderNumber } = options;
            const from = msg.key.remoteJid;
            
            // ==========================================
            // OBTENER NÚMERO DEL BOT
            // ==========================================
            let botNumber = '';
            if (sock.phoneNumber) {
                botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            if (!botNumber) {
                throw new Error('No se pudo identificar el número del bot');
            }
            
            // ==========================================
            // VERIFICAR SI EL USUARIO ES BOTOWNER O OWNER
            // ==========================================
            const cleanSender = (senderNumber || '').replace(/\D/g, '');
            
            const isBotOwner = config.botowner && 
                              config.botowner.replace(/\D/g, '') === cleanSender;
            
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === cleanSender
            );
            
            // Permitir si es botowner o cualquier owner
            if (!isBotOwner && !isOwner) {
                // Mensaje para no autorizados
                await sock.sendMessage(from, {
                    text: `❀ *Solo el dueño del bot puede transferir la propiedad*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar que se proporcionó un número
            if (!args || args.length === 0) {
                await sock.sendMessage(from, {
                    text: `👑 *Formato incorrecto*\n> Uso: *${config.prefix}setbotowner +número*\n> Ejemplo: *${config.prefix}setbotowner +5219992042946*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Obtener el nuevo número
            let newOwner = args[0];
            
            // Eliminar el '+' si está presente al inicio
            if (newOwner.startsWith('+')) {
                newOwner = newOwner.substring(1).trim();
            }
            
            // Limpiar el número (solo dígitos)
            const cleanNewOwner = newOwner.replace(/\D/g, '');
            
            // Verificar que el número no esté vacío y sea válido
            if (!cleanNewOwner || cleanNewOwner.length < 10) {
                await sock.sendMessage(from, {
                    text: `👑 *Número inválido*\n> Debes proporcionar un número de teléfono válido`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            try {
                console.log(`👑 Usuario autorizado ${senderNumber} está transfiriendo el bot ${botNumber} a ${cleanNewOwner}...`);
                console.log(`   - Es botowner: ${isBotOwner ? 'SÍ' : 'NO'}`);
                console.log(`   - Es owner: ${isOwner ? 'SÍ' : 'NO'}`);
                
                // ==========================================
                // RUTA DEL ARCHIVO DE CONFIGURACIÓN
                // ==========================================
                const configPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
                
                if (!fs.existsSync(configPath)) {
                    throw new Error(`No se encontró configuración para el bot ${botNumber}`);
                }
                
                // Leer el archivo actual
                let configContent = fs.readFileSync(configPath, 'utf8');
                
                // Extraer el objeto JSON
                const jsonMatch = configContent.match(/export default\s+({[\s\S]*})/);
                if (!jsonMatch || !jsonMatch[1]) {
                    throw new Error('Formato de archivo config.js inválido');
                }
                
                // Evaluar el objeto actual
                const currentConfig = eval('(' + jsonMatch[1] + ')');
                
                // ==========================================
                // ACTUALIZAR EL BOTOWNER
                // ==========================================
                const oldOwner = currentConfig.botowner || 'No definido';
                currentConfig.botowner = cleanNewOwner;
                
                console.log(`👑 Actualizando botowner de "${oldOwner}" a "${cleanNewOwner}"`);
                
                // ==========================================
                // GUARDAR EL ARCHIVO ACTUALIZADO
                // ==========================================
                const newConfigContent = `// Configuración del Bot - ${currentConfig.tipo || 'Sub-Bot'}
// Creado para el número: ${botNumber}
// Actualizado el: ${new Date().toLocaleString()}

export default ${JSON.stringify(currentConfig, null, 2)}
`;
                
                fs.writeFileSync(configPath, newConfigContent);
                console.log(`✅ Configuración actualizada para bot ${botNumber}`);
                
                // ==========================================
                // ENVIAR CONFIRMACIÓN
                // ==========================================
                let autorizadoPor = '';
                if (isBotOwner && isOwner) {
                    autorizadoPor = 'dueño del bot y owner';
                } else if (isBotOwner) {
                    autorizadoPor = 'dueño del bot';
                } else if (isOwner) {
                    autorizadoPor = 'owner';
                }
                
                await sock.sendMessage(from, {
                    text: `👑 *Dueño del bot transferido con éxito*\n\n` +
                          `> *Nuevo dueño:* ${cleanNewOwner}\n` +
                          `> *Anterior dueño:* ${oldOwner}\n` +
                          `> *Bot:* ${botNumber}\n` +
                          `> *Autorizado por:* ${autorizadoPor}\n\n` +
                          `✨ El nuevo dueño ahora puede administrar el bot`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
                // También notificar al nuevo dueño si está en el chat
                try {
                    const newOwnerJid = `${cleanNewOwner}@s.whatsapp.net`;
                    await sock.sendMessage(newOwnerJid, {
                        text: `👑 *Has sido designado como nuevo dueño del bot ${botNumber}*\n\n` +
                              `> Transferido por: ${senderNumber}\n` +
                              `> Ahora puedes usar comandos de administración como:\n` +
                              `> ${config.prefix}setbanner\n` +
                              `> ${config.prefix}seticon\n` +
                              `> ${config.prefix}setname\n` +
                              `> ${config.prefix}setbotowner`,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    });
                } catch (notifyError) {
                    console.log('⚠️ No se pudo notificar al nuevo dueño:', notifyError.message);
                }
                
            } catch (error) {
                console.error('Error en setbotowner:', error);
                
                await sock.sendMessage(from, {
                    text: `👑 *Error al transferir la propiedad*\n> ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
        } catch (error) {
            console.error('Error general en setbotowner:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ Error inesperado en setbotowner`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};