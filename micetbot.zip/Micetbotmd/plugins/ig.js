import axios from 'axios';

export default {
    name: 'ig',
    alias: ['instagram', 'reel'],
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, sender } = options;
            const from = msg.key.remoteJid;
            const url = args[0];
            
            if (!url) {
                await sock.sendMessage(from, {
                    text: `♡ Por favor, ingresa un enlace de Instagram\n> Uso: ${config.prefix}ig [enlace]`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            if (!url.includes('instagram.com')) {
                await sock.sendMessage(from, {
                    text: `♡ Eso no parece ser un enlace de Instagram válido`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
            } catch (e) {}
            
            // ============ API PRINCIPAL: OotaIzumi ============
            try {
                console.log(`🔍 Consultando API OotaIzumi...`);
                
                const apiUrl = `https://api.ootaizumi.web.id/downloader/instagram/v1?url=${encodeURIComponent(url)}`;
                
                const response = await axios.get(apiUrl, {
                    timeout: 30000,
                    headers: {
                        'accept': '*/*',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    }
                });
                
                const data = response.data;
                
                if (!data.status || !data.result || !data.result.media || data.result.media.length === 0) {
                    throw new Error('No se encontró contenido');
                }
                
                const mediaList = data.result.media;
                const metadata = data.result.metadata || {};
                const author = metadata.author || 'Instagram';
                
                // Procesar cada media
                for (let i = 0; i < mediaList.length; i++) {
                    const media = mediaList[i];
                    const mediaUrl = media.url;
                    
                    if (!mediaUrl) continue;
                    
                    console.log(`📥 Descargando ${media.isVideo ? 'video' : 'imagen'} ${i + 1}/${mediaList.length}...`);
                    
                    try {
                        const mediaResponse = await axios({
                            method: 'get',
                            url: mediaUrl,
                            responseType: 'arraybuffer',
                            timeout: 60000,
                            headers: {
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                                'Accept': '*/*',
                                'Referer': 'https://www.instagram.com/'
                            }
                        });
                        
                        const mediaBuffer = Buffer.from(mediaResponse.data);
                        
                        const caption = `♡ *Instagram Download*\n> Autor: ${author}\n> ${i + 1}/${mediaList.length}`;
                        
                        if (media.isVideo) {
                            await sock.sendMessage(from, {
                                video: mediaBuffer,
                                caption: caption,
                                mimetype: 'video/mp4',
                                contextInfo: {
                                    forwardingScore: 9999999,
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: 0,
                                        newsletterName: config.canalNombre || ''
                                    }
                                }
                            }, { quoted: msg });
                        } else {
                            await sock.sendMessage(from, {
                                image: mediaBuffer,
                                caption: caption,
                                contextInfo: {
                                    forwardingScore: 9999999,
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: 0,
                                        newsletterName: config.canalNombre || ''
                                    }
                                }
                            }, { quoted: msg });
                        }
                        
                        console.log(`✅ Enviado ${i + 1}/${mediaList.length}`);
                        
                    } catch (mediaError) {
                        console.log(`⚠️ Error con media ${i + 1}:`, mediaError.message);
                    }
                }
                
                try {
                    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
                } catch (e) {}
                
                console.log(`✅ Instagram descargado por ${pushName || sender?.split('@')[0]}`);
                return;
                
            } catch (apiError) {
                console.log('⚠️ API OotaIzumi falló, intentando APIs alternativas...');
                // Continuar con las otras APIs
            }
            
            // ============ APIs ALTERNATIVAS ============
            const APIs = config.APIs || {};
            let videoUrl = null;
            let errorMsg = '';
            
            const apiList = [
                {
                    name: 'Delirius',
                    url: APIs.delirius?.url || 'https://api.delirius.store',
                    endpoint: '/download/instagram',
                    params: { url: url },
                    extractor: (data) => {
                        if (data?.data?.length > 0) return data.data[0].url;
                        if (data?.result?.length > 0) return data.result[0].url;
                        if (data?.url) return data.url;
                        return null;
                    }
                },
                {
                    name: 'Vreden',
                    url: APIs.vreden?.url || 'https://api.vreden.web.id',
                    endpoint: '/api/igdl',
                    params: { url: url },
                    extractor: (data) => {
                        if (data?.status && data?.data?.url) return data.data.url;
                        if (data?.result?.url) return data.result.url;
                        return null;
                    }
                }
            ];
            
            for (const api of apiList) {
                try {
                    console.log(`🔄 Probando API ${api.name}...`);
                    
                    const response = await axios.get(api.url + api.endpoint, { 
                        params: api.params,
                        timeout: 15000,
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    
                    videoUrl = api.extractor(response.data);
                    
                    if (videoUrl) {
                        console.log(`✅ API ${api.name} funcionó!`);
                        break;
                    }
                    
                } catch (error) {
                    console.log(`❌ API ${api.name} falló:`, error.message);
                    errorMsg = error.message;
                }
            }
            
            if (!videoUrl) {
                try { await sock.sendMessage(from, { react: { text: '❌', key: msg.key } }); } catch (e) {}
                await sock.sendMessage(from, {
                    text: `♡ No se pudo obtener el contenido\n> Motivo: ${errorMsg || 'APIs no disponibles'}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Descargar y enviar video
            const videoResponse = await axios({
                method: 'get',
                url: videoUrl,
                responseType: 'arraybuffer',
                timeout: 60000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Referer': 'https://www.instagram.com/'
                }
            });
            
            const videoBuffer = Buffer.from(videoResponse.data);
            
            await sock.sendMessage(from, {
                video: videoBuffer,
                mimetype: 'video/mp4',
                caption: '♡ *Instagram Download*',
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try { await sock.sendMessage(from, { react: { text: '✅', key: msg.key } }); } catch (e) {}
            
        } catch (error) {
            console.error('❌ Error en comando ig:', error);
            
            try { await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } }); } catch (e) {}
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `♡ Ocurrió un error: ${error.message}`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};