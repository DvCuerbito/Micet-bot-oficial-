import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'newgroup',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // Lista de rangos permitidos
            const ALLOWED_RANKS = ['owner', 'c-owner', 'srmod', 'mod'];
            
            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}newgroup\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            // Verificar permisos
            const userData = usersDB[senderNumber];
            const userRank = userData?.rank;
            const hasAllowedRank = userRank && ALLOWED_RANKS.includes(userRank);
            
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isOwner && !hasAllowedRank) {
                await sock.sendMessage(from, { 
                    text: `🌸 El comando \`${config.prefix}newgroup\` no existe.\n\n> Usa \`${config.prefix}allmenu\` para ver los comandos disponibles.`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            if (!args || args.length === 0) {
                await sock.sendMessage(from, {
                    text: `🌸 Debes proporcionar un nombre para el grupo.\n\nEjemplo: ${config.prefix}newgroup Mi Grupo Oficial`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const groupName = args.join(' ').trim();
            
            if (!groupName) {
                await sock.sendMessage(from, {
                    text: `🌸 El nombre del grupo no puede estar vacío.`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            await sock.sendMessage(from, {
                react: { text: "🌸", key: msg.key }
            });

            // Mensaje de espera
            await sock.sendMessage(from, {
                text: `🌸 Creando grupo "${groupName}"...`,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });

            try {
                console.log(`🔄 Creando grupo: "${groupName}"`);
                console.log(`👤 Usuario: ${senderNumber}`);
                
                // Crear grupo
                const group = await sock.groupCreate(groupName, []);
                
                console.log(`✅ Grupo creado: ${group.id}`);
                
                const groupId = group.id;
                
                // Esperar un momento para que el grupo se estabilice
                await new Promise(resolve => setTimeout(resolve, 2000));
                
                // Descripción del grupo
                const groupDesc = `🦋 New group - Moonlight Studios`;
                
                // Actualizar la descripción del grupo
                try {
                    await sock.groupUpdateDescription(groupId, groupDesc);
                    console.log(`✅ Descripción actualizada`);
                } catch (descError) {
                    console.log('Error actualizando descripción:', descError.message);
                }
                
                // Ruta de la imagen icon.jpg
                const imagePath = path.join(__dirname, '..', 'img', 'icon.jpg');
                
                // Cambiar la foto del grupo
                try {
                    if (fs.existsSync(imagePath)) {
                        const imageBuffer = fs.readFileSync(imagePath);
                        await sock.updateProfilePicture(groupId, imageBuffer);
                        console.log(`✅ Foto de grupo actualizada con icon.jpg`);
                    } else {
                        console.log(`⚠️ No se encontró icon.jpg en: ${imagePath}`);
                    }
                } catch (imageError) {
                    console.log('Error cambiando foto del grupo:', imageError.message);
                }
                
                // Obtener el enlace de invitación
                let inviteCode;
                try {
                    inviteCode = await sock.groupInviteCode(groupId);
                    console.log(`🔗 Código obtenido: ${inviteCode}`);
                } catch (inviteError) {
                    console.log('Error obteniendo código de invitación:', inviteError.message);
                    
                    try {
                        // Intentar regenerar el enlace
                        await sock.groupSettingUpdate(groupId, 'announcement');
                        await new Promise(resolve => setTimeout(resolve, 1000));
                        await sock.groupSettingUpdate(groupId, 'not_announcement');
                        await new Promise(resolve => setTimeout(resolve, 1000));
                        
                        inviteCode = await sock.groupInviteCode(groupId);
                        console.log(`🔗 Código regenerado: ${inviteCode}`);
                    } catch (retryError) {
                        console.error('Error al regenerar código:', retryError);
                        inviteCode = null;
                    }
                }
                
                const groupLink = inviteCode 
                    ? `https://chat.whatsapp.com/${inviteCode}`
                    : 'No disponible (el bot necesita ser admin para obtener el enlace)';
                
                // Mensaje de respuesta
                const responseText = `🌠 Nuevo grupo creado\n\n> Link » ${groupLink}\n> Nombre » ${groupName}`;
                
                await sock.sendMessage(from, {
                    text: responseText,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
                await sock.sendMessage(from, {
                    react: { text: "🌸", key: msg.key }
                });
                
                console.log(`✅ Grupo "${groupName}" creado por ${pushName || senderNumber}`);
                console.log(`🔗 Link: ${groupLink}`);
                
            } catch (createError) {
                console.error('❌ Error creando grupo:', createError);
                
                await sock.sendMessage(from, {
                    text: `🌸 Error al crear el grupo: ${createError.message}`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                
                await sock.sendMessage(from, {
                    react: { text: "❌", key: msg.key }
                });
            }

        } catch (error) {
            console.error('❌ Error en comando newgroup:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `🌸 Error: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};
