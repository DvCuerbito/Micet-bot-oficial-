import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ID del owner permitido
const OWNER_ID = "5219992042946";

export default {
    name: 'getcode',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { args, config, senderNumber } = options;
            const from = msg.key.remoteJid;
            
            // Verificar que sea el owner
            if (senderNumber !== OWNER_ID) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}getcode\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar que se proporcionó un nombre de archivo
            if (!args || args.length === 0) {
                await sock.sendMessage(from, {
                    text: '🌾 *ᴅᴇʙᴇs ᴘʀᴏᴘᴏʀᴄɪᴏɴᴀʀ ᴇʟ ɴᴏᴍʙʀᴇ ᴅᴇ ᴜɴ ᴀʀᴄʜɪᴠᴏ*\n\n> Ejemplo: $getcode plugins/ping.js\n> Ejemplo: $getcode handler.js',
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            const fileName = args[0].trim();
            
            // Obtener ruta base (directorio raíz del proyecto)
            const baseDir = path.resolve(__dirname, '..');
            let filePath;
            
            // Si el archivo tiene una ruta relativa
            if (fileName.includes('/') || fileName.includes('\\')) {
                filePath = path.join(baseDir, fileName);
            } else {
                // Buscar en diferentes carpetas comunes
                const possiblePaths = [
                    path.join(baseDir, fileName),
                    path.join(baseDir, 'plugins', fileName),
                    path.join(baseDir, 'lib', fileName),
                    path.join(baseDir, 'utils', fileName),
                    path.join(baseDir, 'handlers', fileName),
                    path.join(baseDir, 'databases', fileName),
                    path.join(baseDir, 'temp', fileName)
                ];
                
                // Encontrar la primera ruta que existe
                for (const possiblePath of possiblePaths) {
                    if (fs.existsSync(possiblePath) && fs.statSync(possiblePath).isFile()) {
                        filePath = possiblePath;
                        break;
                    }
                }
                
                // Si no se encontró, usar la ruta en plugins
                if (!filePath) {
                    filePath = path.join(baseDir, 'plugins', fileName);
                }
            }
            
            // Verificar si el archivo existe
            if (!fs.existsSync(filePath)) {
                await sock.sendMessage(from, {
                    text: `🌴 *ᴇʟ ᴀʀᴄʜɪᴠᴏ* \`${fileName}\` *ɴᴏ ᴇxɪsᴛᴇ*\n\n📁 *Rutas buscadas:*\n- plugins/${fileName}\n- lib/${fileName}\n- ${fileName}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar que sea un archivo
            const stats = fs.statSync(filePath);
            if (!stats.isFile()) {
                await sock.sendMessage(from, {
                    text: `🌴 *${fileName}* ɴᴏ ᴇs ᴜɴ ᴀʀᴄʜɪᴠᴏ ᴠᴀ́ʟɪᴅᴏ`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar tamaño del archivo (máx 5MB para evitar problemas)
            const fileSizeMB = stats.size / (1024 * 1024);
            if (fileSizeMB > 5) {
                await sock.sendMessage(from, {
                    text: `🌴 *ᴇʟ ᴀʀᴄʜɪᴠᴏ ᴇs ᴅᴇᴍᴀsɪᴀᴅᴏ ɢʀᴀɴᴅᴇ* (${fileSizeMB.toFixed(2)}MB)\n> Máximo permitido: 5MB`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Leer el contenido del archivo
            const fileContent = fs.readFileSync(filePath, 'utf8');
            
            // Enviar el código
            await sock.sendMessage(from, {
                text: fileContent,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
            
            console.log(`[GETCODE] Archivo enviado: ${filePath} (${stats.size} bytes)`);
            
        } catch (error) {
            console.error('[GETCODE] Error:', error);
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `🌴 *ᴇʀʀᴏʀ:* ${error.message}`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};