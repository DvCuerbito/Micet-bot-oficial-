export default {
    name: 'invocar',
    alias: ['tagall'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar si es un grupo
            if (!from.includes('@g.us')) {
                await sock.sendMessage(from, { 
                    text: `♡ Este comando solo puede usarse en grupos`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            try {
                const groupMetadata = await sock.groupMetadata(from);
                const participants = groupMetadata.participants;
                const botJid = sock.user.id;
                
                // Verificar si el usuario es admin del grupo
                const isGroupAdmin = participants.find(p => {
                    if (p.id === senderJid) return true;
                    if (p.id.includes(senderNumber || '')) return true;
                    if (senderJid && senderJid.includes('@lid')) {
                        const senderNum = senderJid.split('@')[0];
                        if (p.id.includes(senderNum)) return true;
                    }
                    return false;
                })?.admin;
                
                // Verificar si es owner del bot
                const isOwner = config.owner && config.owner.some(ownerNum => 
                    ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
                );
                
                if (!isGroupAdmin && !isOwner) {
                    await sock.sendMessage(from, { 
                        text: `🍉 *Debes ser administrador para usar este comando*`,
                        contextInfo: {
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            },
                            forwardingScore: 9999999,
                            isForwarded: true
                        }
                    }, { quoted: msg });
                    return;
                }
                
                // Obtener la razón (todo el texto después del comando)
                const razon = args.join(' ').trim();
                
                const groupName = groupMetadata.subject;
                
                // Filtrar participantes (excluir al bot)
                const participantsList = participants
                    .filter(p => p.id !== botJid && p.id !== botJid?.split(':')[0] + '@s.whatsapp.net')
                    .map(participant => `🍧 @${participant.id.split('@')[0]}`);
                
                if (participantsList.length === 0) {
                    await sock.sendMessage(from, { 
                        text: `🍉 No hay participantes para mencionar.`,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    return;
                }
                
                // Construir mensaje con razón si existe
                let responseText = `꒰ ${groupName} ꒱\n`;
                responseText += `ൕ *Invocación a todo el grupo*\n`;
                
                if (razon) {
                    responseText += `\n📢 *Razón:* ${razon}\n`;
                }
                
                responseText += `\n${participantsList.join('\n')}`;
                
                // Obtener todos los JIDs para menciones
                const mentionJids = participants
                    .filter(p => p.id !== botJid && p.id !== botJid?.split(':')[0] + '@s.whatsapp.net')
                    .map(p => p.id);

                await sock.sendMessage(from, { 
                    text: responseText, 
                    mentions: mentionJids,
                    contextInfo: {
                        mentionedJid: mentionJids,
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
                console.log(`✅ Invocación enviada por ${pushName || senderNumber}${razon ? ` - Razón: ${razon}` : ''}`);
                
            } catch (error) {
                console.error('Error en comando invocar:', error);
                await sock.sendMessage(from, { 
                    text: `🌿 *Ocurrió un error: ${error.message}*`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            }
            
        } catch (error) {
            console.error('❌ Error en invocar:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { 
                    text: `🌿 *Ocurrió un error: ${error.message}*`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};