import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { downloadMediaMessage } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
  name: 'setpfp',
  alias: ['cambiarfoto', 'setfoto'],
  
  async execute(sock, msg, options) {
    try {
      const { config, senderNumber, senderJid } = options;
      const from = msg.key.remoteJid;
      
      let botNumber = '';
      if (sock.phoneNumber) {
        botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
      } else if (sock.user?.id) {
        botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
      }
      
      const isBotOwner = config.botowner && 
                        config.botowner.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '');

      if (!isBotOwner) {
        return await sock.sendMessage(from, { 
          text: '❀ *Solo el dueño del bot puede cambiar su foto de perfil*'
        }, { quoted: msg });
      }

      const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

      if (!quoted) {
        return await sock.sendMessage(from, { 
          text: `🪷 *Debes responder a una imagen*`
        }, { quoted: msg });
      }

      const messageType = Object.keys(quoted)[0];
      if (messageType !== 'imageMessage') {
        return await sock.sendMessage(from, { 
          text: `🪷 *Debes responder a una imagen*\n> El mensaje citado no es una imagen.`
        }, { quoted: msg });
      }

      try {
        const quotedMsg = {
          key: {
            remoteJid: from,
            id: msg.message.extendedTextMessage.contextInfo.stanzaId,
            participant: msg.message.extendedTextMessage.contextInfo.participant || senderJid,
            fromMe: false
          },
          message: {
            imageMessage: quoted.imageMessage
          }
        };

        const buffer = await downloadMediaMessage(
          quotedMsg,
          'buffer',
          {},
          {
            logger: console,
            reuploadRequest: sock.updateMediaMessage
          }
        );

        if (!buffer || buffer.length === 0) {
          throw new Error('No se pudo descargar la imagen');
        }

        await sock.updateProfilePicture(sock.user.id, buffer);

        await sock.sendMessage(from, { 
          text: `🌸 *Foto de perfil cambiada con éxito*\n> Por el dueño del bot`
        }, { quoted: msg });
        
      } catch (error) {
        console.error('Error en comando setpfp:', error);
        await sock.sendMessage(from, { 
          text: `🪷 *Error al procesar la imagen*\n> ${error.message}`
        }, { quoted: msg });
      }
      
    } catch (error) {
      console.error('Error en setpfp:', error);
      await sock.sendMessage(msg.key.remoteJid, { 
        text: `🪷 *Error:* ${error.message}`
      }, { quoted: msg });
    }
  }
};