import axios from 'axios';

const APIS = [
    {
        name: 'Varhad',
        url: 'https://v2.api-varhad.my.id/ai/gemini',
        param: 'prompt',
        getAnswer: (data) => data?.result?.text
    },
    {
        name: 'NeoAPIs',
        url: 'https://www.neoapis.xyz/api/ai/gemini',
        param: 'text',
        getAnswer: (data) => data?.data?.answer
    },
    {
        name: 'NexRay',
        url: 'https://api.nexray.web.id/ai/gemini',
        param: 'text',
        getAnswer: (data) => data?.result
    }
];

export default {
    name: 'ai',
    alias: ['gemini', 'ia'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const prompt = args.join(' ').trim();
            
            if (!prompt) {
                await replyWithContext(
                    `[ ★ ] Debes proporcionar una pregunta para Gemini`,
                    []
                );
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🙀', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(`[ ★ ] *Pensando...*\n> ${prompt.substring(0, 50)}${prompt.length > 50 ? '...' : ''}`, []);
            
            let answer = null;
            let usedApi = '';
            
            // Intentar con cada API
            for (const api of APIS) {
                try {
                    console.log(`🤖 Intentando API ${api.name}...`);
                    
                    const response = await axios.get(`${api.url}?${api.param}=${encodeURIComponent(prompt)}`, {
                        timeout: 60000,
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                            'Accept': 'application/json'
                        }
                    });
                    
                    answer = api.getAnswer(response.data);
                    
                    if (answer) {
                        usedApi = api.name;
                        console.log(`✅ Respuesta obtenida de ${api.name}`);
                        break;
                    }
                    
                } catch (error) {
                    console.log(`⚠️ API ${api.name} falló: ${error.message}`);
                    continue;
                }
            }
            
            if (!answer) {
                throw new Error('Todas las APIs fallaron');
            }
            
            if (answer.length > 3000) {
                answer = answer.substring(0, 3000) + '\n\n... (respuesta truncada)';
            }
            
            await replyWithContext(
                `[ ★ ] *Gemini:*\n\`\`\`${answer}\`\`\``,
                []
            );
            
            try {
                await sock.sendMessage(from, { react: { text: '🌟', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ AI respondida con ${usedApi} para ${pushName || senderJid}`);
            
        } catch (error) {
            console.error('❌ Error en ai:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(
                `[ ★ ] *Error:* No se pudo obtener respuesta. Intenta más tarde.`,
                []
            );
        }
    }
};