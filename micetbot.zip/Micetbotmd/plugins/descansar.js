import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 0,
            minerals: {},
            health: 100,
            mana: 50,
            items: {}
        };
    }
    return economy[userNumber];
}

function getRemainingTime(lastUsed, cooldownMs = 300000) { // 5 minutos
    const now = Date.now();
    const timePassed = now - lastUsed;
    if (timePassed >= cooldownMs) return 0;
    const remaining = cooldownMs - timePassed;
    const minutes = Math.floor(remaining / 60000);
    const seconds = Math.floor((remaining % 60000) / 1000);
    return `${minutes}m ${seconds}s`;
}

export default {
    name: 'descansar',
    alias: ['rest', 'meditar'],
    
    async execute(sock, msg, options) {
        try {
            const { 
                config, 
                senderNumber, 
                pushName,
                replyWithContext,
                senderJid 
            } = options;
            
            if (!senderNumber) {
                return await replyWithContext(
                    '❌ No se pudo identificar tu número',
                    [senderJid]
                );
            }
            
            let economy = loadEconomy();
            const user = initUserEconomy(economy, senderNumber, pushName);
            
            if (!user.mana) user.mana = 50;
            if (!user.lastRest) user.lastRest = 0;
            
            const now = Date.now();
            const cooldownTime = 300000; // 5 minutos
            
            if (user.lastRest && (now - user.lastRest) < cooldownTime) {
                const remaining = getRemainingTime(user.lastRest, cooldownTime);
                return await replyWithContext(
                    `⏳ *Debes esperar ${remaining}* para descansar nuevamente`,
                    [senderJid]
                );
            }
            
            if (user.mana >= 100) {
                return await replyWithContext(
                    '🔮 *Ya tienes el maná al máximo*',
                    [senderJid]
                );
            }
            
            user.lastRest = now;
            
            const manaRecuperado = Math.floor(Math.random() * 20) + 15; // 15-35 maná
            const manaAnterior = user.mana;
            user.mana = Math.min(100, user.mana + manaRecuperado);
            const manaReal = user.mana - manaAnterior;
            
            saveEconomy(economy);
            
            const bars = '🔮'.repeat(Math.floor(user.mana / 10)) + '⚫'.repeat(10 - Math.floor(user.mana / 10));
            
            await replyWithContext(
                `🧘 *DESCANSO*\n\n` +
                `> Recuperaste: *+${manaReal}* 🔮 Maná\n` +
                `> Maná actual: *${user.mana}*/100\n` +
                `${bars}`,
                [senderJid]
            );
            
        } catch (error) {
            console.error('❌ Error en comando descansar:', error);
        }
    }
};
