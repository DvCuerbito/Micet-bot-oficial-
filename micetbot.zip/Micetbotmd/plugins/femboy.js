export default {
    name: 'femboy',
    alias: ['fem'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            console.log(`🌸 Comando femboy ejecutado por: ${senderNumber}`);

            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            let targetUserJid = senderJid;
            let targetUserNumber = senderNumber;

            // Verificar si hay mención
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
                targetUserNumber = targetUserJid.split('@')[0];
                console.log(`✅ Usuario mencionado: ${targetUserNumber}`);
            }
            // Verificar si es respuesta
            else if (msg.message?.extendedTextMessage?.contextInfo?.stanzaId) {
                const quotedMsg = msg.message.extendedTextMessage.contextInfo;
                if (quotedMsg.participant) {
                    targetUserJid = quotedMsg.participant;
                    targetUserNumber = targetUserJid.split('@')[0];
                }
                console.log(`✅ Usuario por respuesta: ${targetUserNumber}`);
            }

            // Obtener nombre del usuario objetivo
            const targetName = usersDB[targetUserNumber]?.pushName || 
                              usersDB[targetUserNumber]?.name || 
                              targetUserNumber;

            // Verificación especial para el usuario 42211290910827@lid
            const isSpecialUser = targetUserNumber === '42211290910827';
            
            // Calcular porcentaje (si es el usuario especial, siempre 100%)
            let porcentaje;
            if (isSpecialUser) {
                porcentaje = 100;
                console.log(`🎯 Usuario especial detectado: 100% femboy`);
            } else {
                // Calcular porcentaje pseudo-aleatorio basado en el ID del usuario
                let hash = 0;
                for (let i = 0; i < targetUserNumber.length; i++) {
                    hash = ((hash << 7) - hash) + targetUserNumber.charCodeAt(i);
                    hash = hash & hash;
                }
                porcentaje = Math.abs(hash) % 101;
                console.log(`📊 Porcentaje femboy calculado: ${porcentaje}%`);
            }

            // Textos dinámicos según el porcentaje
            let textoDinamico = "";
            if (porcentaje <= 10) {
                textoDinamico = "🍭 Eres más macho que un león";
            } else if (porcentaje <= 20) {
                textoDinamico = "💪 Tu masculinidad es inquebrantable";
            } else if (porcentaje <= 30) {
                textoDinamico = "🌸 Tienes un toque delicado";
            } else if (porcentaje <= 40) {
                textoDinamico = "🎀 Comienzas a apreciar lo kawaii";
            } else if (porcentaje <= 50) {
                textoDinamico = "👗 Te ves bien de rosado";
            } else if (porcentaje <= 60) {
                textoDinamico = "💅 Tu estilo es andrógino";
            } else if (porcentaje <= 70) {
                textoDinamico = "✨ Tienes esencia femboy";
            } else if (porcentaje <= 80) {
                textoDinamico = "🎭 Dominas el arte femboy";
            } else if (porcentaje <= 90) {
                textoDinamico = "🌙 Eres casi un femboy profesional";
            } else {
                textoDinamico = "💖 Eres la definición de femboy";
            }

            // Enviar mensaje de cálculo con las 5 ediciones
            const progressMessages = [
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 20%`,
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 40%`,
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 60%`,
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 80%`,
                `*ׄ─ׄ𖤐─ׄ* 100%`
            ];

            console.log(`🔄 Iniciando cálculo femboy para: ${targetName}`);

            // Enviar primer mensaje de progreso
            const progressMsg = await sock.sendMessage(from, { 
                text: `🍡 *Analizando esencia femboy...*\n\n${progressMessages[0]}`,
                contextInfo: {
                    mentionedJid: [targetUserJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            });

            // Editar el mensaje 4 veces más con delay
            for (let i = 1; i < progressMessages.length; i++) {
                await new Promise(resolve => setTimeout(resolve, 1000));
                await sock.sendMessage(from, { 
                    text: `🍡 *Analizando esencia femboy...*\n\n${progressMessages[i]}`,
                    edit: progressMsg.key,
                    contextInfo: {
                        mentionedJid: [targetUserJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                });
                console.log(`📝 Editando mensaje ${i + 1}/5`);
            }

            // Esperar un poco antes del resultado final
            await new Promise(resolve => setTimeout(resolve, 1500));

            // Eliminar mensaje de progreso
            await sock.sendMessage(from, { 
                delete: progressMsg.key 
            });

            // Enviar resultado final
            const resultadoFinal = `💐 Calculo terminado de @${targetUserNumber}

🍭 Porcentaje Femboy : ${porcentaje}% 
> 🎀 *${textoDinamico}*`;

            await sock.sendMessage(from, {
                text: resultadoFinal,
                contextInfo: {
                    mentionedJid: [targetUserJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            console.log(`🎉 Cálculo femboy completado: ${targetName} = ${porcentaje}%`);

        } catch (error) {
            console.error(`❌ Error en comando femboy:`, error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { 
                    text: `🌸 Error al calcular el nivel femboy: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};