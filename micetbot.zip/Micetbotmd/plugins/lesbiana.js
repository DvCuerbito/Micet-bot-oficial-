export default {
    name: 'lesbiana',
    alias: ['les'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            console.log(`💜 Comando lesbiana ejecutado por: ${senderNumber}`);

            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            let targetUserJid = senderJid;
            let targetUserNumber = senderNumber;

            // Verificar si hay mención
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
                targetUserNumber = targetUserJid.split('@')[0];
                console.log(`✅ Usuario mencionado: ${targetUserNumber}`);
            }
            // Verificar si es respuesta
            else if (msg.message?.extendedTextMessage?.contextInfo?.stanzaId) {
                const quotedMsg = msg.message.extendedTextMessage.contextInfo;
                if (quotedMsg.participant) {
                    targetUserJid = quotedMsg.participant;
                    targetUserNumber = targetUserJid.split('@')[0];
                }
                console.log(`✅ Usuario por respuesta: ${targetUserNumber}`);
            }

            // Obtener nombre del usuario objetivo
            const targetName = usersDB[targetUserNumber]?.pushName || 
                              usersDB[targetUserNumber]?.name || 
                              targetUserNumber;

            // Verificación especial para el usuario 42211290910827
            const isSpecialUser = targetUserNumber === '42211290910827';
            
            // Calcular porcentaje (si es el usuario especial, siempre 100%)
            let porcentaje;
            if (isSpecialUser) {
                porcentaje = 100;
                console.log(`🎯 Usuario especial detectado: 100% lesbiana`);
            } else {
                // Calcular porcentaje pseudo-aleatorio basado en el número del usuario
                let hash = 0;
                for (let i = 0; i < targetUserNumber.length; i++) {
                    hash = ((hash << 6) - hash) + targetUserNumber.charCodeAt(i);
                    hash = hash & hash;
                }
                porcentaje = Math.abs(hash) % 101;
                console.log(`📊 Porcentaje lesbiana calculado: ${porcentaje}%`);
            }

            // Textos dinámicos según el porcentaje
            let textoDinamico = "";
            if (porcentaje <= 10) {
                textoDinamico = "💙 Tu radar femenino está apagado";
            } else if (porcentaje <= 20) {
                textoDinamico = "👩‍❤️‍👩 Comienzas a notar la belleza femenina";
            } else if (porcentaje <= 30) {
                textoDinamico = "🌸 Tienes curiosidad por las mujeres";
            } else if (porcentaje <= 40) {
                textoDinamico = "💮 Tu sapphic energy está creciendo";
            } else if (porcentaje <= 50) {
                textoDinamico = "🌈 Reconoces la atracción femenina";
            } else if (porcentaje <= 60) {
                textoDinamico = "👭 Prefieres la compañía femenina";
            } else if (porcentaje <= 70) {
                textoDinamico = "💕 Tu corazón late por mujeres";
            } else if (porcentaje <= 80) {
                textoDinamico = "🌺 Tienes esencia lesbiana natural";
            } else if (porcentaje <= 90) {
                textoDinamico = "✨ Eres casi un ícono lesbiano";
            } else {
                textoDinamico = "💖 Eres la reina del arcoíris femenino";
            }

            // Enviar mensaje de cálculo con las 5 ediciones
            const progressMessages = [
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 20%`,
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 40%`,
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 60%`,
                `*ׄ─ׄ𖤐─ׄ─ׅ─ׄ𖤐─ׄ* 80%`,
                `*ׄ─ׄ𖤐─ׄ* 100%`
            ];

            console.log(`🔄 Iniciando cálculo lesbiana para: ${targetName}`);

            // Enviar primer mensaje de progreso
            const progressMsg = await sock.sendMessage(from, { 
                text: `💜 *Analizando energía lesbiana...*\n\n${progressMessages[0]}`,
                contextInfo: {
                    mentionedJid: [targetUserJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            });

            // Editar el mensaje 4 veces más con delay
            for (let i = 1; i < progressMessages.length; i++) {
                await new Promise(resolve => setTimeout(resolve, 1000));
                await sock.sendMessage(from, { 
                    text: `💜 *Analizando energía lesbiana...*\n\n${progressMessages[i]}`,
                    edit: progressMsg.key,
                    contextInfo: {
                        mentionedJid: [targetUserJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                });
                console.log(`📝 Editando mensaje ${i + 1}/5`);
            }

            // Esperar un poco antes del resultado final
            await new Promise(resolve => setTimeout(resolve, 1500));

            // Eliminar mensaje de progreso
            await sock.sendMessage(from, { 
                delete: progressMsg.key 
            });

            // Enviar resultado final
            const resultadoFinal = `💐 Calculo terminado de @${targetUserNumber}

🍭 Porcentaje Lesbiana : ${porcentaje}% 
> 💜 *${textoDinamico}*`;

            await sock.sendMessage(from, {
                text: resultadoFinal,
                contextInfo: {
                    mentionedJid: [targetUserJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            console.log(`🎉 Cálculo lesbiana completado: ${targetName} = ${porcentaje}%`);

        } catch (error) {
            console.error(`❌ Error en comando lesbiana:`, error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { 
                    text: `🌸 Error al calcular el nivel lesbiana: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};