import fs from 'fs';
import path from 'path';
import os from 'os';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Cargar base de datos de usuarios
const loadUsersDB = () => {
    try {
        const usersFile = path.join(__dirname, '..', 'databases', 'users.json');
        if (fs.existsSync(usersFile)) {
            const data = fs.readFileSync(usersFile, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando users.json:', error);
    }
    return {};
};

// Cargar base de datos de niveles (para total de comandos)
const loadLevelDB = () => {
    try {
        const levelFile = path.join(__dirname, '..', 'databases', 'level.json');
        if (fs.existsSync(levelFile)) {
            const data = fs.readFileSync(levelFile, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando level.json:', error);
    }
    return {};
};

// Obtener total de comandos usados
const getTotalCommandsUsed = () => {
    try {
        const levelDB = loadLevelDB();
        let total = 0;
        for (const user of Object.values(levelDB)) {
            if (user.commands) total += user.commands;
        }
        return total;
    } catch (error) {
        console.error('Error contando comandos:', error);
        return 0;
    }
};

// Obtener total de sub-bots activos
const getTotalSubBots = () => {
    try {
        let total = 0;
        if (global.conns && Array.isArray(global.conns)) {
            total += global.conns.length;
        }
        return total;
    } catch (error) {
        console.error('Error contando sub-bots:', error);
        return 0;
    }
};

// Obtener uso de disco (solo para Linux/Android)
const getDiskUsage = () => {
    try {
        const { execSync } = require('child_process');
        const stdout = execSync('df -h /data 2>/dev/null || df -h / 2>/dev/null').toString();
        const lines = stdout.trim().split('\n');
        if (lines.length > 1) {
            const parts = lines[1].split(/\s+/);
            if (parts.length >= 4) {
                return `${parts[2]} / ${parts[3]}`;
            }
        }
        return 'N/A';
    } catch (error) {
        return 'N/A';
    }
};

export default {
    name: 'status',
    alias: ['estado', 'system'],
    
    async execute(sock, msg, options) {
        try {
            const { config } = options;
            const from = msg.key.remoteJid;
            
            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);
            
            // ========== OBTENER DATOS ==========
            
            // Registros (total de usuarios registrados)
            const usersDB = loadUsersDB();
            const totalRegistros = Object.keys(usersDB).length;
            
            // Total de comandos usados
            const totalComandos = getTotalCommandsUsed();
            
            // Total de sub-bots activos
            const totalSubBots = getTotalSubBots();
            
            // Versión de Node.js
            const nodeVersion = process.version;
            
            // Plataforma (sistema operativo)
            let platform = os.platform();
            if (platform === 'linux') platform = '🐧 Linux';
            else if (platform === 'android') platform = '📱 Android';
            else if (platform === 'darwin') platform = '🍎 macOS';
            else if (platform === 'win32') platform = '🪟 Windows';
            else platform = platform.charAt(0).toUpperCase() + platform.slice(1);
            
            // Memoria RAM
            const totalRam = Math.round(os.totalmem() / (1024 * 1024));
            const freeRam = Math.round(os.freemem() / (1024 * 1024));
            const usedRam = totalRam - freeRam;
            const ramUsedPercent = Math.round((usedRam / totalRam) * 100);
            
            // CPU
            const cpuUsage = os.loadavg()[0];
            const cpuPercent = Math.round(cpuUsage * 10);
            const cpuCores = os.cpus().length;
            
            // Uso de disco
            const diskUsage = getDiskUsage();
            
            // ========== CONSTRUIR MENSAJE ==========
            
            const message = `▒𓂂⃞꥓ֵ݀❀꯭۟ై᮫࠭  *Registros* » ${totalRegistros}\n` +
                          `▒𓂂⃞꥓ֵ݀❀꯭۟ై᮫࠭  *Comandos* » ${totalComandos.toLocaleString()}\n` +
                          `▒𓂂⃞꥓ֵ݀❀꯭۟ై᮫࠭  *Sub-Bots* » ${totalSubBots}\n\n` +
                          `*( ͜͡ ᮫۟  ͜͡ ᤲ𖹭 ͜͡͡ ᮫໋  ͜͡ )꫶᮫ ( ᮫͜͡   ͜͡ ᤲ۟𖹭 ᮫໋͜͡͡   ͜͡ᤲ )᮫۟*\n\n` +
                          `▒𓂂⃞꥓ֵ݀❀꯭۟ై᮫࠭ *NodeJs* » ${nodeVersion}\n` +
                          `▒𓂂⃞꥓ֵ݀❀꯭۟ై᮫࠭ *Plataforma* » ${platform}\n` +
                          `▒𓂂⃞꥓ֵ݀❀꯭۟ై᮫࠭ *Ram usado* » ${usedRam} MB (${ramUsedPercent}%)\n` +
                          `▒𓂂⃞꥓ֵ݀❀꯭۟ై᮫࠭ *Ram libre* » ${freeRam} MB\n` +
                          `▒𓂂⃞꥓ֵ݀❀꯭۟ై᮫࠭ *CPU* » ${cpuPercent}%\n` +
                          `▒𓂂⃞꥓ֵ݀❀꯭۟ై᮫࠭ *Núcleos* » ${cpuCores}\n` +
                          `▒𓂂⃞꥓ֵ݀❀꯭۟ై᮫࠭ *Disk* » ${diskUsage}`;
            
            // ========== ENVIAR MENSAJE ==========
            await sock.sendMessage(from, {
                text: message,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            console.log(`📊 Status ejecutado - Registros: ${totalRegistros}, Comandos: ${totalComandos}, Sub-Bots: ${totalSubBots}`);
            
        } catch (error) {
            console.error('❌ Error en comando status:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ Error al obtener estado del sistema: ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
};