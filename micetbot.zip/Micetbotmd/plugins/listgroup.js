import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function cleanNumber(num) {
    if (!num) return '';
    return num.toString().replace(/[^0-9]/g, '');
}

export default {
    name: 'listgroup',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const OWNER_ID = '5219992042946';
            const cleanSenderNumber = cleanNumber(senderNumber);
            
            // Verificar que sea el owner
            if (cleanSenderNumber !== OWNER_ID) {
                await replyWithContext(
                    `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}listgroup\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help`,
                    []
                );
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📋', key: msg.key } });
            } catch (e) {}
            
            // Obtener número del bot
            let botNumber = '';
            if (sock.phoneNumber) {
                botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            // Obtener todos los chats del bot
            const chats = await sock.groupFetchAllParticipating();
            
            const grupos = [];
            let chatsPrivados = 0;
            
            for (const [jid, chat] of Object.entries(chats)) {
                if (jid.endsWith('@g.us')) {
                    try {
                        const groupMetadata = await sock.groupMetadata(jid);
                        let groupLink = '';
                        
                        // Intentar obtener el link del grupo
                        try {
                            const inviteCode = await sock.groupInviteCode(jid);
                            groupLink = `https://chat.whatsapp.com/${inviteCode}`;
                        } catch (linkError) {
                            groupLink = 'No disponible (sin invitación)';
                        }
                        
                        grupos.push({
                            id: jid,
                            name: groupMetadata.subject || 'Sin nombre',
                            members: groupMetadata.participants?.length || 0,
                            link: groupLink,
                            owner: groupMetadata.owner || 'No disponible'
                        });
                    } catch (error) {
                        console.error(`Error obteniendo metadata del grupo ${jid}:`, error.message);
                        grupos.push({
                            id: jid,
                            name: 'Error al obtener nombre',
                            members: 0,
                            link: 'No disponible',
                            owner: 'No disponible'
                        });
                    }
                } else if (jid.endsWith('@s.whatsapp.net')) {
                    chatsPrivados++;
                }
            }
            
            const totalGrupos = grupos.length;
            
            if (totalGrupos === 0) {
                await replyWithContext(
                    `ꕤ 𝘎𝘳𝘰𝘶𝘱 𝘓𝘪𝘴𝘵\n۫⚞ׁ۪ ░〫️⢄〫۫ꤦ〪͜░〫️᪲⢄〫۫ໍ〪݀͡░〫️⢄〫۫ꤦ〪͜░〫️᪲⢄〫۫ໍ〪݀͡░〫️⢄〫۫ꤦ〪͜░〫️᪲⢄〫۫ໍ〪݀͡░〫️ ׁ݂⚟۪\n❖ Total Grupos › 0\n❖ Chats privados › ${chatsPrivados}\n❖ Bot › ${botNumber || 'Desconocido'}\n\n❀ No hay grupos disponibles`,
                    []
                );
                return;
            }
            
            // Construir mensaje
            let message = `ꕤ 𝘎𝘳𝘰𝘶𝘱 𝘓𝘪𝘴𝘵\n۫⚞ׁ۪ ░〫️⢄〫۫ꤦ〪͜░〫️᪲⢄〫۫ໍ〪݀͡░〫️⢄〫۫ꤦ〪͜░〫️᪲⢄〫۫ໍ〪݀͡░〫️⢄〫۫ꤦ〪͜░〫️᪲⢄〫۫ໍ〪݀͡░〫️ ׁ݂⚟۪\n`;
            message += `❖ Total Grupos › ${totalGrupos}\n`;
            message += `❖ Chats privados › ${chatsPrivados}\n`;
            message += `❖ Bot › ${botNumber || 'Desconocido'}\n\n`;
            
            // Mostrar cada grupo
            for (let i = 0; i < grupos.length; i++) {
                const grupo = grupos[i];
                message += `❀ Nombre » ${grupo.name}\n`;
                message += `❖ Link » ${grupo.link}\n`;
                message += `❐ Miembros » ${grupo.members}\n`;
                if (i < grupos.length - 1) message += `\n`;
            }
            
            // Verificar si el mensaje es demasiado largo
            if (message.length > 60000) {
                // Enviar por partes (10 grupos por mensaje)
                const chunkSize = 10;
                const totalChunks = Math.ceil(grupos.length / chunkSize);
                
                for (let c = 0; c < totalChunks; c++) {
                    const start = c * chunkSize;
                    const end = Math.min(start + chunkSize, grupos.length);
                    let chunkMessage = `ꕤ 𝘎𝘳𝘰𝘶𝘱 𝘓𝘪𝘴𝘵 (${c + 1}/${totalChunks})\n`;
                    chunkMessage += `۫⚞ׁ۪ ░〫️⢄〫۫ꤦ〪͜░〫️᪲⢄〫۫ໍ〪݀͡░〫️⢄〫۫ꤦ〪͜░〫️᪲⢄〫۫ໍ〪݀͡░〫️⢄〫۫ꤦ〪͜░〫️᪲⢄〫۫ໍ〪݀͡░〫️ ׁ݂⚟۪\n`;
                    chunkMessage += `❖ Total Grupos › ${totalGrupos}\n`;
                    chunkMessage += `❖ Chats privados › ${chatsPrivados}\n`;
                    chunkMessage += `❖ Bot › ${botNumber || 'Desconocido'}\n\n`;
                    
                    for (let i = start; i < end; i++) {
                        const grupo = grupos[i];
                        chunkMessage += `❀ Nombre » ${grupo.name}\n`;
                        chunkMessage += `❖ Link » ${grupo.link}\n`;
                        chunkMessage += `❐ Miembros » ${grupo.members}\n`;
                        if (i < end - 1) chunkMessage += `\n`;
                    }
                    
                    await replyWithContext(chunkMessage, []);
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
                
                try {
                    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
                } catch (e) {}
                
                console.log(`✅ Lista de grupos enviada por OWNER ${pushName || senderNumber}: ${totalGrupos} grupos en ${totalChunks} mensajes`);
                return;
            }
            
            await replyWithContext(message, []);
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Lista de grupos enviada por OWNER ${pushName || senderNumber}: ${totalGrupos} grupos, ${chatsPrivados} chats privados`);
            
        } catch (error) {
            console.error('❌ Error en listgroup:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ Error: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};