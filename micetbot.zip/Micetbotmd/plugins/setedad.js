import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERS_FILE = path.join(__dirname, '..', 'databases', 'users.json');

function loadUsersDB() {
    try {
        if (fs.existsSync(USERS_FILE)) {
            return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando users.json:', error);
        return {};
    }
}

function saveUsersDB(users) {
    try {
        fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando users.json:', error);
        return false;
    }
}

export default {
    name: 'setedad',
    alias: ['setage'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderNumber, senderJid, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const age = parseInt(args[0]);
            
            // Si hay un número válido, establecer directamente
            if (args.length > 0 && !isNaN(age) && age >= 13 && age <= 20) {
                const users = loadUsersDB();
                
                if (!users[senderNumber]) {
                    users[senderNumber] = {
                        number: senderNumber,
                        pushName: pushName || 'Usuario',
                        registered: new Date().toISOString()
                    };
                }
                
                users[senderNumber].age = age;
                saveUsersDB(users);
                
                await replyWithContext(
                    `🌵 Edad establecida con éxito: ${age} años`,
                    []
                );
                return;
            }
            
            // Si hay argumento pero es inválido
            if (args.length > 0 && (isNaN(age) || age < 13 || age > 20)) {
                await replyWithContext(
                    `🌟 Edad no válida\n> Las edades permitidas son: 12 a 20 años`,
                    []
                );
                return;
            }
            
            // Mostrar lista interactiva
            const ageOptions = [12, 13, 14, 15, 16, 17, 18, 19, 20];
            
            const rows = ageOptions.map(ageNum => ({
                title: `${ageNum} años`,
                description: `Establecer edad en ${ageNum} años`,
                id: `${config.prefix}setedad ${ageNum}`
            }));
            
            const sections = [{
                title: "🌟 SELECCIONA TU EDAD",
                highlight_label: "NUEVO",
                rows: rows
            }];
            
            await sock.sendMessage(from, {
                text: `🌟 Debes proporcionar tu edad\nSelecciona tu edad:`,
                footer: "🌙 Moonlight Profile",
                interactiveButtons: [
                    {
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "Sugerencias",
                            sections: sections,
                        }),
                    },
                ],
            }, { quoted: msg });
            
        } catch (error) {
            console.error('❌ Error en setedad:', error);
            await replyWithContext(`❌ Error: ${error.message}`, []);
        }
    }
};