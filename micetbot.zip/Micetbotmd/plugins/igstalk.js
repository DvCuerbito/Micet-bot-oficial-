import axios from 'axios';

export default {
    name: 'igstalk',
    alias: ['instagramstalk'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const username = args.join(' ').trim();
            
            if (!username) {
                await replyWithContext(
                    `🌟 Debes proporcionar un nombre de usuario`,
                    []
                );
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            const response = await axios.get(`https://neji-api.vercel.app/api/tools/igstalk?user=${encodeURIComponent(username)}`, {
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (!response.data?.success || !response.data?.data) {
                throw new Error('No se encontró el usuario');
            }
            
            const result = response.data.data;
            const imageUrl = result.profile_pic;
            
            // Descargar foto de perfil
            let imageBuffer = null;
            if (imageUrl) {
                try {
                    const imgResponse = await axios.get(imageUrl, { responseType: 'arraybuffer', timeout: 15000 });
                    imageBuffer = Buffer.from(imgResponse.data);
                } catch (e) {
                    console.log('Error descargando foto de perfil:', e.message);
                }
            }
            
            const caption = `🍀 *Username* » ${result.username}\n` +
                           `🍀 *Name* » ${result.full_name || 'Sin nombre'}\n` +
                           `🍀 *Bio* » ${result.bio || 'Sin biografía'}\n` +
                           `🍀 *Followers* » ${parseInt(result.followers).toLocaleString() || 0}\n` +
                           `🍀 *Following* » ${parseInt(result.following).toLocaleString() || 0}\n` +
                           `🍀 *Posts* » ${parseInt(result.posts).toLocaleString() || 0}\n` +
                           `🍀 *Verified* » ${result.verified ? '✓' : '✘'}\n` +
                           `🍀 *Private* » ${result.private ? '✓' : '✘'}`;
            
            if (imageBuffer) {
                await sock.sendMessage(from, {
                    image: imageBuffer,
                    caption: caption,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await replyWithContext(caption, []);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Instagram stalk: @${result.username} por ${pushName || 'Usuario'}`);
            
        } catch (error) {
            console.error('❌ Error en igstalk:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(
                `🌵 No se encontraron resultados para tu búsqueda`,
                []
            );
        }
    }
};
