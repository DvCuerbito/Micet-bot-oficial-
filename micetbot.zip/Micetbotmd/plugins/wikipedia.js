
// wikipedia_plus.js - Versión mejorada con imagen
import fetch from 'node-fetch';

function cleanWikipediaText(text) {
    if (!text) return '';
    text = text.replace(/<[^>]*>/g, '');
    text = text.replace(/\[\d+\]/g, '');
    if (text.length > 600) {
        text = text.substring(0, 600) + '...';
    }
    return text.trim();
}

async function searchWikipedia(query) {
    try {
        // Buscar el artículo
        const searchUrl = `https://es.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&format=json&origin=*`;
        const searchResponse = await fetch(searchUrl);
        const searchData = await searchResponse.json();
        
        if (!searchData.query?.search?.length) {
            return { error: 'No se encontraron resultados' };
        }
        
        const firstResult = searchData.query.search[0];
        const pageTitle = firstResult.title;
        const pageId = firstResult.pageid;
        
        // Obtener contenido e imagen
        const contentUrl = `https://es.wikipedia.org/w/api.php?action=query&prop=extracts|pageimages&exintro=true&explaintext=true&pithumbsize=300&pageids=${pageId}&format=json&origin=*`;
        const contentResponse = await fetch(contentUrl);
        const contentData = await contentResponse.json();
        
        const page = contentData.query.pages[pageId];
        const extract = page.extract || 'No hay descripción disponible';
        const imageUrl = page.thumbnail?.source;
        
        const articleUrl = `https://es.wikipedia.org/wiki/${encodeURIComponent(pageTitle.replace(/ /g, '_'))}`;
        
        return {
            title: pageTitle,
            description: cleanWikipediaText(extract),
            url: articleUrl,
            image: imageUrl
        };
        
    } catch (error) {
        console.error('Error en búsqueda:', error);
        return { error: 'Error al buscar en Wikipedia' };
    }
}

export default {
    name: 'wikipedia',
    alias: ['wiki', 'wikipedia'],
    
    async execute(sock, msg, options) {
        try {
            const { args, config } = options;
            const from = msg.key.remoteJid;
            
            if (args.length === 0) {
                return await sock.sendMessage(from, {
                    text: `🌸 *¿Qué deseas buscar en Wikipedia?*\n\n> Ejemplo: ${config.prefix}wikipedia inteligencia artificial`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }

            const query = args.join(' ');
            
            await sock.sendMessage(from, {
                text: `🌸 *Buscando* “${query}”...`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            const result = await searchWikipedia(query);

            if (result.error) {
                return await sock.sendMessage(from, {
                    text: `🌸 *No encontré resultados* 🌸\n\n> Intenta con otras palabras`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }

            // Si hay imagen, enviar con imagen
            if (result.image) {
                try {
                    const imageResponse = await fetch(result.image);
                    const imageBuffer = await imageResponse.buffer();
                    
                    await sock.sendMessage(from, {
                        image: imageBuffer,
                        caption: `ꆭㅤׂ 🎑ᩨ  ㅤׅ — *${result.title}* 🫟҈҉᷒ᰰֱ〪𑄸ֱׁ\n\n${result.description}\n\n🫟҈҉᷒ᰰֱ〪𑄸ֱׁ *Fuente:*\n${result.url}`,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    
                    return;
                } catch (imgError) {
                    console.log('No se pudo enviar la imagen');
                }
            }

            // Si no hay imagen o falló, enviar solo texto
            await sock.sendMessage(from, {
                text: `🌸 *${result.title}* 🌸\n\n${result.description}\n\n🌸 *Fuente:*\n${result.url}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

        } catch (error) {
            console.error('❌ Error:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `🌸 *Error* 🌸\n\n> ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};