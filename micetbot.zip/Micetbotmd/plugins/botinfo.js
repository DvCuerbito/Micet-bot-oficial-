import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'botinfo',
    alias: ['infobot'],
    
    execute: async (sock, msg, options) => {
        try {
            const { config, pushName, sender, getTotalPlugins, getTotalRegistros, getTotalCommandsUsed, senderNumber } = options;
            const from = msg.key.remoteJid;
            
            // ==========================================
            // OBTENER NÚMERO DEL BOT
            // ==========================================
            let botNumber = '';
            
            if (sock.phoneNumber) {
                botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            } else if (sock.user?.jid) {
                botNumber = sock.user.jid.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            console.log(`🔍 BotInfo - Número del bot detectado: ${botNumber}`);
            
            // ==========================================
            // CARGAR CONFIGURACIÓN DESDE INFO/{NÚMERO}/CONFIG.JS
            // ==========================================
            let botConfig = { ...config };
            let configLoaded = false;
            
            if (botNumber) {
                const configPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
                console.log(`🔍 Buscando config en: ${configPath}`);
                
                if (fs.existsSync(configPath)) {
                    try {
                        const configContent = fs.readFileSync(configPath, 'utf8');
                        const jsonMatch = configContent.match(/export default\s+({[\s\S]*})/);
                        if (jsonMatch && jsonMatch[1]) {
                            const infoConfig = eval('(' + jsonMatch[1] + ')');
                            if (infoConfig) {
                                botConfig = infoConfig;
                                configLoaded = true;
                                console.log(`✅ Configuración cargada desde info/${botNumber}/config.js`);
                            }
                        }
                    } catch (readError) {
                        console.log(`⚠️ Error leyendo config.js:`, readError.message);
                    }
                }
            }
            
            if (!configLoaded) {
                if (sock.isSubBot) {
                    botConfig.tipo = 'Sub-Bot';
                    botConfig.navegador = botConfig.navegador || 'Ubuntu Chrome';
                } else if (sock.isMainBot) {
                    botConfig.tipo = 'Main/Principal';
                    botConfig.navegador = botConfig.navegador || 'Windows Edge';
                }
            }
            
            // ==========================================
            // CARGAR IMAGEN DESDE INFO/{NÚMERO}/BANNER.JPG
            // ==========================================
            let bannerBuffer = null;
            
            if (botNumber) {
                const bannerPath = path.join(process.cwd(), 'info', botNumber, 'banner.jpg');
                console.log(`🔍 Buscando imagen en: ${bannerPath}`);
                
                if (fs.existsSync(bannerPath)) {
                    try {
                        bannerBuffer = fs.readFileSync(bannerPath);
                        console.log(`✅ Imagen cargada desde info/${botNumber}/banner.jpg`);
                    } catch (bannerError) {
                        console.log(`⚠️ Error cargando imagen:`, bannerError.message);
                    }
                }
            }
            
            // Si no hay imagen específica, buscar imagen general
            if (!bannerBuffer) {
                const generalBannerPath = path.join(process.cwd(), 'img', 'banner.jpg');
                console.log(`🔍 Buscando imagen general en: ${generalBannerPath}`);
                
                if (fs.existsSync(generalBannerPath)) {
                    bannerBuffer = fs.readFileSync(generalBannerPath);
                    console.log(`✅ Imagen general cargada`);
                }
            }
            
            // ====================
            // OBTENER ESTADÍSTICAS
            // ====================
            const totalPlugins = getTotalPlugins();
            const nodeVersion = process.version;
            const totalRegistros = getTotalRegistros();
            const totalComandos = getTotalCommandsUsed();
            
            const botType = botConfig.tipo || (sock.isSubBot ? 'Sub-Bot' : (sock.isMainBot ? 'Main/Principal' : 'Bot'));
            
            // ==========================================
            // DETERMINAR SI MOSTRAR EL DUEÑO
            // ==========================================
            let ownerDisplay = '';
            let ownerMention = [];
            
            const cleanSender = (senderNumber || '').replace(/\D/g, '');
            const cleanBotOwner = botConfig.botowner ? botConfig.botowner.replace(/\D/g, '') : '';
            const isBotOwnerUser = cleanBotOwner && cleanBotOwner === cleanSender;
            
            if (isBotOwnerUser) {
                const ownerJid = `${cleanBotOwner}@s.whatsapp.net`;
                ownerDisplay = `@${cleanBotOwner}`;
                ownerMention = [ownerJid];
                console.log(`👑 El dueño del bot está usando botinfo`);
            } else {
                ownerDisplay = '*Oculto por seguridad*';
                console.log(`🔒 Usuario no es dueño - ocultando información`);
            }
            
            // ====================
            // CONSTRUIR MENSAJE
            // ====================
            const botName = botConfig.name1 || botConfig.name || '𝖱𝗒𝗈';
            const uptime = process.uptime();
            const hours = Math.floor(uptime / 3600);
            const minutes = Math.floor((uptime % 3600) / 60);
            const uptimeString = `${hours}h ${minutes}m`;
            
            const message = `> 🌈᮫ᮬ᳘᷒ᰰ〫𑪖 ̥̩̥𝆬⌗ *𝗇ᦅ𝗆bꭇᧉ* › ${botName}\n` +
                          `> 🌈᮫ᮬ᳘᷒ᰰ〫𑪖 ̥̩̥𝆬⌗ *𝗉ꭇᧉ𝖿ꪱȷᦅ* › ${botConfig.prefix || '/'}\n` +
                          `> 🌈᮫ᮬ᳘᷒ᰰ〫𑪖 ̥̩̥𝆬⌗ *᥎ᧉꭇ𝗌ꪱó𝗇* › ${botConfig.version || '1.1.0'}\n\n` +
                          `> 🌈᮫ᮬ᳘᷒ᰰ〫𑪖 ̥̩̥𝆬⌗ *bꭇᦅw𝗌ᧉꭇ* › ${botConfig.navegador || 'Ubuntu'}\n` +
                          `> 🌈᮫ᮬ᳘᷒ᰰ〫𑪖 ̥̩̥𝆬⌗ *ƚꪱ𝗉ᦅ* › ${botType}\n` +
                          `> 🌈᮫ᮬ᳘᷒ᰰ〫𑪖 ̥̩̥𝆬⌗ *d𝗎ᧉᥒ̃ᦅ* › ${ownerDisplay}\n\n` +
                          `━ֹ̩̥̩̥─꯭ֹ۪۪۪۪۪─꯭─꯭─꯭─꯭─꯭─꯭᪲━ֹ̩̥̩̥̩۫۫۫౬֔┄᪲🍭̸̶ᩨᰰ〪〫𝆬ᮢ̷─꯭ֹ۪۪۪۪۪━꯭֔─꯭─꯭─꯭─꯭─꯭─꯭᪲━ֹ̩̥̩̥̩\n\n` +
                          `> 🌈᮫ᮬ᳘᷒ᰰ〫𑪖 ̥̩̥𝆬⌗ *α𝖼ƚꪱ᥎ꪱdαd* › ${uptimeString}\n` +
                          `> 🌈᮫ᮬ᳘᷒ᰰ〫𑪖 ̥̩̥𝆬⌗ *𝗉𝗅αƚα𝖿ᦅꭇ𝗆α* › Linux 🐧\n` +
                          `> 🌈᮫ᮬ᳘᷒ᰰ〫𑪖 ̥̩̥𝆬⌗ *𝗀ꭇ𝗎𝗉ᦅ𝗌* › ${Object.keys(await sock.groupFetchAllParticipating()).length}\n` +
                          `> 🌈᮫ᮬ᳘᷒ᰰ〫𑪖 ̥̩̥𝆬⌗ *𝗌𝗎b-bᦅƚ𝗌* › ${fs.existsSync('./Sessions/Subs') ? fs.readdirSync('./Sessions/Subs').length : 0}\n` +
                          `> 🌈᮫ᮬ᳘᷒ᰰ〫𑪖 ̥̩̥𝆬⌗ *𝗉𝗅𝗎𝗀і𝗇𝗌* › ${totalPlugins}\n` +
                          `> 🌈᮫ᮬ᳘᷒ᰰ〫𑪖 ̥̩̥𝆬⌗ *ƚᦅƚα𝗅 c𝗆d* › ${totalComandos}\n` +
                          `> 🌈᮫ᮬ᳘᷒ᰰ〫𑪖 ̥̩̥𝆬⌗ *𝗎𝗌𝗎αꭇꪱᦅ𝗌* › ${totalRegistros}`;
            
            const mentions = [sender, ...ownerMention];
            
            // ====================
            // ENVIAR MENSAJE CON IMAGEN
            // ====================
            if (bannerBuffer) {
                await sock.sendMessage(from, {
                    image: bannerBuffer,
                    caption: message,
                    mentions: mentions,
                    contextInfo: {
                        mentionedJid: mentions,
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: botConfig.canalId || '120363403616345878@newsletter',
                            serverMessageId: 0,
                            newsletterName: botConfig.canalNombre || '❀ּ🌊̸̷̸̷̶ֵ̫̫̫֟ᰈ 𝖬𝗈𝗈𝗇𝗅𝗂𝗀𝗁𝗍 𝖲𝗍𝖺𝖿𝖿'
                        }
                    }
                }, { quoted: msg });
                console.log('✅ Imagen enviada con el texto como caption');
            } else {
                await sock.sendMessage(from, {
                    text: message,
                    mentions: mentions,
                    contextInfo: {
                        mentionedJid: mentions,
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: botConfig.canalId || '120363403616345878@newsletter',
                            serverMessageId: 0,
                            newsletterName: botConfig.canalNombre || '❀ּ🌊̸̷̸̷̶ֵ̫̫̫֟ᰈ 𝖬𝗈𝗈𝗇𝗅𝗂𝗀𝗁𝗍 𝖲𝗍𝖺𝖿𝖿'
                        }
                    }
                }, { quoted: msg });
                console.log('✅ Texto enviado (sin imagen)');
            }
            
            console.log(`📊 Botinfo ejecutado por ${pushName}`);
            console.log(`   - Imagen: ${bannerBuffer ? 'Cargada y enviada' : 'No disponible'}`);
            
        } catch (error) {
            console.error('❌ Error en comando botinfo:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: '🏮 Error al obtener información del bot'
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};
