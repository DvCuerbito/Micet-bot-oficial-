import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'setprefix',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, sender, args, senderNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            // ==========================================
            // OBTENER NÚMERO DEL BOT
            // ==========================================
            let botNumber = '';
            if (sock.phoneNumber) {
                botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            if (!botNumber) {
                throw new Error('No se pudo identificar el número del bot');
            }
            
            // ==========================================
            // VERIFICAR SI EL USUARIO ES OWNER (desde config.js)
            // ==========================================
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isOwner) {
                // Usar el mismo mensaje de "comando no existe"
                await replyWithContext(
                    `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}setprefix\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    []
                );
                return;
            }
            
            // ==========================================
            // VERIFICAR ARGUMENTOS
            // ==========================================
            if (!args || args.length === 0) {
                await sock.sendMessage(from, {
                    text: `⚙️ *Formato incorrecto*\n\n` +
                          `> *Uso correcto:* ${config.prefix}setprefix +nuevoprefijo\n` +
                          `> *Ejemplo:* ${config.prefix}setprefix +!\n` +
                          `> *Ejemplo:* ${config.prefix}setprefix +/\n` +
                          `> *Ejemplo:* ${config.prefix}setprefix +#\n\n` +
                          `📌 *El prefijo actual es:* ${config.prefix}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Obtener el nuevo prefijo
            let newPrefix = args[0];
            
            // Eliminar el '+' si está presente al inicio
            if (newPrefix.startsWith('+')) {
                newPrefix = newPrefix.substring(1).trim();
            }
            
            // Verificar que el prefijo no esté vacío
            if (!newPrefix || newPrefix.length === 0) {
                await sock.sendMessage(from, {
                    text: `⚙️ *El prefijo no puede estar vacío*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Limitar a 1-2 caracteres
            if (newPrefix.length > 2) {
                await sock.sendMessage(from, {
                    text: `⚙️ *El prefijo debe ser de 1-2 caracteres*\n> Ejemplo: . / ! # $`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            try {
                // ==========================================
                // RUTA DEL ARCHIVO DE CONFIGURACIÓN
                // ==========================================
                const configPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
                
                if (!fs.existsSync(configPath)) {
                    throw new Error(`No se encontró configuración para el bot ${botNumber}`);
                }
                
                console.log(`📝 Leyendo configuración actual de: ${configPath}`);
                
                // Leer el archivo actual
                let configContent = fs.readFileSync(configPath, 'utf8');
                
                // Extraer el objeto JSON
                const jsonMatch = configContent.match(/export default\s+({[\s\S]*})/);
                if (!jsonMatch || !jsonMatch[1]) {
                    throw new Error('Formato de archivo config.js inválido');
                }
                
                // Evaluar el objeto actual
                const currentConfig = eval('(' + jsonMatch[1] + ')');
                
                // ==========================================
                // ACTUALIZAR EL PREFIJO
                // ==========================================
                const oldPrefix = currentConfig.prefix || config.prefix;
                currentConfig.prefix = newPrefix;
                
                console.log(`📝 Actualizando prefijo de "${oldPrefix}" a "${newPrefix}"`);
                
                // ==========================================
                // GUARDAR EL ARCHIVO ACTUALIZADO
                // ==========================================
                const newConfigContent = `// Configuración del Bot - ${currentConfig.tipo || 'Sub-Bot'}
// Creado para el número: ${botNumber}
// Actualizado el: ${new Date().toLocaleString()}

export default ${JSON.stringify(currentConfig, null, 2)}
`;
                
                fs.writeFileSync(configPath, newConfigContent);
                console.log(`✅ Configuración actualizada para bot ${botNumber}`);
                
                // ==========================================
                // ENVIAR CONFIRMACIÓN
                // ==========================================
                await sock.sendMessage(from, {
                    text: `⚙️ *Prefijo actualizado con éxito*\n\n` +
                          `> *Nuevo prefijo:* ${newPrefix}\n` +
                          `> *Anterior:* ${oldPrefix}\n` +
                          `> *Bot:* ${botNumber}\n` +
                          `> *Actualizado por:* Owner\n\n` +
                          `✨ Ahora usa ${newPrefix} para los comandos`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
            } catch (error) {
                console.error('Error en setprefix:', error);
                
                await sock.sendMessage(from, {
                    text: `⚙️ *Error al cambiar el prefijo*\n> ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
        } catch (error) {
            console.error('Error general en setprefix:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ Error inesperado en setprefix`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};
