
import fs from 'fs';
import path from 'path';
import axios from 'axios';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'waifu',
    alias: [],
    
    async execute(sock, msg, options) {
        const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
        const from = msg.key.remoteJid;
        
        try {
            // Verificar registro (usando senderNumber)
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                const reply = 'ৎ꯭᪲୨֟ Para usar mis comandos tienes que estar registrado.\n> Uso : ' + config.prefix + 'reg Misa.16';
                return await sock.sendMessage(from, { 
                    text: reply,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);
            
            // Determinar categoría (sfw o nsfw)
            let category = 'sfw';
            if (args && args[0] && (args[0].toLowerCase() === 'nsfw' || args[0].toLowerCase() === '+18')) {
                category = 'nsfw';
            }

            // Obtener waifu aleatoria
            const response = await axios({
                method: 'GET',
                url: `https://api.waifu.pics/${category}/waifu`,
                timeout: 10000
            });

            const imageUrl = response.data?.url;

            if (!imageUrl) {
                throw new Error('No se pudo obtener la imagen');
            }

            // Descargar imagen
            const imageResponse = await axios({
                method: 'GET',
                url: imageUrl,
                responseType: 'arraybuffer',
                timeout: 15000
            });

            const tempDir = path.join(__dirname, '..', 'temp');
            const tempPath = path.join(tempDir, `waifu_${Date.now()}.jpg`);
            
            // Asegurar que existe el directorio temp
            if (!fs.existsSync(tempDir)) {
                fs.mkdirSync(tempDir, { recursive: true });
            }

            // Guardar temporalmente
            fs.writeFileSync(tempPath, imageResponse.data);

            // Preparar caption
            const caption = `🌸 *Waifu para ${pushName || 'ti'}*\n` +
                          `🌸 *Categoría:* ${category.toUpperCase()}\n` +
                          `🌸 *Disfruta tu waifu* ✨`;

            // Enviar imagen
            await sock.sendMessage(from, {
                image: fs.readFileSync(tempPath),
                caption: caption,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            // Eliminar archivo temporal
            fs.unlinkSync(tempPath);

            console.log(`✅ Waifu enviada a ${pushName || senderNumber || 'usuario'} (${category})`);

        } catch (error) {
            console.error("❌ Error en waifu:", error);
            
            try {
                const reply = "🥕 Ocurrió un error obteniendo waifu.\n> Error: " + error.message;
                await sock.sendMessage(from, { 
                    text: reply,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
};