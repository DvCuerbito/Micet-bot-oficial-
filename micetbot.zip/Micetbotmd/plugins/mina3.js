import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 0,
            minerals: {
                piedras: 0,
                diamantes: 0,
                esmeraldas: 0,
                oro: 0,
                rubies: 0,
                zafiros: 0,
                fosiles: 0,
                arcilla: 0,
                carbon: 0,
                hierro: 0,
                platino: 0,
                cobre: 0,
                cristal_magico: 0,
                polvo_estelar: 0,
                esencia: 0
            },
            health: 100,
            mana: 50,
            level: 1,
            exp: 0,
            lastMine: 0,
            lastWork: 0,
            lastCrime: 0,
            lastAdventure: 0,
            lastClaim: 0,
            lastChest: 0,
            lastHunt: 0,
            lastFish: 0,
            lastExcavar: 0,
            lastTesoro: 0,
            lastReciclar: 0,
            lastMina2: 0,
            lastMina3: 0,
            items: {
                agua: 0,
                vendas: 0,
                pastillas: 0,
                pico: 1,
                mapa: 0,
                pala: 1,
                varita: 0
            }
        };
    }
    return economy[userNumber];
}

function getRemainingTime(lastUsed, cooldownMs = 300000) { // 5 minutos
    const now = Date.now();
    const timePassed = now - lastUsed;
    
    if (timePassed >= cooldownMs) return 0;
    
    const remaining = cooldownMs - timePassed;
    const seconds = Math.floor(remaining / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    
    if (minutes > 0) {
        return `${minutes}m ${remainingSeconds}s`;
    }
    return `${remainingSeconds}s`;
}

// Minerales mágicos de mina encantada
const magicalMineOres = [
    // Minerales mágicos comunes (40%)
    {
        name: "✨ Cristal de maná",
        rarity: "común",
        probability: 0.40,
        minerals: { cristal_magico: [2, 5], mana: [5, 10] },
        healthCost: [5, 12],
        exp: 15,
        manaGain: 5
    },
    {
        name: "🌟 Polvo estelar",
        rarity: "común",
        probability: 0.40,
        minerals: { polvo_estelar: [3, 8], coins: [20, 40] },
        healthCost: [6, 14],
        exp: 18,
        manaGain: 3
    },
    
    // Minerales mágicos raros (30%)
    {
        name: "🔮 Esencia mágica",
        rarity: "raro",
        probability: 0.30,
        minerals: { esencia: [2, 5], cristal_magico: [3, 6] },
        healthCost: [8, 16],
        exp: 25,
        manaGain: 10
    },
    {
        name: "💎 Diamante encantado",
        rarity: "raro",
        probability: 0.30,
        minerals: { diamantes: [3, 7], rubies: [2, 4], mana: [8, 15] },
        healthCost: [10, 18],
        exp: 30,
        manaGain: 8
    },
    
    // Minerales mágicos épicos (20%)
    {
        name: "🌙 Piedra lunar",
        rarity: "épico",
        probability: 0.20,
        minerals: { cristal_magico: [4, 8], polvo_estelar: [5, 10], mana: [15, 25] },
        healthCost: [12, 20],
        exp: 45,
        manaGain: 15,
        special: "lunar"
    },
    {
        name: "☀️ Cristal solar",
        rarity: "épico",
        probability: 0.20,
        minerals: { esencia: [3, 7], diamantes: [4, 8], oro: [10, 20] },
        healthCost: [14, 22],
        exp: 50,
        manaGain: 12,
        special: "solar"
    },
    
    // Minerales mágicos legendarios (8%)
    {
        name: "🌈 Gema del arcoíris",
        rarity: "legendario",
        probability: 0.08,
        minerals: { diamantes: [5, 10], rubies: [4, 8], zafiros: [4, 8], esmeraldas: [5, 10] },
        healthCost: [18, 25],
        exp: 80,
        manaGain: 25,
        special: "rainbow"
    },
    
    // Minerales míticos (2%)
    {
        name: "⚡ Corazón de dragón",
        rarity: "mítico",
        probability: 0.02,
        minerals: { esencia: [8, 15], cristal_magico: [10, 20], polvo_estelar: [10, 20], mana: [30, 50] },
        healthCost: [20, 30],
        exp: 150,
        manaGain: 50,
        special: "dragon",
        items: { varita: 1 }
    }
];

export default {
    name: 'mina3',
    alias: ['minaencantada', 'magicmine'],
    
    async execute(sock, msg, options) {
        try {
            const { 
                config, 
                senderNumber, 
                pushName,
                replyWithContext,
                senderJid 
            } = options;
            
            if (!senderNumber) {
                return await replyWithContext(
                    '❌ No se pudo identificar tu número',
                    [senderJid]
                );
            }
            
            let economy = loadEconomy();
            const user = initUserEconomy(economy, senderNumber, pushName);
            
            // Verificar nivel mínimo
            if (user.level < 10) {
                return await replyWithContext(
                    '⚠️ *Necesitas nivel 10 para entrar a la Mina Encantada*\n' +
                    `> Tu nivel: ${user.level}`,
                    [senderJid]
                );
            }
            
            // Verificar salud y maná
            if (user.health < 40) {
                return await replyWithContext(
                    '⚠️ *La Mina Encantada drena tu energía vital*\n' +
                    '> Necesitas al menos 40 de salud',
                    [senderJid]
                );
            }
            
            if (user.mana < 20) {
                return await replyWithContext(
                    '⚠️ *No tienes suficiente maná para la magia de la mina*\n' +
                    '> Necesitas al menos 20 de maná',
                    [senderJid]
                );
            }
            
            // Verificar cooldown
            const cooldownTime = 300000; // 5 minutos
            const now = Date.now();
            
            if (user.lastMina3 && (now - user.lastMina3) < cooldownTime) {
                const remaining = getRemainingTime(user.lastMina3, cooldownTime);
                return await replyWithContext(
                    `⏳ *Debes esperar ${remaining}* para volver a la Mina Encantada`,
                    [senderJid]
                );
            }
            
            user.lastMina3 = now;
            
            // Seleccionar mineral mágico
            const rand = Math.random();
            let selectedOre;
            let cumulative = 0;
            
            for (const ore of magicalMineOres) {
                cumulative += ore.probability;
                if (rand < cumulative) {
                    selectedOre = ore;
                    break;
                }
            }
            
            if (!selectedOre) selectedOre = magicalMineOres[0];
            
            // Calcular salud perdida
            const saludPerdida = Math.floor(Math.random() * (selectedOre.healthCost[1] - selectedOre.healthCost[0] + 1)) + selectedOre.healthCost[0];
            user.health = Math.max(0, user.health - saludPerdida);
            
            // Consumir maná
            const manaCost = Math.floor(saludPerdida / 2);
            user.mana -= manaCost;
            
            // Generar minerales
            let mineralsText = '';
            let totalValue = 0;
            
            for (const [mineral, range] of Object.entries(selectedOre.minerals)) {
                if (mineral === 'mana') {
                    user.mana += range;
                    mineralsText += `🔮 *Maná:* +${range}\n`;
                } else {
                    const cantidad = Math.floor(Math.random() * (range[1] - range[0] + 1)) + range[0];
                    
                    if (!user.minerals[mineral]) user.minerals[mineral] = 0;
                    user.minerals[mineral] += cantidad;
                    
                    const emoji = mineral === 'cristal_magico' ? '🔮' :
                                 mineral === 'polvo_estelar' ? '✨' :
                                 mineral === 'esencia' ? '💫' :
                                 mineral === 'diamantes' ? '💎' :
                                 mineral === 'rubies' ? '🔴' :
                                 mineral === 'zafiros' ? '🔵' :
                                 mineral === 'esmeraldas' ? '💚' :
                                 mineral === 'oro' ? '🪙' : '📦';
                    
                    mineralsText += `${emoji} *${mineral}:* +${cantidad}\n`;
                    
                    if (mineral === 'diamantes') totalValue += cantidad * 30;
                    else if (mineral === 'rubies') totalValue += cantidad * 25;
                    else totalValue += cantidad * 10;
                }
            }
            
            // Bonus por varita
            if (user.items.varita > 0) {
                const bonusMana = Math.floor(selectedOre.manaGain * 1.5);
                user.mana += bonusMana;
                mineralsText += `\n🔮 *Bonus varita mágica:* +${bonusMana} maná`;
            }
            
            // Bonus especiales
            if (selectedOre.special === 'lunar') {
                user.health += 10;
                mineralsText += `\n🌙 *Luz lunar:* +10 salud`;
            } else if (selectedOre.special === 'solar') {
                user.coins += 50;
                mineralsText += `\n☀️ *Energía solar:* +50 coins`;
            } else if (selectedOre.special === 'rainbow') {
                user.minerals.diamantes += 5;
                mineralsText += `\n🌈 *Arcoíris mágico:* +5 diamantes extra`;
            } else if (selectedOre.special === 'dragon') {
                user.minerals.cristal_magico += 10;
                user.health = Math.min(100, user.health + 20);
                mineralsText += `\n🐉 *Corazón de dragón:* +10 cristales y +20 salud`;
            }
            
            // Items especiales
            if (selectedOre.items && selectedOre.items.varita) {
                user.items.varita += 1;
                mineralsText += `\n🪄 *¡Varita mágica encontrada!* +1`;
            }
            
            // Ganar EXP
            user.exp += selectedOre.exp;
            
            // Verificar subida de nivel
            if (user.exp >= user.level * 150) {
                user.level += 1;
                user.exp = 0;
                user.mana += 20;
                mineralsText += `\n\n⭐ *¡Subiste a nivel ${user.level}!* +20 maná`;
            }
            
            saveEconomy(economy);
            
            // Determinar color según rareza
            let rarityColor = '';
            switch(selectedOre.rarity) {
                case 'común': rarityColor = '🟢'; break;
                case 'raro': rarityColor = '🔵'; break;
                case 'épico': rarityColor = '🟣'; break;
                case 'legendario': rarityColor = '🟡'; break;
                case 'mítico': rarityColor = '🔴'; break;
            }
            
            const mina3Text = `⚗️ *MINA ENCANTADA (NIVEL 3)*\n\n` +
                `${selectedOre.name}\n` +
                `${rarityColor} *Rareza:* ${selectedOre.rarity.toUpperCase()}\n\n` +
                `🎑 *MINERALES MÁGICOS*\n\n` +
                mineralsText +
                `\n❤️ *Salud:* -${saludPerdida} | 🔮 *Maná:* -${manaCost}\n` +
                `🔮 *Maná actual:* ${user.mana}\n` +
                `📊 *EXP ganada:* +${selectedOre.exp}`;
            
            await replyWithContext(mina3Text, [senderJid]);
            
        } catch (error) {
            console.error('❌ Error en comando mina3:', error);
        }
    }
};
