import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'setchannelid',
    alias: ['setcanalid'],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, args } = options;
            const from = msg.key.remoteJid;
            
            // ==========================================
            // OBTENER NÚMERO DEL BOT
            // ==========================================
            let botNumber = '';
            if (sock.phoneNumber) {
                botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            if (!botNumber) {
                throw new Error('No se pudo identificar el número del bot');
            }
            
            // ==========================================
            // VERIFICAR SI EL USUARIO ES EL BOTOWNER
            // ==========================================
            const isBotOwner = config.botowner && 
                              config.botowner.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '');
            
            if (!isBotOwner) {
                await sock.sendMessage(from, {
                    text: `❀ *Solo el dueño del bot puede cambiar el ID del canal*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar que se proporcionó un ID
            if (!args || args.length === 0) {
                await sock.sendMessage(from, {
                    text: `🌽 Debes proporcionar el id de tu canal\n\n` +
                          `> *Uso correcto:* ${config.prefix}setchannelid +12345678910@newslettr`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Obtener el nuevo ID
            let newId = args.join(' ');
            
            // Eliminar el '+' si está presente al inicio
            if (newId.startsWith('+')) {
                newId = newId.substring(1).trim();
            }
            
            // Verificar que el ID no esté vacío
            if (!newId || newId.length === 0) {
                await sock.sendMessage(from, {
                    text: `🌽 *El ID del canal no puede estar vacío*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar que el ID tenga el formato correcto (debe terminar en @newsletter)
            if (!newId.endsWith('@newsletter')) {
                await sock.sendMessage(from, {
                    text: `🌽 *Formato de ID inválido*\n\n` +
                          `> *El ID debe terminar en:* @newsletter`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            try {
                console.log(`📢 Botowner ${senderNumber} está cambiando el ID del canal del bot ${botNumber}...`);
                
                // ==========================================
                // RUTA DEL ARCHIVO DE CONFIGURACIÓN
                // ==========================================
                const configPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
                
                if (!fs.existsSync(configPath)) {
                    throw new Error(`No se encontró configuración para el bot ${botNumber}`);
                }
                
                console.log(`📝 Leyendo configuración actual de: ${configPath}`);
                
                // Leer el archivo actual
                let configContent = fs.readFileSync(configPath, 'utf8');
                
                // Extraer el objeto JSON
                const jsonMatch = configContent.match(/export default\s+({[\s\S]*})/);
                if (!jsonMatch || !jsonMatch[1]) {
                    throw new Error('Formato de archivo config.js inválido');
                }
                
                // Evaluar el objeto actual
                const currentConfig = eval('(' + jsonMatch[1] + ')');
                
                // ==========================================
                // ACTUALIZAR EL ID DEL CANAL
                // ==========================================
                const oldId = currentConfig.canalId || config.canalId || 'No definido';
                currentConfig.canalId = newId;
                
                console.log(`📝 Actualizando ID del canal de "${oldId}" a "${newId}"`);
                
                // ==========================================
                // GUARDAR EL ARCHIVO ACTUALIZADO
                // ==========================================
                const newConfigContent = `// Configuración del Bot - ${currentConfig.tipo || 'Sub-Bot'}
// Creado para el número: ${botNumber}
// Actualizado el: ${new Date().toLocaleString()}

export default ${JSON.stringify(currentConfig, null, 2)}
`;
                
                fs.writeFileSync(configPath, newConfigContent);
                console.log(`✅ Configuración actualizada para bot ${botNumber}`);
                
                // ==========================================
                // ENVIAR CONFIRMACIÓN
                // ==========================================
                await sock.sendMessage(from, {
                    text: `🎑 Id del canal actualizado con éxito`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: newId,
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
            } catch (error) {
                console.error('Error en setchannelid:', error);
                
                await sock.sendMessage(from, {
                    text: `📢 *Error al cambiar el ID del canal*\n> ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
        } catch (error) {
            console.error('Error general en setchannelid:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ Error inesperado en setchannelid`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};