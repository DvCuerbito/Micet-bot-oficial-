import cp, { exec as _exec } from 'child_process';
import { promisify } from 'util';

const exec = promisify(_exec).bind(cp);

export default {
    name: 'r',
    alias: ['exec', 'ejecutar'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            const text = args.join(' ').trim();
            
            if (!text) {
                return await sock.sendMessage(from, {
                    text: `《✧》 Debes escribir un comando a ejecutar.`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            // Verificar si es owner
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isOwner) {
                return await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}r\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            let o;
            try {
                await sock.sendMessage(from, { react: { text: '🕒', key: msg.key } });
                o = await exec(text);
                await sock.sendMessage(from, { react: { text: '✔️', key: msg.key } });
            } catch (e) {
                o = e;
                await sock.sendMessage(from, { react: { text: '✖️', key: msg.key } });
            } finally {
                const { stdout, stderr } = o;
                if (stdout?.trim()) {
                    await sock.sendMessage(from, {
                        text: stdout,
                        contextInfo: {
                            mentionedJid: [senderJid],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
                if (stderr?.trim()) {
                    await sock.sendMessage(from, {
                        text: stderr,
                        contextInfo: {
                            mentionedJid: [senderJid],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
            }
            
        } catch (error) {
            console.error('❌ Error en r:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '✖️', key: msg.key } });
            } catch (e) {}
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `《✧》 Error al ejecutar comando: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};