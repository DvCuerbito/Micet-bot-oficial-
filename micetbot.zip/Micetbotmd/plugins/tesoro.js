import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 0,
            minerals: {
                piedras: 0,
                diamantes: 0,
                esmeraldas: 0,
                oro: 0,
                rubies: 0,
                zafiros: 0,
                fosiles: 0,
                arcilla: 0,
                carbon: 0,
                hierro: 0
            },
            health: 100,
            lastMine: 0,
            lastWork: 0,
            lastCrime: 0,
            lastAdventure: 0,
            lastClaim: 0,
            lastChest: 0,
            lastHunt: 0,
            lastFish: 0,
            lastExcavar: 0,
            lastTesoro: 0,
            lastReciclar: 0,
            lastMina2: 0,
            lastMina3: 0,
            items: {
                agua: 0,
                vendas: 0,
                pastillas: 0,
                pico: 1,
                mapa: 0,
                pala: 1
            }
        };
    }
    return economy[userNumber];
}

function getRemainingTime(lastUsed, cooldownMs = 300000) { // 5 minutos
    const now = Date.now();
    const timePassed = now - lastUsed;
    
    if (timePassed >= cooldownMs) return 0;
    
    const remaining = cooldownMs - timePassed;
    const seconds = Math.floor(remaining / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    
    if (minutes > 0) {
        return `${minutes}m ${remainingSeconds}s`;
    }
    return `${remainingSeconds}s`;
}

// Tipos de tesoros
const treasures = [
    {
        name: "🗺️ *Mapa Antiguo*",
        rarity: "común",
        probability: 0.50,
        requires: { mapa: 0 },
        rewards: {
            coins: [30, 80],
            minerals: {
                oro: [2, 5],
                piedras: [10, 20]
            }
        }
    },
    {
        name: "📜 *Pergamino Secreto*",
        rarity: "común",
        probability: 0.50,
        requires: { mapa: 0 },
        rewards: {
            coins: [40, 100],
            minerals: {
                diamantes: [1, 2],
                esmeraldas: [2, 4]
            }
        }
    },
    {
        name: "⚱️ *Cofre de Bronce*",
        rarity: "raro",
        probability: 0.25,
        requires: { mapa: 1 },
        rewards: {
            coins: [80, 150],
            minerals: {
                diamantes: [2, 4],
                oro: [5, 10],
                rubies: [1, 2]
            },
            items: {
                agua: [2, 4],
                vendas: [1, 3]
            }
        }
    },
    {
        name: "🏺 *Cofre de Plata*",
        rarity: "raro",
        probability: 0.25,
        requires: { mapa: 1 },
        rewards: {
            coins: [120, 200],
            minerals: {
                diamantes: [3, 6],
                esmeraldas: [4, 8],
                zafiros: [1, 3]
            },
            items: {
                pastillas: [2, 4],
                vendas: [2, 3]
            }
        }
    },
    {
        name: "👑 *Cofre de Oro*",
        rarity: "épico",
        probability: 0.15,
        requires: { mapa: 2 },
        rewards: {
            coins: [200, 350],
            minerals: {
                diamantes: [5, 10],
                rubies: [3, 6],
                zafiros: [2, 5],
                oro: [10, 20]
            },
            items: {
                pastillas: [3, 5],
                agua: [4, 6],
                vendas: [3, 4]
            }
        }
    },
    {
        name: "💎 *Cofre de Diamante*",
        rarity: "épico",
        probability: 0.15,
        requires: { mapa: 2 },
        rewards: {
            coins: [300, 500],
            minerals: {
                diamantes: [8, 15],
                rubies: [5, 10],
                esmeraldas: [10, 15]
            },
            items: {
                pastillas: [4, 6],
                agua: [5, 8]
            },
            special: "mapa"
        }
    },
    {
        name: "🔮 *Cofre Místico*",
        rarity: "legendario",
        probability: 0.05,
        requires: { mapa: 3 },
        rewards: {
            coins: [500, 1000],
            minerals: {
                diamantes: [15, 25],
                rubies: [10, 15],
                zafiros: [8, 12],
                fosiles: [2, 5]
            },
            items: {
                pastillas: [6, 10],
                agua: [8, 12],
                vendas: [5, 8]
            },
            special: "pico"
        }
    }
];

export default {
    name: 'tesoro',
    alias: ['treasure', 'buscar'],
    
    async execute(sock, msg, options) {
        try {
            const { 
                config, 
                senderNumber, 
                pushName,
                replyWithContext,
                senderJid 
            } = options;
            
            if (!senderNumber) {
                return await replyWithContext(
                    '❌ No se pudo identificar tu número',
                    [senderJid]
                );
            }
            
            let economy = loadEconomy();
            const user = initUserEconomy(economy, senderNumber, pushName);
            
            // Verificar cooldown
            const cooldownTime = 300000; // 5 minutos
            const now = Date.now();
            
            if (user.lastTesoro && (now - user.lastTesoro) < cooldownTime) {
                const remaining = getRemainingTime(user.lastTesoro, cooldownTime);
                return await replyWithContext(
                    `⏳ *Debes esperar ${remaining}* para buscar otro tesoro`,
                    [senderJid]
                );
            }
            
            // Verificar si tiene mapa
            if (!user.items.mapa || user.items.mapa === 0) {
                return await replyWithContext(
                    '🗺️ *No tienes mapas del tesoro*\n' +
                    '> Consigue mapas en *minar*, *excavar* o *comerciante*',
                    [senderJid]
                );
            }
            
            user.lastTesoro = now;
            
            // Usar un mapa
            user.items.mapa -= 1;
            
            // Seleccionar tesoro basado en rareza y mapa
            const rand = Math.random();
            let selectedTreasure;
            let cumulative = 0;
            
            // Filtrar tesoros según nivel de mapa
            const availableTreasures = treasures.filter(t => t.requires.mapa <= user.items.mapa + 1);
            
            for (const treasure of availableTreasures) {
                cumulative += treasure.probability;
                if (rand < cumulative) {
                    selectedTreasure = treasure;
                    break;
                }
            }
            
            if (!selectedTreasure) selectedTreasure = availableTreasures[0];
            
            // Aplicar recompensas
            const rewards = selectedTreasure.rewards;
            let rewardsText = '';
            
            // Coins
            if (rewards.coins) {
                const coins = Math.floor(Math.random() * (rewards.coins[1] - rewards.coins[0] + 1)) + rewards.coins[0];
                user.coins += coins;
                rewardsText += `💰 Coins: *+${coins}*\n`;
            }
            
            // Minerales
            if (rewards.minerals) {
                for (const [mineral, range] of Object.entries(rewards.minerals)) {
                    const cantidad = Math.floor(Math.random() * (range[1] - range[0] + 1)) + range[0];
                    if (!user.minerals[mineral]) user.minerals[mineral] = 0;
                    user.minerals[mineral] += cantidad;
                    
                    const emoji = mineral === 'diamantes' ? '💎' : 
                                 mineral === 'esmeraldas' ? '💚' :
                                 mineral === 'oro' ? '🪙' :
                                 mineral === 'rubies' ? '🔴' :
                                 mineral === 'zafiros' ? '🔵' :
                                 mineral === 'fosiles' ? '🦴' : '🪨';
                    
                    rewardsText += `${emoji} ${mineral}: *+${cantidad}*\n`;
                }
            }
            
            // Items
            if (rewards.items) {
                for (const [item, range] of Object.entries(rewards.items)) {
                    const cantidad = Math.floor(Math.random() * (range[1] - range[0] + 1)) + range[0];
                    user.items[item] += cantidad;
                    
                    const emoji = item === 'agua' ? '🍶' : 
                                 item === 'vendas' ? '🩹' :
                                 item === 'pastillas' ? '💊' : '📦';
                    
                    rewardsText += `${emoji} ${item}: *+${cantidad}*\n`;
                }
            }
            
            // Recompensa especial
            if (rewards.special === 'mapa') {
                user.items.mapa += 2;
                rewardsText += `🗺️ *Mapas extra:* +2\n`;
            } else if (rewards.special === 'pico') {
                user.items.pico += 1;
                rewardsText += `⛏️ *Pico mejorado:* +1 nivel\n`;
            }
            
            saveEconomy(economy);
            
            // Determinar color según rareza
            let rarityColor = '';
            switch(selectedTreasure.rarity) {
                case 'común': rarityColor = '🟢'; break;
                case 'raro': rarityColor = '🔵'; break;
                case 'épico': rarityColor = '🟣'; break;
                case 'legendario': rarityColor = '🟡'; break;
            }
            
            const tesoroText = `${selectedTreasure.name}\n` +
                `${rarityColor} *Rareza:* ${selectedTreasure.rarity.toUpperCase()}\n\n` +
                `🎁 *CONTENIDO*\n\n` +
                rewardsText +
                `\n🗺️ *Mapas restantes:* ${user.items.mapa}`;
            
            await replyWithContext(tesoroText, [senderJid]);
            
        } catch (error) {
            console.error('❌ Error en comando tesoro:', error);
        }
    }
};
