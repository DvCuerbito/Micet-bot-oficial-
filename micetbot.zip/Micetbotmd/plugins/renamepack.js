import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PACKS_FILE = path.join(__dirname, '..', 'databases', 'packs.json');

const loadPacksDB = () => {
    try {
        if (fs.existsSync(PACKS_FILE)) {
            const data = fs.readFileSync(PACKS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando packs.json:', error);
    }
    return {};
};

const savePacksDB = (packsDB) => {
    try {
        const dbDir = path.join(__dirname, '..', 'databases');
        if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
        fs.writeFileSync(PACKS_FILE, JSON.stringify(packsDB, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando packs.json:', error);
        return false;
    }
};

export default {
    name: 'renamepack',
    alias: ['setpackname'],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, senderJid, args, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (args.length < 3) {
                return await sock.sendMessage(from, {
                    text: `「✰」Debes proporcionar el nombre actual y el nuevo nombre separados por un "/"\n> Ejemplo: ${config.prefix}renamepack Mis Stickers / Nuevo Nombre`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            const separatorIndex = args.findIndex(arg => arg === '/');
            
            if (separatorIndex === -1) {
                return await sock.sendMessage(from, {
                    text: `「✰」Formato incorrecto\n> Usa "/" para separar el nombre actual del nuevo nombre\n> Ejemplo: ${config.prefix}renamepack Mis Stickers / Nuevo Nombre`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            const oldName = args.slice(0, separatorIndex).join(' ').trim();
            const newName = args.slice(separatorIndex + 1).join(' ').trim();
            
            if (!oldName || !newName) {
                return await sock.sendMessage(from, {
                    text: `「✰」Nombre inválido\n> Ejemplo: ${config.prefix}renamepack Mis Stickers / Nuevo Nombre`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            const packsDB = loadPacksDB();
            
            if (!packsDB[senderNumber] || !packsDB[senderNumber][oldName]) {
                return await sock.sendMessage(from, {
                    text: `「✰」No tienes un pack llamado "${oldName}"\n> Usa ${config.prefix}packlist para ver tus packs`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            if (packsDB[senderNumber][newName]) {
                return await sock.sendMessage(from, {
                    text: `《✧》Ya tienes un pack llamado "${newName}"\n> Usa otro nombre o elimina el existente con ${config.prefix}delpack ${newName}`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            packsDB[senderNumber][newName] = packsDB[senderNumber][oldName];
            packsDB[senderNumber][newName].name = newName;
            delete packsDB[senderNumber][oldName];
            
            savePacksDB(packsDB);
            
            const stickerCount = packsDB[senderNumber][newName].stickers.length;
            
            await sock.sendMessage(from, {
                text: `《✧》Pack renombrado exitosamente`,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
        } catch (error) {
            console.error('❌ Error en renamepack:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ Error: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};