import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'getfile',
    alias: [],

    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;

            if (usersDB && senderNumber &&!usersDB[senderNumber]) {
                await sock.sendMessage(from, { text: `🍒 Registrate primero.\n> Uso : ${config.prefix}reg` }, { quoted: msg });
                return;
            }

            const isOwner = config.owner && config.owner.some(num =>
                num.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            if (!isOwner) {
                await sock.sendMessage(from, {
                    text: ` ๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}getfile\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help ⍴ᥲrᥲ ᥎ᥱr mіs ᥴ᥆mᥲᥒძ᥆s`,
                    contextInfo: { mentionedJid: [senderJid], forwardingScore: 9999999, isForwarded: true }
                }, { quoted: msg });
                return;
            }

            if (!args[0]) {
                await sock.sendMessage(from, { text: `💐 Debes dar la ruta del archivo` }, { quoted: msg });
                return;
            }

            const fileName = args[0];
            if (fileName.includes('..')) {
                await sock.sendMessage(from, { text: `💐 Nombre no válido` }, { quoted: msg });
                return;
            }

            const baseDir = path.join(__dirname, '..');
            const filePath = path.join(baseDir, fileName);

            if (!fs.existsSync(filePath)) {
                await sock.sendMessage(from, { text: `💐 Archivo no existe` }, { quoted: msg });
                return;
            }

            const buffer = fs.readFileSync(filePath);
            const baseName = path.basename(fileName);
            const ext = path.extname(fileName).toLowerCase();
            const mime = ext === '.json'? 'application/json' : ext === '.sh'? 'application/x-sh' : 'text/javascript';

            await sock.sendMessage(from, {
                document: buffer,
                mimetype: mime,
                fileName: baseName,
                contextInfo: { mentionedJid: [senderJid], forwardingScore: 9999999, isForwarded: true }
            }, { quoted: msg });

        } catch (error) {
            await sock.sendMessage(msg.key.remoteJid, {
                text: `💐 Error\n> ${error.message.substring(0,100)}`,
                contextInfo: { forwardingScore: 9999999, isForwarded: true }
            }, { quoted: msg });
        }
    }
};