import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'top2',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            console.log(`📊 Comando top2 ejecutado por: ${senderNumber}`);

            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            // Verificar si el comando se usa en un grupo
            if (!from.includes('@g.us')) {
                await sock.sendMessage(from, {
                    text: '🍓 Este comando solo puede usarse en grupos.',
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Verificar argumentos
            if (!args || args.length === 0) {
                await sock.sendMessage(from, {
                    text: `🍒 Formato: ${config.prefix}top2 <palabra>\n> Ejemplo: ${config.prefix}top2 gays`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const palabra = args.join(' ').trim();
            
            if (!palabra) {
                await sock.sendMessage(from, {
                    text: `🍓 Debes proporcionar una palabra\n> Ejemplo: ${config.prefix}top2 gays`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Obtener lista de participantes del grupo
            const groupMetadata = await sock.groupMetadata(from);
            const participants = groupMetadata.participants;
            
            if (participants.length === 0) {
                await sock.sendMessage(from, {
                    text: '🔖 No hay participantes en el grupo.',
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Lista extensa de emojis para el título (selección aleatoria)
            const titleEmojis = [
                '🍡', '🧁', '🗣️', '🍕', '💫', '🙀', '🌹', '🪴', '🎉', '🍓',
                '🥭', '🍙', '🌾', '🌙', '🏳️‍🌈', '🏳️‍⚧️', '🎁', '💈', '🐬', '🤡',
                '🍨', '🍧', '🎀', '🌸', '⚡', '🌟', '🎭', '🎪', '🎯', '🎮',
                '🏆', '🎖️', '🥇', '🥈', '🥉', '💎', '🔮', '🎊', '🎐', '🎏',
                '🦋', '🐇', '🐾', '🌺', '🌼', '🌻', '🌷', '💐', '🍄', '🌰',
                '🎨', '🧩', '🎲', '♟️', '🎳', '🏓', '🏸', '🥏', '🎱', '🤿',
                '⛸️', '🎿', '🛷', '🥌', '🏒', '🏑', '🥍', '🏏', '🎣', '🥊',
                '🤼', '🤸', '⛹️', '🤾', '🏌️', '🏇', '🧘', '🏄', '🏊', '🤽',
                '🚣', '🧗', '🚵', '🚴', '🤹', '🎪', '🎭', '🎟️', '🎫', '🎼',
                '🎵', '🎶', '🎤', '🎧', '🎷', '🎸', '🎹', '🎺', '🎻', '🥁',
                '📱', '💻', '🖥️', '🖨️', '⌨️', '🖱️', '🖲️', '💽', '💾', '💿',
                '📀', '📼', '📷', '📸', '📹', '🎥', '📽️', '🎞️', '📞', '☎️',
                '📟', '📠', '📺', '📻', '🎙️', '🎚️', '🎛️', '🧭', '⏱️', '⏲️',
                '⏰', '🕰️', '⌛', '⏳', '📡', '🔋', '🔌', '💡', '🔦', '🕯️',
                '🪔', '🧯', '🛢️', '💸', '💵', '💴', '💶', '💷', '💰', '💳',
                '💎', '⚖️', '🧰', '🔧', '🔨', '⚒️', '🛠️', '⛏️', '🔩', '⚙️',
                '🧱', '⛓️', '🧲', '🔫', '💣', '🧨', '🪓', '🔪', '🗡️', '⚔️',
                '🛡️', '🚬', '⚰️', '⚱️', '🏺', '🔮', '📿', '💈', '⚗️', '🔭',
                '🔬', '🕳️', '🩹', '🩺', '💊', '💉', '🩸', '🧬', '🦠', '🧫',
                '🧪', '🌡️', '🧹', '🧺', '🧻', '🚽', '🚰', '🚿', '🛁', '🛀',
                '🧼', '🪒', '🧽', '🧴', '🛎️', '🔑', '🗝️', '🚪', '🪑', '🛋️',
                '🛏️', '🛌', '🧸', '🖼️', '🛍️', '🛒', '🎁', '🎈', '🎏', '🎀',
                '🎊', '🎉', '🎎', '🏮', '🎐', '✉️', '📩', '📨', '📧', '💌',
                '📥', '📤', '📦', '🏷️', '📪', '📫', '📬', '📭', '📮', '📯',
                '📜', '📃', '📄', '📑', '🧾', '📊', '📈', '📉', '🗒️', '🗓️',
                '📆', '📅', '🗑️', '📇', '🗃️', '🗳️', '🗄️', '📋', '📁', '📂',
                '🗂️', '🗞️', '📰', '📓', '📔', '📒', '📕', '📗', '📘', '📙',
                '📚', '📖', '🔖', '🧷', '🔗', '📎', '🖇️', '📐', '📏', '🧮',
                '📌', '📍', '✂️', '🖊️', '🖋️', '✒️', '🖌️', '🖍️', '📝', '✏️',
                '🔍', '🔎', '🔏', '🔐', '🔒', '🔓'
            ];

            // Seleccionar emoji aleatorio para el título
            const randomTitleEmoji = titleEmojis[Math.floor(Math.random() * titleEmojis.length)];

            // Seleccionar participantes aleatorios únicos (máximo 10 o los que haya)
            const maxParticipants = Math.min(participants.length, 10);
            const selectedParticipants = [];
            const usedIndexes = new Set();
            
            while (selectedParticipants.length < maxParticipants && usedIndexes.size < participants.length) {
                const randomIndex = Math.floor(Math.random() * participants.length);
                if (!usedIndexes.has(randomIndex)) {
                    usedIndexes.add(randomIndex);
                    selectedParticipants.push(participants[randomIndex]);
                }
            }

            // Construir el mensaje del top
            let topMessage = `${randomTitleEmoji} *Top ${maxParticipants} ${palabra}* ${randomTitleEmoji}\n\n`;
            
            const mentions = [];
            selectedParticipants.forEach((participant, index) => {
                const participantNumber = participant.id.split('@')[0];
                topMessage += `🍒 ${index + 1} » @${participantNumber}\n`;
                mentions.push(participant.id);
            });

            // Obtener el usuario del top 1 para la imagen
            const top1User = selectedParticipants[0].id;

            try {
                // Intentar obtener la foto de perfil del top 1
                const ppUrl = await sock.profilePictureUrl(top1User, 'image');
                
                if (ppUrl) {
                    await sock.sendMessage(from, {
                        image: { url: ppUrl },
                        caption: topMessage,
                        contextInfo: {
                            mentionedJid: mentions,
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                } else {
                    throw new Error('No profile picture');
                }
            } catch (error) {
                console.log('❌ No se pudo obtener foto de perfil, usando imagen por defecto:', error.message);
                
                // Usar imagen por defecto
                const defaultImagePath = path.join(__dirname, '..', 'img', 'icon.jpg');
                
                try {
                    if (fs.existsSync(defaultImagePath)) {
                        await sock.sendMessage(from, {
                            image: fs.readFileSync(defaultImagePath),
                            caption: topMessage,
                            contextInfo: {
                                mentionedJid: mentions,
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                    } else {
                        // Si no existe la imagen por defecto, enviar solo texto
                        await sock.sendMessage(from, {
                            text: topMessage,
                            contextInfo: {
                                mentionedJid: mentions,
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                    }
                } catch (defaultImageError) {
                    console.log('❌ Error con imagen por defecto:', defaultImageError.message);
                    
                    // Fallback final: solo texto
                    await sock.sendMessage(from, {
                        text: topMessage,
                        contextInfo: {
                            mentionedJid: mentions,
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
            }

            console.log(`✅ Top2 generado por ${pushName || senderNumber}: ${palabra} (${maxParticipants} participantes)`);

        } catch (error) {
            console.error('❌ Error en comando top2:', error);
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❖ Error al generar el top: ${error.message}`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};