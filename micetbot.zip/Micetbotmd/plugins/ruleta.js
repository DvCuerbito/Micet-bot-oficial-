export default {
    name: 'ruleta',
    alias: ['roulette'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            // Verificar que sea un grupo
            if (!from.endsWith('@g.us')) {
                return;
            }
            
            // Obtener metadata del grupo
            let groupMetadata;
            try {
                groupMetadata = await sock.groupMetadata(from);
            } catch (error) {
                return;
            }
            
            // Verificar si el usuario es admin del grupo
            const isGroupAdmin = groupMetadata.participants.find(p => {
                if (p.id === senderJid) return true;
                if (p.id.includes(senderNumber || '')) return true;
                if (senderJid && senderJid.includes('@lid')) {
                    const senderNum = senderJid.split('@')[0];
                    if (p.id.includes(senderNum)) return true;
                }
                return false;
            })?.admin;
            
            // Verificar si es owner del bot
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isGroupAdmin && !isOwner) {
                await sock.sendMessage(from, {
                    text: `🌠 Solo administradores del grupo pueden usar este comando.`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            try {
                // Obtener todos los participantes del grupo
                const participants = groupMetadata.participants;
                const botJid = sock.user.id;
                
                // Excluir al bot y a los administradores de la ruleta
                const eligibleUsers = participants.filter(p => {
                    const isBot = p.id === botJid || p.id === botJid?.split(':')[0] + '@s.whatsapp.net';
                    const isAdmin = p.admin === 'admin' || p.admin === 'superadmin';
                    return !isBot && !isAdmin;
                });
                
                if (eligibleUsers.length === 0) {
                    await sock.sendMessage(from, {
                        text: `🌠 No hay usuarios no administradores para eliminar en el grupo.`,
                        contextInfo: {
                            mentionedJid: [senderJid],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    return;
                }
                
                // Seleccionar un usuario aleatorio
                const randomIndex = Math.floor(Math.random() * eligibleUsers.length);
                const selectedUser = eligibleUsers[randomIndex].id;
                const selectedNumber = selectedUser.split('@')[0];
                
                // Intentar eliminar al usuario seleccionado
                try {
                    await sock.groupParticipantsUpdate(from, [selectedUser], 'remove');
                    
                    // Mensaje de éxito
                    await sock.sendMessage(from, {
                        text: `> 🌠 Se eliminó a @${selectedNumber}`,
                        mentions: [selectedUser],
                        contextInfo: {
                            mentionedJid: [selectedUser, senderJid],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    
                    console.log(`\x1b[1;32m✅ Ruleta: Usuario ${selectedNumber} eliminado por ${senderNumber}\x1b[0m`);
                    
                } catch (error) {
                    console.log(`\x1b[1;31m❌ Error en ruleta al eliminar: ${error.message}\x1b[0m`);
                    
                    if (error.message.includes('not authorized') || error.message.includes('forbidden') || error.message.includes('admin')) {
                        await sock.sendMessage(from, {
                            text: `🌠 *${config.name}* debe ser administrador del grupo para eliminar a un usuario.`,
                            contextInfo: {
                                mentionedJid: [senderJid],
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                    } else {
                        await sock.sendMessage(from, {
                            text: `🌠 Error al eliminar al usuario: ${error.message}`,
                            contextInfo: {
                                mentionedJid: [senderJid],
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                    }
                }
                
            } catch (error) {
                console.log(`\x1b[1;31m❌ Error en ruleta: ${error.message}\x1b[0m`);
                
                await sock.sendMessage(from, {
                    text: `🌠 Error al ejecutar la ruleta: ${error.message}`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
        } catch (error) {
            console.error('❌ Error en ruleta:', error);
        }
    }
};