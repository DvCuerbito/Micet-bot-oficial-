import { sticker } from '../lib/sticker.js';
import axios from 'axios';

export default {
    name: 'qc',
    alias: ['quote', 'quotly'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍒 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Sumi.18`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);

            // Obtener texto del mensaje
            let text;
            
            if (args && args.length >= 1) {
                text = args.join(" ");
            } else if (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
                // Si hay mensaje citado, obtener su texto
                const quotedMsg = msg.message.extendedTextMessage.contextInfo.quotedMessage;
                if (quotedMsg.conversation) {
                    text = quotedMsg.conversation;
                } else if (quotedMsg.extendedTextMessage?.text) {
                    text = quotedMsg.extendedTextMessage.text;
                }
            }

            if (!text) {
                await sock.sendMessage(from, { 
                    text: `📌 Te faltó el texto!\n\nEjemplo: *${config.prefix}qc* Hola mundo`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // Verificar longitud del texto (máximo 40 caracteres)
            if (text.length > 40) {
                await sock.sendMessage(from, { 
                    text: `📌 El texto no puede tener más de 40 caracteres\n\nTu texto tiene: *${text.length}* caracteres`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            // React de espera
            await sock.sendMessage(from, {
                react: { text: "🕒", key: msg.key }
            });

            // Obtener nombre del perfil de WhatsApp del usuario
            let userName = pushName || senderNumber; // Valor por defecto
            
            try {
                // Usar la función getName de baileys para obtener el nombre real del perfil
                const whatsappName = await sock.getName(senderJid).catch(() => null);
                
                if (whatsappName && whatsappName.trim() !== '') {
                    userName = whatsappName;
                } else if (usersDB[senderNumber]?.name) {
                    // Si no se puede obtener el nombre de WhatsApp, usar el nombre del registro
                    userName = usersDB[senderNumber].name;
                }
            } catch (nameError) {
                console.log('No se pudo obtener el nombre de WhatsApp:', nameError);
            }

            // Intentar obtener la foto de perfil del usuario
            let profilePictureUrl = "https://telegra.ph/file/24fa902ead26340f3df2c.png"; // Avatar por defecto
            
            try {
                const profilePic = await sock.profilePictureUrl(senderJid, 'image').catch(() => null);
                if (profilePic) {
                    profilePictureUrl = profilePic;
                }
            } catch (profileError) {
                console.log('No se pudo obtener la foto de perfil:', profileError);
            }

            // Crear objeto para la API de quotes
            const obj = {
                "type": "quote",
                "format": "png",
                "backgroundColor": "#000000",
                "width": 512,
                "height": 768,
                "scale": 2,
                "messages": [{
                    "entities": [],
                    "avatar": true,
                    "from": {
                        "id": 1,
                        "name": userName,
                        "photo": { 
                            url: profilePictureUrl
                        }
                    },
                    "text": text,
                    "replyMessage": {}
                }]
            };

            // Generar la imagen de quote
            const json = await axios.post('https://bot.lyo.su/quote/generate', obj, { 
                headers: { 'Content-Type': 'application/json' },
                timeout: 30000
            });

            if (!json.data?.result?.image) {
                throw new Error('No se pudo generar la imagen');
            }

            const buffer = Buffer.from(json.data.result.image, 'base64');

            // Crear sticker (sin packname ni autor específico)
            const stiker = await sticker(buffer, false, '', '');

            if (!stiker) {
                throw new Error('No se pudo crear el sticker');
            }

            // Enviar sticker
            await sock.sendMessage(from, { 
                sticker: stiker,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            // React de éxito
            await sock.sendMessage(from, {
                react: { text: "✅", key: msg.key }
            });

        } catch (error) {
            console.error('❌ Error en comando qc:', error);
            
            // React de error
            await sock.sendMessage(msg.key.remoteJid, {
                react: { text: "❌", key: msg.key }
            });
            
            await sock.sendMessage(msg.key.remoteJid, { 
                text: `⚠︎ Se ha producido un problema.\n> Usa *${options.config.prefix}report* para informarlo.\n\nError: ${error.message}`,
                contextInfo: {
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config.canalNombre || ''
                    },
                    forwardingScore: 9999999,
                    isForwarded: true
                }
            }, { quoted: msg });
        }
    }
};