import fs from 'fs';
import path from 'path';
import axios from 'axios';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'neko',
    alias: [],
    
    async execute(sock, msg, options) {
        const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
        const from = msg.key.remoteJid;
        
        try {
            // Verificar registro (usando senderNumber)
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                const reply = 'ৎ꯭᪲୨֟ Para usar mis comandos tienes que estar registrado.\n> Uso : ' + config.prefix + 'reg Misa.16';
                return await sock.sendMessage(from, { 
                    text: reply,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }

            // Mostrar que está procesando
            await sock.sendPresenceUpdate('composing', from);
            
            // Tipos de neko disponibles
            const nekoTypes = [
                'neko', 'husbando', 'kitsune', 'waifu',
                'cuddle', 'hug', 'kiss', 'pat', 'smug',
                'bonk', 'blush', 'smile', 'wave', 'handhold',
                'nom', 'bite', 'glomp', 'slap', 'kill',
                'happy', 'wink', 'poke', 'dance', 'cringe'
            ];

            let type = 'neko'; // Por defecto
            
            // Verificar si se especificó un tipo
            if (args && args[0]) {
                const requestedType = args[0].toLowerCase();
                if (nekoTypes.includes(requestedType)) {
                    type = requestedType;
                }
            }

            // Determinar categoría (sfw por defecto)
            let category = 'sfw';
            if (args && args[1] && (args[1].toLowerCase() === 'nsfw' || args[1].toLowerCase() === '+18')) {
                category = 'nsfw';
            }

            // Obtener neko aleatoria
            const response = await axios({
                method: 'GET',
                url: `https://nekos.life/api/v2/img/${type}`,
                timeout: 10000
            });

            const imageUrl = response.data?.url;

            if (!imageUrl) {
                throw new Error('No se pudo obtener la imagen');
            }

            // Descargar imagen
            const imageResponse = await axios({
                method: 'GET',
                url: imageUrl,
                responseType: 'arraybuffer',
                timeout: 15000
            });

            const tempDir = path.join(__dirname, '..', 'temp');
            const tempPath = path.join(tempDir, `neko_${Date.now()}.jpg`);
            
            // Asegurar que existe el directorio temp
            if (!fs.existsSync(tempDir)) {
                fs.mkdirSync(tempDir, { recursive: true });
            }

            // Guardar temporalmente
            fs.writeFileSync(tempPath, imageResponse.data);

            // Preparar caption
            const caption = `🐱 *Neko para ${pushName || 'ti'}*\n` +
                          `🐱 *Tipo:* ${type}\n` +
                          `🐱 *Categoría:* ${category.toUpperCase()}\n` +
                          `🐱 *Nyaa~*`;

            // Enviar imagen
            await sock.sendMessage(from, {
                image: fs.readFileSync(tempPath),
                caption: caption,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            // Eliminar archivo temporal
            fs.unlinkSync(tempPath);

            console.log(`✅ Neko enviada a ${pushName || senderNumber || 'usuario'} (${type})`);

        } catch (error) {
            console.error("❌ Error en neko:", error);
            
            try {
                const reply = "🥕 Ocurrió un error obteniendo neko.\n> Error: " + error.message;
                await sock.sendMessage(from, { 
                    text: reply,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
};
