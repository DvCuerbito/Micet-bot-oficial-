import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const execAsync = promisify(exec);

export default {
    name: 'mp4',
    alias: ['ytmp4'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            const query = args.join(' ').trim();
            
            if (!query) {
                return await sock.sendMessage(from, {
                    text: `🌽 Debes proporcionar el nombre o link de una canción`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            await sock.sendPresenceUpdate('composing', from);
            
            try {
                await sock.sendMessage(from, { react: { text: '🎬', key: msg.key } });
            } catch (e) {}
            
            const tempDir = path.join(__dirname, '..', 'temp');
            if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
            
            const outputPath = path.join(tempDir, `video_${Date.now()}.mp4`);
            
            // Ruta del archivo de cookies
            const cookiesPath = path.join(process.cwd(), 'cookies.txt');
            let cookiesOption = '';
            
            if (fs.existsSync(cookiesPath)) {
                cookiesOption = `--cookies "${cookiesPath}"`;
                console.log('✅ Usando archivo de cookies');
            }
            
            // Ruta de yt-dlp portable
            const ytDlpPath = path.join(process.cwd(), 'yt-dlp');
            
            // Usar Node.js como runtime
            const jsRuntime = '--js-runtimes node';
            
            // Primero obtener información del video
            let infoCommand;
            if (query.includes('youtu.be') || query.includes('youtube.com')) {
                infoCommand = `"${ytDlpPath}" ${jsRuntime} ${cookiesOption} -j "${query}"`;
            } else {
                infoCommand = `"${ytDlpPath}" ${jsRuntime} ${cookiesOption} -j "ytsearch1:${query}"`;
            }
            
            console.log(`📥 Obteniendo información: ${infoCommand}`);
            
            const { stdout: infoStdout } = await execAsync(infoCommand, { timeout: 30000, cwd: process.cwd() });
            const videoInfo = JSON.parse(infoStdout);
            
            // Extraer información del video
            const videoTitle = videoInfo?.title || 'Sin título';
            const videoChannel = videoInfo?.channel || videoInfo?.uploader || 'Canal desconocido';
            const videoUrl = videoInfo?.webpage_url || videoInfo?.original_url || query;
            const videoThumbnail = videoInfo?.thumbnail || '';
            
            // Descargar video
            let downloadCommand;
            if (query.includes('youtu.be') || query.includes('youtube.com')) {
                downloadCommand = `"${ytDlpPath}" ${jsRuntime} -f "best[height<=480]" ${cookiesOption} -o "${outputPath}" "${query}"`;
            } else {
                downloadCommand = `"${ytDlpPath}" ${jsRuntime} -f "best[height<=480]" ${cookiesOption} -o "${outputPath}" "ytsearch1:${query}"`;
            }
            
            console.log(`📥 Descargando video: ${downloadCommand}`);
            
            await execAsync(downloadCommand, { timeout: 180000, cwd: process.cwd() });
            
            if (!fs.existsSync(outputPath)) {
                throw new Error('No se pudo descargar el video');
            }
            
            const stats = fs.statSync(outputPath);
            const sizeMB = (stats.size / 1024 / 1024).toFixed(2);
            
            // Descargar miniatura
            let thumbnailBuffer = null;
            if (videoThumbnail) {
                try {
                    const thumbResponse = await axios.get(videoThumbnail, {
                        responseType: 'arraybuffer',
                        timeout: 10000
                    });
                    thumbnailBuffer = Buffer.from(thumbResponse.data);
                } catch (e) {
                    console.log('Error descargando miniatura:', e.message);
                }
            }
            
            // Mensaje con información del video
            const caption = `あ🏮 *Título* » ${videoTitle}\n` +
                          `あ🏮 *Canal* » ${videoChannel}\n` +
                          `あ🏮 *Tamaño* » ${sizeMB} MB\n` +
                          `あ🏮 *Link* » ${videoUrl}`;
            
            // Enviar imagen con información
            if (thumbnailBuffer) {
                await sock.sendMessage(from, {
                    image: thumbnailBuffer,
                    caption: caption,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, {
                    text: caption,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            // Enviar el video
            const videoBuffer = fs.readFileSync(outputPath);
            
            await sock.sendMessage(from, {
                video: videoBuffer,
                mimetype: 'video/mp4',
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            // Limpiar archivos temporales
            setTimeout(() => {
                try { if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch (e) {}
            }, 10000);
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Video enviado por ${pushName || 'Usuario'}: ${videoTitle} (${sizeMB} MB)`);
            
        } catch (error) {
            console.error('❌ Error en mp4:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ *Error:* ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};