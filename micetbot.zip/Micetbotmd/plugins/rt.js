import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 0,
            minerals: {
                piedras: 0,
                diamantes: 0,
                esmeraldas: 0,
                oro: 0
            },
            health: 100,
            lastMine: 0,
            lastWork: 0,
            lastCrime: 0,
            lastAdventure: 0,
            lastClaim: 0,
            lastChest: 0,
            items: {
                agua: 0,
                vendas: 0,
                pastillas: 0
            }
        };
    }
    return economy[userNumber];
}

// Números de la ruleta
const redNumbers = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];
const blackNumbers = [2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35];

export default {
    name: 'rt',
    alias: ['ruleta', 'roulette', 'rojo', 'negro', 'red', 'black'],
    
    async execute(sock, msg, options) {
        try {
            const { 
                config, 
                senderNumber, 
                pushName,
                replyWithContext,
                senderJid,
                args 
            } = options;
            
            if (!senderNumber) {
                return await replyWithContext(
                    '❌ No se pudo identificar tu número',
                    [senderJid]
                );
            }
            
            // Verificar argumentos
            if (!args || args.length < 2) {
                return await replyWithContext(
                    `🎰 *RULETA - ROJO O NEGRO*\n\n` +
                    `> Uso: ${config.prefix}rt [rojo/negro] [cantidad]\n` +
                    `> Ejemplo: ${config.prefix}rt rojo 100\n` +
                    `> Ejemplo: ${config.prefix}rt negro 50\n\n` +
                    `> También puedes: ${config.prefix}rt 100 rojo`,
                    [senderJid]
                );
            }
            
            let eleccion = '';
            let apuesta = 0;
            
            // Determinar formato (elección/cantidad o cantidad/elección)
            if (args[0].match(/^\d+$/)) {
                // Formato: cantidad elección
                apuesta = parseInt(args[0]);
                eleccion = args[1].toLowerCase();
            } else {
                // Formato: elección cantidad
                eleccion = args[0].toLowerCase();
                apuesta = parseInt(args[1]);
            }
            
            // Validar elección
            if (eleccion !== 'rojo' && eleccion !== 'negro' && 
                eleccion !== 'red' && eleccion !== 'black') {
                return await replyWithContext(
                    '❌ Debes elegir *rojo* o *negro*',
                    [senderJid]
                );
            }
            
            // Normalizar a rojo/negro
            if (eleccion === 'red') eleccion = 'rojo';
            if (eleccion === 'black') eleccion = 'negro';
            
            // Validar apuesta
            if (isNaN(apuesta) || apuesta < 1) {
                return await replyWithContext(
                    '❌ La cantidad debe ser un número positivo',
                    [senderJid]
                );
            }
            
            let economy = loadEconomy();
            const user = initUserEconomy(economy, senderNumber, pushName);
            
            // Verificar si tiene suficientes coins
            if (user.coins < apuesta) {
                return await replyWithContext(
                    `❌ No tienes suficientes coins\n` +
                    `> Apostaste: *${apuesta}* coins\n` +
                    `> Tienes: *${user.coins}* coins`,
                    [senderJid]
                );
            }
            
            // Restar la apuesta
            user.coins -= apuesta;
            
            // Girar ruleta (0-36)
            const numero = Math.floor(Math.random() * 37); // 0 al 36
            
            let color = '';
            if (numero === 0) {
                color = 'verde';
            } else if (redNumbers.includes(numero)) {
                color = 'rojo';
            } else {
                color = 'negro';
            }
            
            const ganaste = eleccion === color;
            
            let mensaje = '';
            let coinsFinales = user.coins;
            
            if (ganaste) {
                const ganancia = apuesta * 2; // Recupera lo apostado + gana lo mismo
                user.coins += ganancia;
                coinsFinales = user.coins;
                
                mensaje = `🎰 *RULETA - ROJO O NEGRO*\n\n` +
                    `🎲 *Número:* ${numero} ${color === 'rojo' ? '🔴' : color === 'negro' ? '⚫' : '💚'}\n` +
                    `🎯 *Tu elección:* ${eleccion === 'rojo' ? '🔴 Rojo' : '⚫ Negro'}\n\n` +
                    `✅ *¡GANASTE!*\n\n` +
                    `💰 Apostaste: *${apuesta}* coins\n` +
                    `🎁 Ganaste: *${apuesta}* coins\n` +
                    `💎 Total: *${coinsFinales}* coins`;
            } else {
                coinsFinales = user.coins;
                
                mensaje = `🎰 *RULETA - ROJO O NEGRO*\n\n` +
                    `🎲 *Número:* ${numero} ${color === 'rojo' ? '🔴' : color === 'negro' ? '⚫' : '💚'}\n` +
                    `🎯 *Tu elección:* ${eleccion === 'rojo' ? '🔴 Rojo' : '⚫ Negro'}\n\n` +
                    `❌ *PERDISTE*\n\n` +
                    `💰 Apostaste: *${apuesta}* coins\n` +
                    `💔 Perdiste: *${apuesta}* coins\n` +
                    `💎 Total: *${coinsFinales}* coins`;
            }
            
            // Bonus si sale 0 (verde)
            if (numero === 0 && !ganaste) {
                mensaje += `\n\n💚 *¡Salió verde!* La casa gana esta vez`;
            }
            
            saveEconomy(economy);
            await replyWithContext(mensaje, [senderJid]);
            
        } catch (error) {
            console.error('❌ Error en comando rt:', error);
            await options.replyWithContext(
                `❌ Error: ${error.message}`,
                [options.senderJid]
            );
        }
    }
};
