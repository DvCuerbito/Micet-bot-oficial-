import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'setchannel',
    alias: ['setcanal'],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, args } = options;
            const from = msg.key.remoteJid;
            
            // ==========================================
            // OBTENER NÚMERO DEL BOT
            // ==========================================
            let botNumber = '';
            if (sock.phoneNumber) {
                botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            if (!botNumber) {
                throw new Error('No se pudo identificar el número del bot');
            }
            
            // ==========================================
            // VERIFICAR SI EL USUARIO ES EL BOTOWNER
            // ==========================================
            const isBotOwner = config.botowner && 
                              config.botowner.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '');
            
            if (!isBotOwner) {
                await sock.sendMessage(from, {
                    text: `❀ *Solo el dueño del bot puede cambiar su nombre de canal*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Verificar que se proporcionó un nombre
            if (!args || args.length === 0) {
                await sock.sendMessage(from, {
                    text: `🍭 Debes proporcionar un nombre\n` +
                          `> *Uso correcto:* ${config.prefix}setchannel +nombre`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Obtener el nuevo nombre
            let newName = args.join(' ');
            
            // Eliminar el '+' si está presente al inicio
            if (newName.startsWith('+')) {
                newName = newName.substring(1).trim();
            }
            
            // Verificar que el nombre no esté vacío
            if (!newName || newName.length === 0) {
                await sock.sendMessage(from, {
                    text: `🍭 *El nombre del canal no puede estar vacío*`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            // Limitar longitud (máx 50 caracteres)
            if (newName.length > 50) {
                await sock.sendMessage(from, {
                    text: `🍭 *El nombre del canal es demasiado largo*\n> Máximo 50 caracteres`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }
            
            try {
                console.log(`📢 Botowner ${senderNumber} está cambiando el nombre del canal del bot ${botNumber}...`);
                
                // ==========================================
                // RUTA DEL ARCHIVO DE CONFIGURACIÓN
                // ==========================================
                const configPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
                
                if (!fs.existsSync(configPath)) {
                    throw new Error(`No se encontró configuración para el bot ${botNumber}`);
                }
                
                console.log(`📝 Leyendo configuración actual de: ${configPath}`);
                
                // Leer el archivo actual
                let configContent = fs.readFileSync(configPath, 'utf8');
                
                // Extraer el objeto JSON
                const jsonMatch = configContent.match(/export default\s+({[\s\S]*})/);
                if (!jsonMatch || !jsonMatch[1]) {
                    throw new Error('Formato de archivo config.js inválido');
                }
                
                // Evaluar el objeto actual
                const currentConfig = eval('(' + jsonMatch[1] + ')');
                
                // ==========================================
                // ACTUALIZAR EL NOMBRE DEL CANAL
                // ==========================================
                const oldName = currentConfig.canalNombre || config.canalNombre || 'No definido';
                currentConfig.canalNombre = newName;
                
                // También actualizar canalId si no existe
                if (!currentConfig.canalId) {
                    currentConfig.canalId = config.canalId || '120363403616345878@newsletter';
                }
                
                console.log(`📝 Actualizando nombre del canal de "${oldName}" a "${newName}"`);
                
                // ==========================================
                // GUARDAR EL ARCHIVO ACTUALIZADO
                // ==========================================
                const newConfigContent = `// Configuración del Bot - ${currentConfig.tipo || 'Sub-Bot'}
// Creado para el número: ${botNumber}
// Actualizado el: ${new Date().toLocaleString()}

export default ${JSON.stringify(currentConfig, null, 2)}
`;
                
                fs.writeFileSync(configPath, newConfigContent);
                console.log(`✅ Configuración actualizada para bot ${botNumber}`);
                
                // ==========================================
                // ENVIAR CONFIRMACIÓN
                // ==========================================
                await sock.sendMessage(from, {
                    text: `🌽 Se ha actualizado el nombre del canal`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
            } catch (error) {
                console.error('Error en setchannel:', error);
                
                await sock.sendMessage(from, {
                    text: `📢 *Error al cambiar el nombre del canal*\n> ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
        } catch (error) {
            console.error('Error general en setchannel:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ Error inesperado en setchannel`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};