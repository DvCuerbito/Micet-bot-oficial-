import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function cleanJid(jid) {
    if (!jid) return jid;
    return jid.replace(/(:\d+)@/, '@');
}

function loadUsersDB() {
    try {
        const usersFile = path.join(__dirname, '..', 'databases', 'users.json');
        if (fs.existsSync(usersFile)) {
            const data = fs.readFileSync(usersFile, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando users.json:', error);
    }
    return {};
}

function extractNumberFromJid(jid) {
    if (!jid) return null;
    const clean = cleanJid(jid);
    return clean.split('@')[0].replace(/\D/g, '');
}

function getDisplayName(usersDB, userIdentifier, defaultName = 'Usuario') {
    try {
        if (!userIdentifier) return defaultName;
        
        const cleanIdentifier = cleanJid(userIdentifier);
        const userNumber = extractNumberFromJid(cleanIdentifier);
        
        if (userNumber && usersDB[userNumber]) {
            return usersDB[userNumber].pushName || usersDB[userNumber].name || userNumber;
        }
        
        for (const [num, userData] of Object.entries(usersDB)) {
            const cleanLid = userData.lid ? cleanJid(userData.lid) : null;
            const cleanJidData = userData.jid ? cleanJid(userData.jid) : null;
            
            if (cleanLid === cleanIdentifier || cleanJidData === cleanIdentifier) {
                return userData.pushName || userData.name || num;
            }
        }
        
        return userNumber || cleanIdentifier.split('@')[0] || defaultName;
        
    } catch (error) {
        console.error('Error obteniendo nombre para mostrar:', error);
        return defaultName;
    }
}

export default {
    name: 'cuddle',
    
    async execute(sock, msg, options) {
        try {
            const { config, pushName, senderNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            const usersDB = loadUsersDB();
            
            const user1Jid = senderJid;
            const userName1 = pushName || senderNumber || 'Usuario';
            
            let user2Jid = null;
            let userName2 = null;
            
            const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
            let mentionedJids = [];
            
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
                mentionedJids = msg.message.extendedTextMessage.contextInfo.mentionedJid;
            }
            
            if (mentionedJids && mentionedJids.length > 0) {
                user2Jid = cleanJid(mentionedJids[0]);
                userName2 = getDisplayName(usersDB, user2Jid, 'Usuario mencionado');
            }
            else if (quotedParticipant) {
                user2Jid = cleanJid(quotedParticipant);
                userName2 = getDisplayName(usersDB, user2Jid, 'Usuario citado');
            }
            
            if (!userName2) {
                userName2 = userName1;
            }

            const categoriesFile = path.join(__dirname, '..', 'databases', 'categories.json');
            let categories = {};
            
            if (fs.existsSync(categoriesFile)) {
                try {
                    categories = JSON.parse(fs.readFileSync(categoriesFile, 'utf8'));
                } catch (e) {
                    console.log('Error parsing categories.json:', e);
                }
            }

            const categoryName = 'cuddle';
            if (!categories[categoryName] || !categories[categoryName].videos?.length) {
                await sock.sendMessage(from, {
                    text: '❖ No hay GIFs disponibles en la categoría *cuddle*',
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const category = categories[categoryName];
            const randomIndex = Math.floor(Math.random() * category.videos.length);
            const videoInfo = category.videos[randomIndex];
            
            const descFile = path.join(__dirname, '..', 'databases', 'gif_descriptions.json');
            let descriptions = {};
            let descriptionText = `${userName1} ${categoryName} a ${userName2}`;
            
            if (fs.existsSync(descFile)) {
                try {
                    descriptions = JSON.parse(fs.readFileSync(descFile, 'utf8'));
                    
                    if (descriptions[categoryName]?.length > 0) {
                        const randomDescIndex = Math.floor(Math.random() * descriptions[categoryName].length);
                        const selectedDesc = descriptions[categoryName][randomDescIndex].text;
                        
                        descriptionText = selectedDesc
                            .replace(/\{user\}/g, userName1)
                            .replace(/\{user1\}/g, userName1)
                            .replace(/\{user2\}/g, userName2);
                    }
                } catch (e) {
                    console.log('Error parsing descriptions:', e);
                }
            }

            const videosDir = path.join(__dirname, '..', 'videos');
            const gifPath = path.join(videosDir, categoryName, videoInfo.filename);

            if (!fs.existsSync(gifPath)) {
                await sock.sendMessage(from, {
                    text: '❖ Error: El archivo GIF no existe.',
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }

            const gifBuffer = fs.readFileSync(gifPath);
            const mentions = [];
            if (senderJid) mentions.push(senderJid);
            if (user2Jid && user2Jid !== senderJid) mentions.push(user2Jid);

            try {
                await sock.sendMessage(from, {
                    video: gifBuffer,
                    caption: descriptionText,
                    gifPlayback: true,
                    mimetype: 'video/mp4',
                    fileName: `${categoryName}.mp4`,
                    mentions: mentions,
                    contextInfo: {
                        mentionedJid: mentions,
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
                console.log(`✅ Comando ${categoryName} ejecutado: ${userName1} -> ${userName2}`);
                
            } catch (error1) {
                console.log('❌ Error enviando como video:', error1);
                try {
                    await sock.sendMessage(from, {
                        image: gifBuffer,
                        caption: descriptionText,
                        mimetype: 'image/gif',
                        mentions: mentions,
                        contextInfo: {
                            mentionedJid: mentions,
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                } catch (error2) {
                    console.log('❌ Error enviando como imagen:', error2);
                    await sock.sendMessage(from, {
                        text: descriptionText,
                        mentions: mentions,
                        contextInfo: {
                            mentionedJid: mentions,
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
            }

        } catch (error) {
            console.log(`❌ Error en comando ${categoryName}:`, error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❖ Error al ejecutar el comando: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};
