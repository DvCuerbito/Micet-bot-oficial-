import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const API_URL = 'https://api-varhad.my.id/search/ytplay';

const tempFolder = path.join(__dirname, '..', 'tmp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `play2_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

export default {
    name: 'ytmp3doc',
    alias: ['mp3doc'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const query = args.join(' ').trim();
            
            if (!query) {
                await replyWithContext(
                    `🌸 Debes proporcionar el nombre de una canción`,
                    []
                );
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(`🌟 *Buscando:* ${query}...`, []);
            
            const response = await axios.get(`${API_URL}?q=${encodeURIComponent(query)}`, {
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (!response.data?.status || !response.data?.result) {
                throw new Error('No se encontró la canción');
            }
            
            const result = response.data.result;
            const title = result.title || 'Canción';
            const duration = result.duration || 'Desconocido';
            const thumbnail = result.thumbnail || '';
            const mp3Url = result.mp3;
            
            if (!mp3Url) {
                throw new Error('No se pudo obtener el enlace de descarga');
            }
            
            // Descargar thumbnail
            let thumbnailBuffer = null;
            if (thumbnail) {
                try {
                    const thumbResponse = await axios.get(thumbnail, { responseType: 'arraybuffer', timeout: 10000 });
                    thumbnailBuffer = Buffer.from(thumbResponse.data);
                } catch (e) {
                    console.log('Error descargando thumbnail:', e.message);
                }
            }
            
            // Descargar audio
            const audioResponse = await axios.get(mp3Url, {
                responseType: 'stream',
                timeout: 120000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Referer': 'https://savetube.me/'
                }
            });
            
            const tempPath = getTempFilePath('mp3');
            const writer = fs.createWriteStream(tempPath);
            
            await new Promise((resolve, reject) => {
                audioResponse.data.pipe(writer);
                writer.on('finish', resolve);
                writer.on('error', reject);
            });
            
            const audioBuffer = fs.readFileSync(tempPath);
            fs.unlinkSync(tempPath);
            
            const sizeMB = (audioBuffer.length / 1024 / 1024).toFixed(2);
            const cleanFilename = `${title.replace(/[^a-zA-Z0-9]/g, '_')}.mp3`;
            
            // Enviar thumbnail con la información
            if (thumbnailBuffer) {
                await sock.sendMessage(from, {
                    image: thumbnailBuffer,
                    caption: `> 🌵 *Nombre* » ${title}\n> 🌵 *Duración* » ${duration}\n> 🌵 *Tamaño* » ${sizeMB} MB`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await replyWithContext(
                    `> 🌵 *Nombre* » ${title}\n> 🌵 *Duración* » ${duration}\n> 🌵 *Tamaño* » ${sizeMB} MB`,
                    []
                );
            }
            
            // Enviar el audio
            await sock.sendMessage(from, {
                document: audioBuffer,
                mimetype: 'audio/mpeg',
                fileName: cleanFilename,
                caption: `> Solicitado por: ${pushName || 'Usuario'}`,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Canción descargada: ${title} (${sizeMB} MB) por ${pushName || 'Usuario'}`);
            
        } catch (error) {
            console.error('❌ Error en play2:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(
                `❌ *Error:* ${error.message}\n\n> No se encontró la canción. Intenta con otro nombre.`,
                []
            );
        }
    }
};