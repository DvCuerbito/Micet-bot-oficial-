import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'databases', 'economy.json');
const PETS_FILE = path.join(__dirname, '..', 'databases', 'pets.json');

// Lista completa de mascotas disponibles
const ALL_PETS = [
    { id: 1, name: 'Perro', price: 50000, emoji: '🐶', popular: false },
    { id: 2, name: 'Gato', price: 45000, emoji: '🐱', popular: false },
    { id: 3, name: 'Zorro', price: 60000, emoji: '🦊', popular: false },
    { id: 4, name: 'Panda', price: 80000, emoji: '🐼', popular: false },
    { id: 5, name: 'Pingüino', price: 55000, emoji: '🐧', popular: false },
    { id: 6, name: 'Loro', price: 40000, emoji: '🦜', popular: false },
    { id: 7, name: 'Tortuga', price: 65000, emoji: '🐢', popular: false },
    { id: 8, name: 'Unicornio', price: 150000, emoji: '🦄', popular: false },
    { id: 9, name: 'Dragón', price: 200000, emoji: '🐉', popular: false },
    { id: 10, name: 'Águila', price: 75000, emoji: '🦅', popular: false },
    { id: 11, name: 'Lobo', price: 85000, emoji: '🐺', popular: false },
    { id: 12, name: 'León', price: 130000, emoji: '🦁', popular: false },
    { id: 13, name: 'Mono', price: 45000, emoji: '🐒', popular: false },
    { id: 14, name: 'Conejo', price: 30000, emoji: '🐇', popular: false },
    { id: 15, name: 'Abeja', price: 25000, emoji: '🐝', popular: false },
    { id: 16, name: 'Búho', price: 70000, emoji: '🦉', popular: false },
    { id: 17, name: 'Pez', price: 20000, emoji: '🐟', popular: false },
    { id: 18, name: 'Mariposa', price: 25000, emoji: '🦋', popular: false },
    { id: 19, name: 'Elefante', price: 120000, emoji: '🐘', popular: false },
    { id: 20, name: 'Jirafa', price: 110000, emoji: '🦒', popular: false },
    { id: 21, name: 'Erizo', price: 35000, emoji: '🦔', popular: false },
    { id: 22, name: 'Cabra', price: 38000, emoji: '🐐', popular: false },
    { id: 23, name: 'Castor', price: 40000, emoji: '🦫', popular: false },
    { id: 24, name: 'Cangrejo', price: 30000, emoji: '🦀', popular: false },
    { id: 25, name: 'Gecko', price: 45000, emoji: '🦎', popular: false },
    { id: 26, name: 'Pavo real', price: 90000, emoji: '🦚', popular: false },
    { id: 27, name: 'Cisne', price: 70000, emoji: '🦢', popular: false },
    { id: 28, name: 'Ardilla', price: 30000, emoji: '🐿️', popular: false },
    { id: 29, name: 'Zorrillo', price: 40000, emoji: '🦨', popular: false },
    { id: 30, name: 'Nutria', price: 50000, emoji: '🦦', popular: false },
    { id: 31, name: 'Ratón', price: 15000, emoji: '🐁', popular: false },
    { id: 32, name: 'Gallo', price: 25000, emoji: '🐓', popular: false },
    { id: 33, name: 'Pavo', price: 35000, emoji: '🦃', popular: false },
    { id: 34, name: 'Perro lobo', price: 95000, emoji: '🐕', popular: false },
    { id: 35, name: 'Gato montés', price: 90000, emoji: '🐈', popular: false },
    { id: 36, name: 'Rinoceronte', price: 180000, emoji: '🦏', popular: false },
    { id: 37, name: 'Hipopótamo', price: 170000, emoji: '🦛', popular: false },
    { id: 38, name: 'Camello', price: 100000, emoji: '🐪', popular: false },
    { id: 39, name: 'Dromedario', price: 100000, emoji: '🐫', popular: false },
    { id: 40, name: 'Bisonte', price: 120000, emoji: '🦬', popular: false },
    { id: 41, name: 'Koala', price: 80000, emoji: '🐨', popular: false },
    { id: 42, name: 'Canguro', price: 90000, emoji: '🦘', popular: false },
    { id: 43, name: 'Cocodrilo', price: 140000, emoji: '🐊', popular: false },
    { id: 44, name: 'Foca', price: 70000, emoji: '🦭', popular: false },
    { id: 45, name: 'Ballena', price: 250000, emoji: '🐋', popular: false },
    { id: 46, name: 'Tiburón', price: 180000, emoji: '🦈', popular: true },
    { id: 47, name: 'Pulpo', price: 50000, emoji: '🐙', popular: false },
    { id: 48, name: 'Calamar', price: 45000, emoji: '🦑', popular: false },
    { id: 49, name: 'Caracol', price: 15000, emoji: '🐚', popular: false },
    { id: 50, name: 'Escorpión', price: 60000, emoji: '🦂', popular: false }
];

// Lista de comidas
const ALL_FOODS = [
    { id: 1, name: 'Carne', price: 500, emoji: '🍖', health: 20 },
    { id: 2, name: 'Pescado', price: 400, emoji: '🐟', health: 15 },
    { id: 3, name: 'Zanahoria', price: 300, emoji: '🥕', health: 10 },
    { id: 4, name: 'Manzana', price: 250, emoji: '🍎', health: 10 },
    { id: 5, name: 'Pollo', price: 600, emoji: '🍗', health: 25 },
    { id: 6, name: 'Bistec', price: 800, emoji: '🥩', health: 30 },
    { id: 7, name: 'Bambú', price: 1000, emoji: '🎋', health: 20 },
    { id: 8, name: 'Polvo mágico', price: 1500, emoji: '✨', health: 50 },
    { id: 9, name: 'Fuego', price: 2000, emoji: '🔥', health: 60 },
    { id: 10, name: 'Semillas', price: 350, emoji: '🌰', health: 10 },
    { id: 11, name: 'Lechuga', price: 300, emoji: '🥬', health: 10 },
    { id: 12, name: 'Plátano', price: 400, emoji: '🍌', health: 15 },
    { id: 13, name: 'Camarón', price: 600, emoji: '🦐', health: 20 },
    { id: 14, name: 'Hierba', price: 350, emoji: '🌿', health: 10 },
    { id: 15, name: 'Carne premium', price: 1200, emoji: '🍖', health: 45 },
    { id: 16, name: 'Salmón', price: 800, emoji: '🐟', health: 25 },
    { id: 17, name: 'Huevo', price: 200, emoji: '🥚', health: 8 },
    { id: 18, name: 'Miel', price: 500, emoji: '🍯', health: 15 },
    { id: 19, name: 'Queso', price: 400, emoji: '🧀', health: 12 },
    { id: 20, name: 'Sandía', price: 350, emoji: '🍉', health: 12 }
];

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            return JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando economía:', error);
        return {};
    }
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando economía:', error);
        return false;
    }
}

function loadPetsStore() {
    try {
        if (fs.existsSync(PETS_FILE)) {
            return JSON.parse(fs.readFileSync(PETS_FILE, 'utf8'));
        }
        return {};
    } catch (error) {
        console.error('Error cargando tienda:', error);
        return {};
    }
}

function savePetsStore(store) {
    try {
        fs.writeFileSync(PETS_FILE, JSON.stringify(store, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando tienda:', error);
        return false;
    }
}

function initUserEconomy(economy, userNumber, pushName) {
    if (!economy[userNumber]) {
        economy[userNumber] = {
            number: userNumber,
            name: pushName || 'Usuario',
            coins: 10000,
            bank: 0,
            pets: [],
            foods: [],
            store: null
        };
    }
    if (economy[userNumber].pets === undefined) economy[userNumber].pets = [];
    if (economy[userNumber].foods === undefined) economy[userNumber].foods = [];
    if (economy[userNumber].bank === undefined) economy[userNumber].bank = 0;
    if (economy[userNumber].store === undefined) economy[userNumber].store = null;
    return economy[userNumber];
}

function generateUserStore(existingPets = []) {
    // Filtrar mascotas que el usuario ya tiene
    const existingPetIds = existingPets.map(p => p.id);
    const availablePets = ALL_PETS.filter(p => !existingPetIds.includes(p.id));
    
    const shuffledPets = [...availablePets].sort(() => 0.5 - Math.random());
    const shuffledFoods = [...ALL_FOODS].sort(() => 0.5 - Math.random());
    
    return {
        pets: shuffledPets.slice(0, 4),
        foods: shuffledFoods.slice(0, 4),
        lastPetUpdate: Date.now(),
        lastFoodUpdate: Date.now()
    };
}

function updateUserStoreIfNeeded(userNumber, storeDB, userPets) {
    const now = Date.now();
    const restockTime = 2 * 60 * 60 * 1000; // 2 horas
    
    let userStore = storeDB[userNumber];
    
    if (!userStore) {
        userStore = generateUserStore(userPets);
        storeDB[userNumber] = userStore;
        savePetsStore(storeDB);
        return userStore;
    }
    
    let updated = false;
    
    if (!userStore.lastPetUpdate || (now - userStore.lastPetUpdate) > restockTime) {
        const existingPetIds = userPets.map(p => p.id);
        const availablePets = ALL_PETS.filter(p => !existingPetIds.includes(p.id));
        const shuffledPets = [...availablePets].sort(() => 0.5 - Math.random());
        userStore.pets = shuffledPets.slice(0, 4);
        userStore.lastPetUpdate = now;
        updated = true;
    }
    
    if (!userStore.lastFoodUpdate || (now - userStore.lastFoodUpdate) > restockTime) {
        const shuffledFoods = [...ALL_FOODS].sort(() => 0.5 - Math.random());
        userStore.foods = shuffledFoods.slice(0, 4);
        userStore.lastFoodUpdate = now;
        updated = true;
    }
    
    if (updated) {
        savePetsStore(storeDB);
    }
    
    return userStore;
}

export default {
    name: 'storepets',
    alias: ['buypets', 'petshop'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderNumber, pushName, replyWithContext, senderJid } = options;
            const from = msg.key.remoteJid;
            
            if (!senderNumber) {
                return await replyWithContext('❌ No se pudo identificar tu número', [senderJid]);
            }
            
            let economy = loadEconomy();
            let storeDB = loadPetsStore();
            const user = initUserEconomy(economy, senderNumber, pushName);
            
            // Obtener o generar tienda personal del usuario
            let userStore = updateUserStoreIfNeeded(senderNumber, storeDB, user.pets);
            
            const now = Date.now();
            const restockTime = 2 * 60 * 60 * 1000; // 2 horas
            
            const timeLeftPet = userStore.lastPetUpdate ? (restockTime - (now - userStore.lastPetUpdate)) : 0;
            const hoursLeftPet = Math.floor(timeLeftPet / (60 * 60 * 1000));
            const minutesLeftPet = Math.floor((timeLeftPet % (60 * 60 * 1000)) / (60 * 1000));
            
            // Comprar mascota
            if (args[0] && (args[0].toLowerCase() === 'buy' || args[0].toLowerCase() === 'comprar')) {
                const petId = parseInt(args[1]);
                
                if (isNaN(petId)) {
                    return await replyWithContext(
                        `🐾 *Comprar mascota*\n\n> Uso: ${config.prefix}storepets buy <id>\n> Ejemplo: ${config.prefix}storepets buy 1`,
                        [senderJid]
                    );
                }
                
                const selectedPet = userStore.pets.find(p => p.id === petId);
                
                if (!selectedPet) {
                    return await replyWithContext(`❌ Mascota no encontrada en tu tienda`, [senderJid]);
                }
                
                if (user.coins < selectedPet.price) {
                    return await replyWithContext(
                        `❌ No tienes suficientes coins\n\n` +
                        `> 🐾 *Mascota:* ${selectedPet.emoji} ${selectedPet.name}\n` +
                        `> 💰 *Precio:* ${selectedPet.price.toLocaleString()} coins\n` +
                        `> 💵 *Tienes:* ${user.coins.toLocaleString()} coins`,
                        [senderJid]
                    );
                }
                
                user.coins -= selectedPet.price;
                user.pets.push({
                    id: selectedPet.id,
                    name: selectedPet.name,
                    emoji: selectedPet.emoji,
                    health: 100,
                    purchasedAt: now
                });
                
                saveEconomy(economy);
                
                // Eliminar mascota de la tienda del usuario
                userStore.pets = userStore.pets.filter(p => p.id !== petId);
                savePetsStore(storeDB);
                
                return await replyWithContext(
                    `🛒 *Compra exitosa*\n\n🍀 *Pet* » ${selectedPet.emoji} ${selectedPet.name}\n💵 *Te quedan:* ${user.coins.toLocaleString()} coins`,
                    [senderJid]
                );
            }
            
            // Comprar comida
            if (args[0] && (args[0].toLowerCase() === 'buyfood' || args[0].toLowerCase() === 'comidapet')) {
                const foodId = parseInt(args[1]);
                
                if (isNaN(foodId)) {
                    return await replyWithContext(
                        `🍖 *Comprar comida*\n\n> Uso: ${config.prefix}storepets buyfood <id>\n> Ejemplo: ${config.prefix}storepets buyfood 1`,
                        [senderJid]
                    );
                }
                
                const selectedFood = userStore.foods.find(f => f.id === foodId);
                
                if (!selectedFood) {
                    return await replyWithContext(`❌ Comida no encontrada en tu tienda`, [senderJid]);
                }
                
                if (user.coins < selectedFood.price) {
                    return await replyWithContext(
                        `❌ No tienes suficientes coins\n\n` +
                        `> 🍖 *Comida:* ${selectedFood.emoji} ${selectedFood.name}\n` +
                        `> 💰 *Precio:* ${selectedFood.price.toLocaleString()} coins\n` +
                        `> 💵 *Tienes:* ${user.coins.toLocaleString()} coins`,
                        [senderJid]
                    );
                }
                
                user.coins -= selectedFood.price;
                user.foods.push({
                    id: selectedFood.id,
                    name: selectedFood.name,
                    emoji: selectedFood.emoji,
                    health: selectedFood.health
                });
                
                saveEconomy(economy);
                
                // Eliminar comida de la tienda del usuario
                userStore.foods = userStore.foods.filter(f => f.id !== foodId);
                savePetsStore(storeDB);
                
                return await replyWithContext(
                    `🍖 *Compra exitosa*\n\n🍽️ *Comida* » ${selectedFood.emoji} ${selectedFood.name}\n💵 *Te quedan:* ${user.coins.toLocaleString()} coins`,
                    [senderJid]
                );
            }
            
            // Mostrar tienda personal del usuario
            const popularPets = userStore.pets.filter(p => p.popular === true);
            const normalPets = userStore.pets.filter(p => p.popular !== true);
            
            const sections = [];
            
            if (popularPets.length > 0) {
                const popularRows = popularPets.map(pet => ({
                    title: `${pet.emoji} ${pet.name}`,
                    description: `💰 ${pet.price.toLocaleString()} coins`,
                    id: `${config.prefix}storepets buy ${pet.id}`
                }));
                
                sections.push({
                    title: "🐾 NUEVOS",
                    highlight_label: "POPULAR",
                    rows: popularRows
                });
            }
            
            if (normalPets.length > 0) {
                const normalRows = normalPets.map(pet => ({
                    title: `${pet.emoji} ${pet.name}`,
                    description: `💰 ${pet.price.toLocaleString()} coins`,
                    id: `${config.prefix}storepets buy ${pet.id}`
                }));
                
                sections.push({
                    title: "🐾 MASCOTAS",
                    rows: normalRows
                });
            }
            
            if (userStore.foods.length > 0) {
                const foodRows = userStore.foods.map(food => ({
                    title: `${food.emoji} ${food.name}`,
                    description: `💰 ${food.price.toLocaleString()} coins | +${food.health} salud`,
                    id: `${config.prefix}storepets buyfood ${food.id}`
                }));
                
                sections.push({
                    title: "🍖 COMIDAS",
                    rows: foodRows
                });
            }
            
            const message = `🛒 *Tu Tienda de Mascotas*\n\n⏰ *Reabastecimiento:* ${hoursLeftPet > 0 ? `${hoursLeftPet}h ${minutesLeftPet}m` : '¡Ahora mismo!'}\n💰 *Tus coins:* ${user.coins.toLocaleString()}\n📦 *Tus mascotas:* ${user.pets.length}\n🍖 *Tus comidas:* ${user.foods.length}\n\n> *Elige una para comprar*`;
            
            await sock.sendMessage(from, {
                text: message,
                footer: "🌙 Moonlight Pets",
                interactiveButtons: [
                    {
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "🛒 Tu Tienda",
                            sections: sections,
                        }),
                    },
                ],
            }, { quoted: msg });
            
        } catch (error) {
            console.error('❌ Error en storepets:', error);
            await replyWithContext(`❌ Error: ${error.message}`, [senderJid]);
        }
    }
};