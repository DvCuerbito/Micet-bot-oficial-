import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ALLOWED_RANKS = ['owner', 'c-owner', 'srmod', 'mod'];

function cleanNumber(jid) {
    if (!jid) return null;
    return jid.split('@')[0].replace(/[^0-9]/g, '');
}

export default {
    name: 'videolist',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber } = options;
            const from = msg.key.remoteJid;
            
            let userNumber = cleanNumber(msg.key.participant) || cleanNumber(msg.key.remoteJid);
            
            if (msg.key.fromMe) {
                userNumber = cleanNumber(sock.user?.id);
            }
            
            const userData = usersDB[senderNumber];
            const userRank = userData?.rank;
            const isAllowed = userRank && ALLOWED_RANKS.includes(userRank);
            
            const isOwner = config.owner && config.owner.some(ownerNum => 
                ownerNum.replace(/\D/g, '') === (senderNumber || '').replace(/\D/g, '')
            );
            
            if (!isOwner && !isAllowed) {
                await sock.sendMessage(from, {
                    text: `๑ֵ݊🍀 ᥱᥣ ᥴ᥆mᥲᥒძ᥆ \`${config.prefix}videolist\` ᥒ᥆ ᥱ᥊іs𝗍ᥱ.\n> ೯۪🎑̶ֵ ᥙsᥲ ${config.prefix}help`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }

            const categoriesFile = path.join(__dirname, '..', 'databases', 'categories.json');
            let categories = {};
            
            if (fs.existsSync(categoriesFile)) {
                categories = JSON.parse(fs.readFileSync(categoriesFile, 'utf8'));
            }

            const categoryNames = Object.keys(categories);
            
            if (categoryNames.length === 0) {
                await sock.sendMessage(from, {
                    text: '> ✩ No existen videos en la `db`',
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }

            let message = '*ꨄ⃝⃝⃟🌙- 𝙇𝙞𝙨𝙩𝙖 𝙙𝙚 𝙫𝙞𝙙𝙚𝙤𝙨 -「⭐̸ᩧ」*\n> *addvideo <categoría> (respondiendo a un gif)*\n\n';

            categoryNames.forEach(categoryName => {
                const category = categories[categoryName];
                const videoCount = category.videos?.length || 0;
                
                message += `*໒🍀໓়.* Nombre » *${categoryName}*\n`;
                message += `*໒🍀໓়.* Videos » *${videoCount}*\n\n`;
            });

            await sock.sendMessage(from, { text: message }, { quoted: msg });

        } catch (error) {
            console.error('Error en videolist:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❖ Error: ${error.message}`
            }, { quoted: msg });
        }
    }
};