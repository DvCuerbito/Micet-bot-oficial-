import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const API_URL = 'https://api.yupra.my.id/api/downloader/spotify';

const tempFolder = path.join(__dirname, '..', 'tmp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `spotify_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

export default {
    name: 'spotify',
    alias: ['sp', 'spotifydl'],
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const url = args.join(' ').trim();
            
            if (!url) {
                await replyWithContext(
                    `🌸 Debes proporcionar un enlace de Spotify`,
                    []
                );
                return;
            }
            
            if (!url.includes('spotify.com')) {
                await replyWithContext(
                    `❌ *Link inválido*\n\n> Debes proporcionar un enlace de Spotify válido.`,
                    []
                );
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(`🌟 *Buscando:* ${url}...`, []);
            
            const response = await axios.get(`${API_URL}?url=${encodeURIComponent(url)}`, {
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (!response.data?.status || !response.data?.result) {
                throw new Error('No se encontró la canción');
            }
            
            const result = response.data.result;
            const title = result.title || 'Canción';
            const artist = result.artist || 'Artista';
            const imageUrl = result.image || '';
            const downloadUrl = result.download?.url;
            
            if (!downloadUrl) {
                throw new Error('No se pudo obtener el enlace de descarga');
            }
            
            // Descargar thumbnail
            let thumbnailBuffer = null;
            if (imageUrl) {
                try {
                    const thumbResponse = await axios.get(imageUrl, { responseType: 'arraybuffer', timeout: 10000 });
                    thumbnailBuffer = Buffer.from(thumbResponse.data);
                } catch (e) {
                    console.log('Error descargando thumbnail:', e.message);
                }
            }
            
            // Descargar audio
            const audioResponse = await axios.get(downloadUrl, {
                responseType: 'stream',
                timeout: 120000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Referer': 'https://spotidown.app/'
                }
            });
            
            const tempPath = getTempFilePath('mp3');
            const writer = fs.createWriteStream(tempPath);
            
            await new Promise((resolve, reject) => {
                audioResponse.data.pipe(writer);
                writer.on('finish', resolve);
                writer.on('error', reject);
            });
            
            const audioBuffer = fs.readFileSync(tempPath);
            fs.unlinkSync(tempPath);
            
            const sizeMB = (audioBuffer.length / 1024 / 1024).toFixed(2);
            
            // Enviar thumbnail con la información
            if (thumbnailBuffer) {
                await sock.sendMessage(from, {
                    image: thumbnailBuffer,
                    caption: `> 🌵 *Nombre* » ${title}\n> 🌵 *Artista* » ${artist}\n> 🌵 *Tamaño* » ${sizeMB} MB\n> Solicitado por: ${pushName || 'Usuario'}`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await replyWithContext(
                    `> 🌵 *Nombre* » ${title}\n> 🌵 *Artista* » ${artist}\n> 🌵 *Tamaño* » ${sizeMB} MB\n> Solicitado por: ${pushName || 'Usuario'}`,
                    []
                );
            }
            
            // Enviar el audio como MP3 (reproducible)
            await sock.sendMessage(from, {
                audio: audioBuffer,
                mimetype: 'audio/mpeg',
                fileName: `${title.replace(/[^a-zA-Z0-9]/g, '_')}.mp3`,
                ptt: false,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Canción descargada: ${title} - ${artist} (${sizeMB} MB) por ${pushName || 'Usuario'}`);
            
        } catch (error) {
            console.error('❌ Error en spotify:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(
                `❌ *Error:* ${error.message}\n\n> Verifica que el enlace sea válido y vuelve a intentarlo.`,
                []
            );
        }
    }
};