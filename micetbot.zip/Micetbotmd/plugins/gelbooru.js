import axios from 'axios';
import * as cheerio from 'cheerio';

export default {
    name: 'imagen',
    alias: [],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // 🌸 Verificar registro (usando senderNumber)
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🌷 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg TuNombre`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
                return;
            }
            
            // 🌿 Obtener tags de búsqueda
            const searchTags = args.length > 0 ? args.join('_') : 'flower';
            
            // 🍃 Mensaje de espera
            await sock.sendMessage(from, {
                text: `🌺 *Buscando imagen*\n> Tags: ${searchTags.replace(/_/g, ' ')}\n🍀 Por favor espera un momento.`
            }, { quoted: msg });
            
            await sock.sendPresenceUpdate('composing', from);
            
            // 🌻 Hacer scraping de Gelbooru
            try {
                // PASO 1: Obtener lista de posts
                const listUrl = `https://gelbooru.com/index.php?page=post&s=list&tags=${searchTags}`;
                
                const listResponse = await axios.get(listUrl, {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                        'Accept-Language': 'es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3',
                        'Connection': 'keep-alive',
                        'Referer': 'https://gelbooru.com/'
                    }
                });
                
                // Cargar HTML con cheerio
                const $ = cheerio.load(listResponse.data);
                
                // 🌸 Buscar enlaces a posts individuales
                const postLinks = [];
                
                $('.thumbnail-preview a').each((i, el) => {
                    const href = $(el).attr('href');
                    if (href && href.includes('page=post&s=view&id=')) {
                        const fullUrl = href.startsWith('http') ? href : `https://gelbooru.com/${href}`;
                        postLinks.push(fullUrl);
                    }
                });
                
                const uniquePostLinks = [...new Set(postLinks)];
                
                if (uniquePostLinks.length === 0) {
                    await sock.sendMessage(from, {
                        text: `🌸 No encontré imágenes para "${searchTags.replace(/_/g, ' ')}".\n🌱 Prueba con otras palabras como: flower, nature, landscape, cherry_blossom.`,
                        contextInfo: {
                            mentionedJid: [senderJid],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    return;
                }
                
                // 🍃 Seleccionar un post aleatorio
                const randomPostUrl = uniquePostLinks[Math.floor(Math.random() * uniquePostLinks.length)];
                
                // PASO 2: Obtener la página del post
                const postResponse = await axios.get(randomPostUrl, {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                        'Referer': 'https://gelbooru.com/'
                    }
                });
                
                const $post = cheerio.load(postResponse.data);
                
                // 🌺 Buscar la imagen real
                let imageUrl = null;
                
                // Buscar en diferentes selectores
                const possibleSelectors = [
                    'meta[property="og:image"]',
                    'meta[name="twitter:image"]',
                    '#image',
                    '.original-file img',
                    'img[src*="images/"]',
                    'a[href*=".jpg"] img',
                    'a[href*=".png"] img'
                ];
                
                for (const selector of possibleSelectors) {
                    if (selector.startsWith('meta')) {
                        imageUrl = $post(selector).attr('content');
                    } else {
                        imageUrl = $post(selector).attr('src');
                    }
                    
                    if (imageUrl && (imageUrl.includes('.jpg') || imageUrl.includes('.png') || imageUrl.includes('.jpeg'))) {
                        break;
                    }
                }
                
                if (!imageUrl) {
                    throw new Error('No se encontró imagen');
                }
                
                // Asegurar URL absoluta
                if (!imageUrl.startsWith('http')) {
                    imageUrl = `https://gelbooru.com/${imageUrl}`;
                }
                
                // 🌷 PASO 3: Descargar la imagen como buffer
                const imageResponse = await axios.get(imageUrl, {
                    responseType: 'arraybuffer',
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                        'Referer': 'https://gelbooru.com/',
                        'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
                        'Accept-Language': 'es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3',
                        'Connection': 'keep-alive'
                    }
                });
                
                const imageBuffer = Buffer.from(imageResponse.data);
                
                // Determinar el mimetype
                let mimetype = 'image/jpeg';
                if (imageUrl.includes('.png')) {
                    mimetype = 'image/png';
                } else if (imageUrl.includes('.gif')) {
                    mimetype = 'image/gif';
                } else if (imageUrl.includes('.webp')) {
                    mimetype = 'image/webp';
                }
                
                // 🌼 Enviar la imagen como buffer
                await sock.sendMessage(from, {
                    image: imageBuffer,
                    mimetype: mimetype,
                    caption: `🌼 \`I M A G E N\`\n\n🌸 *Tags:* ${searchTags.replace(/_/g, ' ')}\n🌿 *Total encontradas:* ${uniquePostLinks.length}\n🍃 *Solicitado por:* @${senderNumber || senderJid?.split('@')[0] || 'usuario'}`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
                console.log(`🌺 Imagen de Gelbooru enviada a ${pushName || senderNumber || 'usuario'} - Tags: ${searchTags}`);
                
            } catch (scrapeError) {
                console.error('🍂 Error en scraping:', scrapeError);
                
                // 🌱 Fallback con imágenes de Unsplash (más confiables)
                const fallbackImages = [
                    'https://images.unsplash.com/photo-1490750967868-88aa4486c946?w=800', // Flores
                    'https://images.unsplash.com/photo-1470509037663-253afd7f0f51?w=800', // Naturaleza
                    'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800', // Bosque
                    'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800', // Paisaje
                    'https://images.unsplash.com/photo-1445964047600-cdbdb873673d?w=800'  // Atardecer
                ];
                
                const randomFallback = fallbackImages[Math.floor(Math.random() * fallbackImages.length)];
                
                // Descargar la imagen de fallback como buffer también
                try {
                    const fallbackResponse = await axios.get(randomFallback, {
                        responseType: 'arraybuffer',
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    
                    const fallbackBuffer = Buffer.from(fallbackResponse.data);
                    
                    await sock.sendMessage(from, {
                        image: fallbackBuffer,
                        caption: `🌱 *Imagen Aleatoria (Fallback)*\n\n🍂 No pude acceder a Gelbooru en este momento.\n🌸 Aquí tienes una imagen alternativa.\n\n🌿 *Solicitado por:* @${senderNumber || senderJid?.split('@')[0] || 'usuario'}`,
                        contextInfo: {
                            mentionedJid: [senderJid],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                } catch (fallbackError) {
                    // Si falla hasta el fallback, enviar solo mensaje
                    await sock.sendMessage(from, {
                        text: `🌧️ No pude obtener ninguna imagen.\n🌱 Intenta de nuevo más tarde.`,
                        contextInfo: {
                            mentionedJid: [senderJid],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
            }
            
        } catch (error) {
            console.error('❌ Error en comando gelbooru:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `🌧️ *Error:*\n\`\`\`${error.message}\`\`\`\n\n🌱 Intenta de nuevo más tarde.`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config?.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config?.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
};
