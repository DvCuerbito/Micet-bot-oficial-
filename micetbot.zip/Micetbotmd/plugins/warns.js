export default {
    name: 'warns',
    alias: ['verwarns', 'lista-warns'],
    
    async execute(sock, msg, options) {
        try {
            const { config, usersDB, senderNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            // Verificar que sea un grupo
            if (!from.includes('@g.us')) {
                return;
            }

            // Verificar registro
            if (usersDB && senderNumber && !usersDB[senderNumber]) {
                await sock.sendMessage(from, { 
                    text: `🍥 Para usar mis comandos tienes que estar registrado.\n> Uso : ${config.prefix}reg Misa.16`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }

            // 🔥 FUNCIÓN PARA OBTENER EL NÚMERO REAL 🔥
            const getRealPhoneNumber = (jid) => {
                if (!jid) return null;
                const identificador = jid.split('@')[0];
                
                for (const [num, data] of Object.entries(usersDB)) {
                    if (data.lid === jid || data.lid === identificador) return num;
                    if (data.jid === jid || data.jid === identificador) return num;
                }
                
                if (/^[\d]+$/.test(identificador) && identificador.length > 8) return identificador;
                return null;
            };
            
            let targetUserJid = null;
            let targetUserNumber = null;

            // Obtener usuario objetivo
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
                targetUserNumber = getRealPhoneNumber(targetUserJid);
            }
            else if (msg.message?.extendedTextMessage?.contextInfo?.participant) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.participant;
                targetUserNumber = getRealPhoneNumber(targetUserJid);
            }
            // Si no hay mención ni respuesta, usar al propio usuario
            else if (senderNumber) {
                targetUserNumber = senderNumber;
                // Buscar JID en el grupo
                const found = groupMetadata?.participants?.find(p => 
                    p.id.includes(senderNumber) || 
                    p.id.split('@')[0] === senderNumber
                );
                if (found) targetUserJid = found.id;
            }

            if (!targetUserJid || !targetUserNumber) {
                await sock.sendMessage(from, { 
                    text: `🍥 Debes proporcionar a un usuario\n> Responde a un mensaje o menciona con @\n> También puedes usar el comando sin mencionar para ver tus propios warns`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }

            // Obtener warns del usuario
            const { getWarns } = await import('../handler.js');
            const userWarns = getWarns(targetUserNumber, from);
            
            if (userWarns.length === 0) {
                await sock.sendMessage(from, { 
                    text: `🌠 El usuario @${targetUserNumber} no tiene advertencias`,
                    mentions: [targetUserJid],
                    contextInfo: {
                        mentionedJid: [targetUserJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                return;
            }

            let warnsText = `🦋 *Warns de @${targetUserNumber}*\n\n`;
            
            userWarns.forEach(warn => {
                warnsText += `🌠 *Warn #${warn.id}*\n`;
                warnsText += `🌠 Razón » *${warn.reason}*\n`;
                warnsText += `🌠 Fecha » *${warn.date}*\n`;
                warnsText += `🌠 Administrador » @${warn.warner}\n`;
                warnsText += `━━━━━━━━━━━━━━━━━━━━\n`;
            });

            warnsText += `\n🍁 *Total:* ${userWarns.length}/3 warns`;

            // Obtener JIDs para menciones
            const warnersJids = userWarns
                .map(w => `${w.warner}@s.whatsapp.net`)
                .filter(jid => jid !== targetUserJid);

            await sock.sendMessage(from, { 
                text: warnsText,
                mentions: [targetUserJid, ...warnersJids],
                contextInfo: {
                    mentionedJid: [targetUserJid, ...warnersJids],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            console.log(`✅ Warns consultados para ${targetUserNumber} por ${senderNumber || 'usuario'}`);

        } catch (error) {
            console.error('❌ Error en warns:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { 
                    text: `🌠 Error al consultar warns: ${error.message}`,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        },
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};