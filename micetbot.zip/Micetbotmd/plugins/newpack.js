import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PACKS_FILE = path.join(__dirname, '..', 'databases', 'packs.json');

const loadPacksDB = () => {
    try {
        if (fs.existsSync(PACKS_FILE)) {
            const data = fs.readFileSync(PACKS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando packs.json:', error);
    }
    return {};
};

const savePacksDB = (packsDB) => {
    try {
        const dbDir = path.join(__dirname, '..', 'databases');
        if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
        fs.writeFileSync(PACKS_FILE, JSON.stringify(packsDB, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando packs.json:', error);
        return false;
    }
};

export default {
    name: 'newpack',
    alias: ['addpack'],
    
    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, senderJid, args, pushName } = options;
            const from = msg.key.remoteJid;
            
            const packName = args.join(' ').trim();
            
            if (!packName || packName.length < 1 || packName.length > 64) {
                return await sock.sendMessage(from, {
                    text: `「✰」El nombre del pack debe tener entre 1 y 64 caracteres\n> Ejemplo: ${config.prefix}newpack Mis Stickers`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            const packsDB = loadPacksDB();
            
            if (!packsDB[senderNumber]) packsDB[senderNumber] = { packs: [] };
            
            const existingPack = packsDB[senderNumber].packs.find(p => p.name.toLowerCase() === packName.toLowerCase());
            
            if (existingPack) {
                return await sock.sendMessage(from, {
                    text: `「✰」Ya tienes un pack con el nombre "${packName}"`,
                    contextInfo: {
                        mentionedJid: [senderJid],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            const newPack = {
                id: Date.now().toString(),
                name: packName,
                owner: senderNumber,
                ownerJid: senderJid,
                ownerName: pushName || senderNumber,
                author: '𝖬𝖺𝖽𝖾 𝗂𝗇 𝖬𝗈𝗈𝗇𝗅𝗂𝗀𝗁𝗍 𝖲𝗍𝖺𝖿𝖿',
                desc: `Paquete de stickers creado por ${pushName || senderNumber}`,
                createdAt: new Date().toLocaleString(),
                lastModified: Date.now().toString(),
                timestamp: Date.now(),
                stickers: [],
                spackpublic: 0
            };
            
            packsDB[senderNumber].packs.push(newPack);
            savePacksDB(packsDB);
            
            await sock.sendMessage(from, {
                text: `《✧》El paquete de stickers \`${packName}\` ha sido creado exitosamente!\n> Puedes agregar stickers respondiendo a uno usando *${config.prefix}addsticker ${packName}*!`,
                contextInfo: {
                    mentionedJid: [senderJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
        } catch (error) {
            console.error('❌ Error en newpack:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ Error: ${error.message}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: options.config?.canalId || '',
                        serverMessageId: 0,
                        newsletterName: options.config?.canalNombre || ''
                    }
                }
            }, { quoted: msg });
        }
    }
};